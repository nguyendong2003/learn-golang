import { Injectable } from '@nestjs/common'

@Injectable()
export class PostsService {
  getPosts() {
    return [
      { id: 1, title: 'First Post 1', content: 'This is the first post' },
      { id: 2, title: 'Second Post', content: 'This is the second post' },
    ]
  }

  createPost(body: any) {
    return {
      id: Math.floor(Math.random() * 1000),
      ...body,
    }
  }

  getPost(id: string) {
    return { id, title: `Post ${id}`, content: `This is post ${id}` }
  }

  updatePost(id: string, body: any) {
    return {
      id,
      ...body,
    }
  }

  deletePost(id: string) {
    return { message: `Post ${id} deleted` }
  }
}
