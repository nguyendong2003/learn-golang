import { Injectable, OnModuleInit, OnModuleDestroy, Logger } from '@nestjs/common'
import { PrismaClient } from 'src/generated/prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'

@Injectable()
export class PrismaService extends PrismaClient {
  constructor() {
    const databaseUrl = process.env.DATABASE_URL
    if (!databaseUrl) {
      throw new Error('DATABASE_URL is missing')
    }

    super({
      adapter: new PrismaPg({ connectionString: databaseUrl }),
      log: ['query', 'error', 'warn', 'info'],
    })
  }
}
