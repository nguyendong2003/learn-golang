import React, { useState, useEffect } from 'react';
import {
  Modal,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  StyleSheet,
  Alert,
} from 'react-native';
import { HotUpdater } from '@hot-updater/react-native';

export default function DevChannelSwitcher() {
  const [visible, setVisible] = useState(false);
  const [currentChannel, setCurrentChannel] = useState('stg');
  const [targetChannel, setTargetChannel] = useState('');

  useEffect(() => {
    // Lấy thông tin channel hiện tại (đồng bộ)
    const ch = HotUpdater.getChannel();
    if (ch) {
      setCurrentChannel(ch);
    }
  }, [visible]);

  const handleSwitchChannel = async () => {
    if (!targetChannel.trim()) {
      return;
    }

    try {
      Alert.alert('Checking', `Checking for updates on channel: ${targetChannel.trim()}...`);
      const updateInfo = await HotUpdater.checkForUpdate({
        channel: targetChannel.trim(),
        updateStrategy: 'appVersion',
      });

      if (updateInfo) {
        await updateInfo.updateBundle();
        setVisible(false);
        await HotUpdater.reload();
      } else {
        Alert.alert('No Updates', `No updates found on channel: ${targetChannel.trim()}`);
      }
    } catch (error) {
      console.error('Failed to switch channel:', error);
      Alert.alert('Error', 'Failed to switch channel. Check console logs.');
    }
  };

  const handleReset = async () => {
    try {
      await HotUpdater.resetChannel();
      setVisible(false);
      await HotUpdater.reload();
    } catch (error) {
      console.error('Failed to reset channel:', error);
      Alert.alert('Error', 'Failed to reset channel.');
    }
  };

  return (
    <>
      <TouchableOpacity style={styles.fab} onPress={() => setVisible(true)}>
        <Text style={styles.fabText}>🔥</Text>
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType='slide'>
        <View style={styles.modalOverlay}>
          <View style={styles.card}>
            <Text style={styles.title}>Dynamic Channel Switcher</Text>
            <Text style={styles.subtitle}>
              Current Channel: <Text style={styles.bold}>{currentChannel}</Text>
            </Text>

            <TextInput
              style={styles.input}
              placeholder='e.g., V567APP-199'
              value={targetChannel}
              onChangeText={setTargetChannel}
              autoCapitalize='none'
            />

            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={[styles.btn, styles.btnSwitch]}
                onPress={handleSwitchChannel}
              >
                <Text style={styles.btnText}>🚀 Switch Task</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.btn, styles.btnReset]}
                onPress={handleReset}
              >
                <Text style={styles.btnText}>🔄 Reset (stg)</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.btnClose}
              onPress={() => setVisible(false)}
            >
              <Text style={styles.closeText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  fab: {
    position: 'absolute',
    bottom: 40,
    right: 20,
    backgroundColor: '#111',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999,
  },
  fabText: { fontSize: 22 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: '85%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
  },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#555', marginBottom: 16 },
  bold: { fontWeight: 'bold', color: '#000' },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginBottom: 16,
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 10,
  },
  btn: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  btnSwitch: { backgroundColor: '#2563eb' },
  btnReset: { backgroundColor: '#4b5563' },
  btnText: { color: '#fff', fontWeight: '600' },
  btnClose: { marginTop: 12, alignItems: 'center' },
  closeText: { color: '#ef4444' },
});
