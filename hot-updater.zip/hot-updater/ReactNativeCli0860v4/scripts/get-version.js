const fs = require('fs');
const path = require('path');

const envFile = process.argv[2] || '.env.staging';
try {
  const envPath = path.resolve(process.cwd(), envFile);
  if (!fs.existsSync(envPath)) {
    console.error(`Error: File ${envFile} not found`);
    process.exit(1);
  }

  const content = fs.readFileSync(envPath, 'utf8');
  const line = content.split('\n').find(l => l.startsWith('ANDROID_VERSION_NAME='));
  if (!line) {
    console.error(`Error: ANDROID_VERSION_NAME not found in ${envFile}`);
    process.exit(1);
  }

  const version = line.split('=')[1].replace(/['"\r]/g, '').trim();
  console.log(version);
} catch (error) {
  console.error('Error reading version:', error);
  process.exit(1);
}
