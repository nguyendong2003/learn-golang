const { execSync } = require('child_process');

try {
  // Lấy danh sách các file thay đổi trong commit hiện tại
  const diffFiles = execSync('git diff-tree --no-commit-id --name-only -r HEAD')
    .toString()
    .split('\n');

  const nativePaths = ['android/', 'ios/'];

  const hasNativeChanges = diffFiles.some(file =>
    nativePaths.some(path => file.startsWith(path)),
  );

  if (hasNativeChanges) {
    console.log(
      '⚠️ [WARNING]: Native changes detected in commit! Skipped Hot Update. Full Native Build is required.',
    );
    process.exit(1); // Trả về lỗi để ngắt pipeline OTA
  } else {
    console.log(
      '✅ Only JS/Asset changes detected. Proceeding with Hot Update deploy...',
    );
    process.exit(0);
  }
} catch (error) {
  console.error('Error checking git diff:', error);
  process.exit(0);
}
