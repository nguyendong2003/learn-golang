import React from 'react';
import {
  StatusBar,
  StyleSheet,
  Text,
  useColorScheme,
  View,
} from 'react-native';
import {
  SafeAreaProvider,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';
import { NewAppScreen } from '@react-native/new-app-screen';
import Config from 'react-native-config';
import { HotUpdater } from '@hot-updater/react-native';
import DevChannelSwitcher from './src/components/DevChannelSwitcher';

const isDevMode = Config.DEVELOPMENT_MODE === 'true';
const isHotUpdateEnabled = Config.HOT_UPDATER_ENABLED === 'true';

function MainApp() {
  const isDarkMode = useColorScheme() === 'dark';
  const safeAreaInsets = useSafeAreaInsets();

  return (
    <View style={styles.container}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text
          style={{
            fontSize: 24,
            fontWeight: 'bold',
            textAlign: 'center',
          }}
        >
          Hello World Staging
        </Text>
      </View>
      {/* <NewAppScreen
        templateFileName="App.tsx"
        safeAreaInsets={safeAreaInsets}
      /> */}
      {/* Dev Channel Switcher Floating Button chỉ hiển thị ở Staging/Dev */}
      {isDevMode && <DevChannelSwitcher />}
    </View>
  );
}

function MainAppWrapper() {
  return (
    <SafeAreaProvider>
      <MainApp />
    </SafeAreaProvider>
  );
}

const HotUpdatedApp = HotUpdater.wrap({
  baseURL: Config.HOT_UPDATER_BASE_URL || '',
  updateStrategy: 'appVersion',
  updateMode: 'auto',
})(MainAppWrapper);

export default function App() {
  if (!isHotUpdateEnabled) {
    return <MainAppWrapper />;
  }
  return <HotUpdatedApp />;
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
