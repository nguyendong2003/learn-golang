# Tóm Tắt Luồng Hoạt Động GitLab CI/CD: React Native & Hot Updater

Tài liệu này tóm tắt toàn bộ quy trình tự động hóa (CI/CD Pipeline) khi tích hợp **Hot Updater** vào dự án React Native.

---

## 1. Bản Chất Cốt Lõi (Core Philosophy)

* **Quy trình truyền thống (Full Native Build):** Mỗi lần thay đổi code JS hoặc CSS, hệ thống phải build lại toàn bộ Native App (tạo file `.apk` hoặc `.ipa`). Quá trình này rất tốn thời gian (15–30 phút) và QA phải gỡ app cũ cài app mới liên tục.
* **Quy trình mới (Hot Updater - OTA):** 
  * Bạn chỉ cần build Native App (APK/IPA) **một lần duy nhất** để cài lên thiết bị của QA hoặc người dùng.
  * Khi có thay đổi ở tầng JavaScript, CSS, hoặc hình ảnh, CI/CD chỉ mất **1–2 phút** để đóng gói mã nguồn JS (Bundle) rồi đẩy lên Cloudflare (D1/R2). 
  * Ứng dụng trên điện thoại khi khởi động sẽ tự động kiểm tra và tải gói cập nhật mới về để áp dụng ngay lập tức mà không cần cài lại app.

---

## 2. Ba Kênh Cập Nhật (Deployment Channels)

Hệ thống lưu trữ và phân phối gói bundle JS trên Cloudflare được chia làm 3 kênh chính:

| Tên Kênh (Channel) | Môi Trường | Đối Tượng Sử Dụng | Cách Thức Hoạt Động |
| :--- | :--- | :--- | :--- |
| **`stg` (Staging)** | Staging (`.env.staging`) | QA Tester | Kênh kiểm thử chung cho cả đội. Chứa code mới nhất đã được merge vào nhánh `develop`. |
| **`[Jira-Ticket-ID]`** | Staging (`.env.staging`) | QA Tester / Dev | Kênh tạm thời (Ephemeral Channel) dùng để test riêng một tính năng đang phát triển ở Feature Branch độc lập (ví dụ: `V567APP-199`). |
| **`production`** | Production (`.env.production`) | End-User (Khách hàng) | Kênh chính thức cho người dùng cuối trên App Store / Google Play. |

---

## 3. Luồng Hoạt Động Của 4 Job Trong `.gitlab-ci.yml`

Khi có lập trình viên đẩy code (Push) hoặc gộp code (Merge PR), GitLab CI/CD sẽ tự động kích hoạt pipeline chạy qua các bước sau:

```mermaid
graph TD
    A[Push Code / Merge PR] --> B{Job 1: check_native_changes}
    B -- Phát hiện sửa code Native --> C[Dừng Pipeline - Bắt buộc Build Native lại]
    B -- Chỉ sửa JS / CSS / Assets --> D[Đi tiếp sang Stage Deploy]
    
    D --> E{Kiểm tra điều kiện nhánh}
    E -- Nhánh develop / staging --> F[Job 2: deploy_staging_ota<br>Đẩy lên kênh 'stg']
    E -- Bấm nút Run Pipeline thủ công --> G[Job 3: deploy_task_ota<br>Đẩy lên kênh 'Jira-Ticket-ID']
    E -- Push Tag v* / Nhánh main --> H[Job 4: deploy_production_ota<br>Đẩy lên kênh 'production']
```

### 🚨 Job 1: `check_native_changes` (Chốt chặn an toàn - Tự động)
* **Khi nào chạy:** Tự động chạy mỗi khi push code lên `develop`, `staging`, hoặc `main`.
* **Nhiệm vụ:** Chạy script Git quét xem commit này có chỉnh sửa gì trong thư mục `android/` hoặc `ios/` hay không.
* **Mục đích:** Nếu bạn thêm thư viện Native mới (ví dụ: Bluetooth, Camera...) mà chỉ cập nhật OTA (JS-only), app người dùng sẽ bị crash do thiếu code native chạy dưới nền.
* **Kết quả:**
  * **Có sửa native:** Job báo **Thất bại (Fail)** -> Dừng pipeline để ngăn chặn việc đẩy cập nhật OTA lỗi.
  * **Không sửa native:** Job báo **Thành công (Success)** -> Cho phép các job deploy chạy tiếp.

### 🧪 Job 2: `deploy_staging_ota` (Deploy Staging chung - Tự động)
* **Khi nào chạy:** Tự động chạy sau khi Job 1 thành công và code được merge vào nhánh `develop` hoặc `staging`.
* **Nhiệm vụ:** Lấy cấu hình `.env.staging`, đóng gói JS Bundle và đẩy lên Cloudflare nhắm vào kênh `stg`.
* **Kết quả:** QA Tester mở Staging app lên sẽ nhận được tính năng mới ngay lập tức mà không cần cài lại file cài đặt mới.

### 🚀 Job 3: `deploy_task_ota` (Deploy Task lẻ - Thủ công)
* **Khi nào chạy:** Lập trình viên hoặc QA kích hoạt thủ công (Manual) từ giao diện GitLab Web UI khi cần test riêng một nhánh tính năng (Feature Branch) chưa merge vào nhánh chính.
* **Cách sử dụng:**
  1. Vào GitLab -> Pipelines -> Bấm **Run pipeline**.
  2. Chọn nhánh tính năng, nhập biến `TASK_CHANNEL` (ví dụ: `V567APP-199`) rồi chạy.
  3. CI/CD đóng gói JS Bundle và đẩy lên Cloudflare dưới kênh `V567APP-199`.
  4. QA mở Staging App, nhấn **Nút Fire 🔥**, nhập `V567APP-199` và bấm **Switch** để tải bản test riêng của task này. Test xong bấm **Reset** để quay lại kênh `stg` mặc định.

### 👑 Job 4: `deploy_production_ota` (Deploy Production - Tự động)
* **Khi nào chạy:** Tự động chạy khi tạo một **Release Tag** mới (ví dụ: `v1.0.0`) hoặc khi code được gộp vào nhánh `main`.
* **Nhiệm vụ:** Lấy cấu hình `.env.production`, đóng gói JS Bundle và đẩy lên Cloudflare nhắm vào kênh `production`.
* **Kết quả:** Tất cả người dùng cài app từ App Store/Google Play khi mở app lên sẽ tự động nhận được bản hotfix/tính năng mới này một cách mượt mà dưới nền.
