# Architecture & Setup Guide: Multi-Environment & Hot Updater Integration

**Dành cho React Native CLI 0.86.0 (Android & iOS)**

---

## 1. Tổng Quan Kiến Trúc & Tư Duy Thiết Kế

Khi phát triển một ứng dụng React Native quy mô lớn, việc tách biệt các môi trường (Dev, Staging, Production) kết hợp với giải pháp **Over-The-Air (OTA) Updates** là điều bắt buộc.

### Ma trận Môi trường & Luồng Hot Update

```
                      ┌─────────────────────────────────┐
                      │        REACT NATIVE APP         │
                      └────────────────┬────────────────┘
                                       │
                         [Environment Configuration]
                                       │
         ┌─────────────────────────────┼─────────────────────────────┐
         ▼                             ▼                             ▼
 .env.development                .env.staging                .env.production
 • API: dev.api.com              • API: stg.api.com          • API: api.com
 • ID: com.app.dev               • ID: com.app.stg           • ID: com.app
 • DEVELOPMENT_MODE: true        • DEVELOPMENT_MODE: true    • DEVELOPMENT_MODE: false
 • HOT_UPDATER_ENABLED: false    • HOT_UPDATER_ENABLED: true • HOT_UPDATER_ENABLED: true
         │                             │                             │
         │                             │ (Chạy OTA Resolver)         │ (Chạy OTA Resolver)
         │                             ▼                             ▼
         │                     ┌───────────────┐             ┌───────────────┐
         │                     │  Hot Update:  │             │  Hot Update:  │
         │                     │    ENABLED    │             │    ENABLED    │
         │                     └───────┬───────┘             └───────────────┘
         │                             │
         │                             ├─► Channel: stg (Base QA Branch)
         ▼                             └─► Ephemeral Channels (e.g., V567APP-199)
┌─────────────────┐                        (Có Switch Channel UI 🔥)
│  Hot Update:    │
│    DISABLED     │
│ (Metro Local)   │
└─────────────────┘
```

### Nguyên tắc cốt lõi:

1. **Config Bake-in:** Môi trường (`.env.*`) được nhúng (bake) trực tiếp vào JS Bundle trong quá trình bundling. Vì vậy, khi deploy Hot Update cho một channel, ta phải nạp đúng file env của môi trường đó.
2. **Feature Isolation:** Tính năng **Switch Channel UI** (Dev Channel Switcher) chỉ được phép xuất hiện ở bản build **Staging** và **Development** (`DEVELOPMENT_MODE=true`). Tuyệt đối cách ly khỏi môi trường **Production**.
3. **App Version Targeting:** Hot Update bundle gắn chặt với phiên bản Native App (`appVersion`, ví dụ `1.0.0`). Nếu có bất kỳ thay đổi nào ở tầng **Native Code** (Podfile, Gradle, Native Modules), bắt buộc phải build lại Native App và tăng `appVersion`.
4. **Phân biệt `DEVELOPMENT_MODE` & `HOT_UPDATER_ENABLED`:**
   - **`HOT_UPDATER_ENABLED`**: Quyết định xem app có khởi tạo và kết nối tới server Hot Updater để kiểm tra/tải bản cập nhật OTA hay không. Cần đặt là `false` ở local development để tránh xung đột với Metro server local.
   - **`DEVELOPMENT_MODE`**: Quyết định xem app có mở các tính năng bổ trợ dành cho dev/tester hay không (như nút Floating Button 🔥 để switch channel ở Staging). Cần đặt là `false` ở Production để đảm bảo bảo mật cho môi trường cuối.

---

## 2. Cấu Hình Multi-Environment (React Native Config)

Áp dụng cho React Native 0.86.0 với Gradle plugin mới và Auto-linking.

### Step 2.1: Khai báo file môi trường ở Root

Tạo 3 file cấu hình ở thư mục gốc project:

#### `.env.development`

```ini
ENV=development
APP_NAME="MyApp Dev"
API_URL=https://api-dev.example.com
ANDROID_APPLICATION_ID=com.myapp.dev
HOT_UPDATER_ENABLED=false
DEVELOPMENT_MODE=true
HOT_UPDATER_BASE_URL=https://hot-update.staging.workers.dev/api/check-update
ANDROID_VERSION_CODE=1
ANDROID_VERSION_NAME=1.0.0
```

#### `.env.staging`

```ini
ENV=staging
APP_NAME="MyApp Stg"
API_URL=https://api-stg.example.com
ANDROID_APPLICATION_ID=com.myapp.stg
HOT_UPDATER_ENABLED=true
DEVELOPMENT_MODE=true
HOT_UPDATER_BASE_URL=https://hot-update.staging.workers.dev/api/check-update
ANDROID_VERSION_CODE=1
ANDROID_VERSION_NAME=1.0.0
```

#### `.env.production`

```ini
ENV=production
APP_NAME="MyApp"
API_URL=https://api.example.com
ANDROID_APPLICATION_ID=com.myapp
HOT_UPDATER_ENABLED=true
DEVELOPMENT_MODE=false
HOT_UPDATER_BASE_URL=https://hot-update.production.workers.dev/api/check-update
ANDROID_VERSION_CODE=1
ANDROID_VERSION_NAME=1.0.0
```

---

### Step 2.2: Config Android Client (`android/app/build.gradle`)

Trong React Native 0.86.0, cấu hình `react-native-config` cùng với `flavorDimensions` được thiết lập như sau:

```groovy
// 1. Khai báo mapping ENV ở đầu file
project.ext.envConfigFiles = [
    development: ".env.development",
    staging: ".env.staging",
    production: ".env.production"
]

apply from: project(':react-native-config').projectDir.getPath() + "/dotenv.gradle"

android {
    ...
    namespace "com.myapp"
    defaultConfig {
        applicationId project.env.get("ANDROID_APPLICATION_ID")
        minSdkVersion rootProject.ext.minSdkVersion
        targetSdkVersion rootProject.ext.targetSdkVersion
        versionCode project.env.get("ANDROID_VERSION_CODE").toInteger()
        versionName project.env.get("ANDROID_VERSION_NAME")
        resValue 'string', 'build_config_package', 'com.myapp'
    }

    flavorDimensions "default"
    productFlavors {
        development {
            dimension "default"
            resValue "string", "app_name", "MyApp Dev"
        }
        staging {
            dimension "default"
            resValue "string", "app_name", "MyApp Stg"
        }
        production {
            dimension "default"
            resValue "string", "app_name", "MyApp"
        }
    }
}
```

> **Cấu trúc Thư mục GoogleService.json & App Icon theo Flavor:**
>
> ```text
> android/app/src/
> ├── main/             --> Chứa GoogleService.json (Production) & base code
> ├── development/      --> Chứa GoogleService.json (Dev) & res/mipmap-*/ic_launcher.png
> └── staging/          --> Chứa GoogleService.json (Staging) & res/mipmap-*/ic_launcher.png
> ```

---

### Step 2.3: Config iOS Client (`ios/`)

1. Tạo **Configurations** trong Xcode: `Development`, `Staging`, `Production` (tương ứng cho cả Debug & Release).
2. Tạo các **Scheme**: `MyApp-Dev`, `MyApp-Stg`, `MyApp-Prod`.
3. Trong Build Phases -> Run Script (đặt trên cùng):
   ```bash
   cp "${PROJECT_DIR}/../${ENVFILE}" "${PROJECT_DIR}/../.env"
   ```

---

## 3. Tích Hợp Hot-Updater & Switch Channel Logic

### Step 3.1: File Cấu Hình Hot Updater (`hot-updater.config.ts`)

```typescript
import { bare } from '@hot-updater/bare';
import { d1Database, r2Storage } from '@hot-updater/cloudflare';
import { defineConfig } from 'hot-updater';
import fs from 'fs';
import path from 'path';

// Nạp thủ công biến môi trường từ .env.hotupdater để đảm bảo các tiến trình con (Nuxt console) có biến cấu hình Cloudflare
const envPath = path.resolve(__dirname, '.env.hotupdater');
if (fs.existsSync(envPath)) {
  const envConfig = fs.readFileSync(envPath, 'utf8');
  envConfig.split('\n').forEach((line) => {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (match) {
      const key = match[1];
      let value = match[2] || '';
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.substring(1, value.length - 1);
      } else if (value.startsWith("'") && value.endsWith("'")) {
        value = value.substring(1, value.length - 1);
      }
      process.env[key] = value.trim();
    }
  });
}

export default defineConfig({
  updateStrategy: 'appVersion',
  build: bare({ enableHermes: true }),
  storage: r2Storage({
    bucketName: process.env.HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME!,
    accountId: process.env.HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID!,
    credentials: {
      accessKeyId: process.env.HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID!,
      secretAccessKey: process.env.HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY!,
    },
  }),
  database: d1Database({
    databaseId: process.env.HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID!,
    accountId: process.env.HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID!,
    cloudflareApiToken: process.env.HOT_UPDATER_CLOUDFLARE_API_TOKEN!,
  }),
});
```

---

### Step 3.2: Bootstrap App Integration (`App.tsx`)

Bọc Root Component bằng HOC của Hot Updater. Chỉ kích hoạt cơ chế tự động update nếu `HOT_UPDATER_ENABLED=true`.

```tsx
import React, { useEffect } from 'react';
import { View, StyleSheet } from 'react-native';
import Config from 'react-native-config';
import HotUpdater from 'hot-updater';
import DevChannelSwitcher from './src/components/DevChannelSwitcher';

const isDevMode = Config.DEVELOPMENT_MODE === 'true';
const isHotUpdateEnabled = Config.HOT_UPDATER_ENABLED === 'true';

function MainApp() {
  return (
    <View style={styles.container}>
      {/* Root Navigation / Application Components */}

      {/* Dev Channel Switcher Floating Button chỉ hiển thị ở Staging/Dev */}
      {isDevMode && <DevChannelSwitcher />}
    </View>
  );
}

const HotUpdatedApp = HotUpdater.wrap({
  baseURL: Config.HOT_UPDATER_BASE_URL,
  updateStrategy: 'appVersion',
  updateMode: 'auto',
})(MainApp);

export default function App() {
  if (!isHotUpdateEnabled) {
    return <MainApp />;
  }
  return <HotUpdatedApp />;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});
```

---

### Step 3.3: In-App Dev Channel Switcher (`DevChannelSwitcher.tsx`)

Component hiển thị nút FAB điều hướng dành riêng cho QA/Tester chuyển đổi giữa các ephemeral channels.

```tsx
import React, { useState, useEffect } from 'react';
import {
  Modal,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  StyleSheet,
} from 'react-native';
import HotUpdater from 'hot-updater';

export default function DevChannelSwitcher() {
  const [visible, setVisible] = useState(false);
  const [currentChannel, setCurrentChannel] = useState('stg');
  const [targetChannel, setTargetChannel] = useState('');

  useEffect(() => {
    // Lấy thông tin channel hiện tại
    HotUpdater.getChannel().then((ch) => {
      if (ch) setCurrentChannel(ch);
    });
  }, []);

  const handleSwitchChannel = async () => {
    if (!targetChannel.trim()) return;

    // Lưu ý: Quy trình chuyển từ Ephemeral Channel sang Ephemeral Channel khác
    // Cần reset về channel gốc (stg) trước khi set channel mới
    await HotUpdater.setChannel('stg');
    await HotUpdater.setChannel(targetChannel.trim());
    setVisible(false);
    HotUpdater.reload();
  };

  const handleReset = async () => {
    await HotUpdater.setChannel('stg');
    setVisible(false);
    HotUpdater.reload();
  };

  return (
    <>
      <TouchableOpacity style={styles.fab} onPress={() => setVisible(true)}>
        <Text style={styles.fabText}>🔥</Text>
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType='slide'>
        <View style={styles.modalOverlay}>
          <View style={styles.card}>
            <Text style={styles.title}>Dynamic Channel Switcher</Text>
            <Text style={styles.subtitle}>
              Current Channel: <Text style={styles.bold}>{currentChannel}</Text>
            </Text>

            <TextInput
              style={styles.input}
              placeholder='e.g., V567APP-199'
              value={targetChannel}
              onChangeText={setTargetChannel}
              autoCapitalize='none'
            />

            <View style={styles.buttonGroup}>
              <TouchableOpacity
                style={[styles.btn, styles.btnSwitch]}
                onPress={handleSwitchChannel}
              >
                <Text style={styles.btnText}>🚀 Switch Task</Text>
              </TouchableOpacity>

              <TouchableOpacity
                style={[styles.btn, styles.btnReset]}
                onPress={handleReset}
              >
                <Text style={styles.btnText}>🔄 Reset (stg)</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.btnClose}
              onPress={() => setVisible(false)}
            >
              <Text style={styles.closeText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  fab: {
    position: 'absolute',
    bottom: 40,
    right: 20,
    backgroundColor: '#111',
    width: 50,
    height: 50,
    borderRadius: 25,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999,
  },
  fabText: { fontSize: 22 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  card: {
    width: '85%',
    backgroundColor: '#fff',
    padding: 20,
    borderRadius: 12,
  },
  title: { fontSize: 18, fontWeight: 'bold', marginBottom: 8 },
  subtitle: { fontSize: 14, color: '#555', marginBottom: 16 },
  bold: { fontWeight: 'bold', color: '#000' },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginBottom: 16,
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: 10,
  },
  btn: { flex: 1, padding: 12, borderRadius: 8, alignItems: 'center' },
  btnSwitch: { backgroundColor: '#2563eb' },
  btnReset: { backgroundColor: '#4b5563' },
  btnText: { color: '#fff', fontWeight: '600' },
  btnClose: { marginTop: 12, alignItems: 'center' },
  closeText: { color: '#ef4444' },
});
```

---

## 4. Automation Scripts (`package.json`) & Helper Script

Để quản lý phiên bản một cách thống nhất từ file `.env` và giúp các câu lệnh trong `package.json` ngắn gọn, dễ đọc, ta tạo một script bổ trợ tại thư mục gốc:

### Tạo file `scripts/get-version.js`
```javascript
const fs = require('fs');
const path = require('path');

const envFile = process.argv[2] || '.env.staging';
try {
  const envPath = path.resolve(process.cwd(), envFile);
  if (!fs.existsSync(envPath)) {
    console.error(`Error: File ${envFile} not found`);
    process.exit(1);
  }

  const content = fs.readFileSync(envPath, 'utf8');
  const line = content.split('\n').find(l => l.startsWith('ANDROID_VERSION_NAME='));
  if (!line) {
    console.error(`Error: ANDROID_VERSION_NAME not found in ${envFile}`);
    process.exit(1);
  }

  const version = line.split('=')[1].replace(/['"\r]/g, '').trim();
  console.log(version);
} catch (error) {
  console.error('Error reading version:', error);
  process.exit(1);
}
```

### Cấu hình `package.json`
Tích hợp toàn bộ lệnh build Native App và Deploy OTA Bundle vào `package.json` (sử dụng script `get-version.js` để đọc phiên bản động):

```json
{
  "name": "myapp",
  "version": "1.0.0",
  "scripts": {
    "android": "react-native run-android",
    "ios": "react-native run-ios",

    "=== LOCAL BUILD SCRIPTS ===": "",
    "aos:dev": "ENVFILE=.env.development react-native run-android --mode=developmentDebug --appIdSuffix=dev",
    "aos:stg": "ENVFILE=.env.staging react-native run-android --mode=stagingDebug --appIdSuffix=stg",
    "aos:prod": "ENVFILE=.env.production react-native run-android --mode=productionRelease",

    "=== HOT UPDATER DEPLOYMENT ===": "",
    "hot:console": "npx hot-updater console",

    "hot:stg:ios": "ENVFILE=.env.staging npx hot-updater deploy -p ios -t $(node scripts/get-version.js .env.staging) --channel stg",
    "hot:stg:android": "ENVFILE=.env.staging npx hot-updater deploy -p android -t $(node scripts/get-version.js .env.staging) --channel stg",
    "hot:stg": "npm run hot:stg:ios && npm run hot:stg:android",

    "hot:task:ios": "ENVFILE=.env.staging npx hot-updater deploy -p ios -t $(node scripts/get-version.js .env.staging) --channel",
    "hot:task:android": "ENVFILE=.env.staging npx hot-updater deploy -p android -t $(node scripts/get-version.js .env.staging) --channel",

    "hot:prod:ios": "ENVFILE=.env.production npx hot-updater deploy -p ios -t $(node scripts/get-version.js .env.production) --channel production",
    "hot:prod:android": "ENVFILE=.env.production npx hot-updater deploy -p android -t $(node scripts/get-version.js .env.production) --channel production"
  }
}
```

---

## 5. Quy Trình Phối Hợp Giữa Developer & QA

### Luồng công việc hàng ngày (Daily Workflow)

```
[Developer]                                              [QA Tester]
    │                                                         │
    ├─► 1. Hoàn thành task (vd: V567APP-199)                  │
    │                                                         │
    ├─► 2. Chạy lệnh deploy Ephemeral Channel:                │
    │      $ npm run hot:task:ios V567APP-199                 │
    │      $ npm run hot:task:android V567APP-199             │
    │                                                         │
    ├─► 3. Notify QA trên Jira/Slack ────────────────────────►│
    │                                                         ├─► 4. Mở Staging App
    │                                                         ├─► 5. Bấm icon 🔥
    │                                                         ├─► 6. Nhập "V567APP-199" & Switch
    │                                                         ├─► 7. App tải bundle & Test
    │                                                         │
    ├─► 8. Merge PR vào branch develop                        │
    │                                                         │
    └─► 9. Deploy cập nhật Channel base (stg):                │
           $ npm run hot:stg                                  │
                                                              └─► 10. QA Reset về "stg" để test
                                                                     nhánh chính
```

---

## 6. So Sánh Quy Trình Cũ vs. Quy Trình Mới

| Tiêu chí                            | Quy trình truyền thống (Full Native Build) | Quy trình Mới (Hot Updater + Multi-Env)          |
| :---------------------------------- | :----------------------------------------- | :----------------------------------------------- |
| **Thời gian có app cho QA**         | 15–30 phút (Chờ CI/CD & TestFlight)        | **1–2 phút** (Chỉ bundle JS)                     |
| **Chi phí hạ tầng / Build machine** | Cao (Tốn CPU/RAM máy Mac/Cloud build)      | **Rất thấp** (Build bundle JS nhẹ)               |
| **Test nhiều Task song song**       | Cần cài nhiều file APK/IPA khác nhau       | **Switch Channel ngay trên 1 App duy nhất**      |
| **Rollback khi có lỗi**             | Build lại commit cũ (15-30 phút)           | **Rollback tức thì qua Dashboard Console**       |
| **Khả năng cách ly Production**     | Phụ thuộc vào việc check tay file Config   | **Cách ly triệt để bằng `.env` & Feature Flags** |

---

## 7. Các Lưu Ý Quan Trọng (Best Practices)

1. **Native Changes Rules:**
   - Hot Update **CHỈ** hoạt động cho **JavaScript, TypeScript, Asset (Images, Fonts)**.
   - Nếu có bất kỳ thay đổi nào liên quan tới Native (như thêm Pod, sửa `AndroidManifest.xml`, thêm Native Library mới), **BẮT BUỘC** phải thực hiện Native Build lại và cập nhật `appVersion` lên bản tiếp theo (ví dụ: `4.1.0`).

2. **Quản lý Secrets (.env):**
   - File `.env.hotupdater` chứa token của Cloudflare D1/R2 **không được commit lên Git**. Chia sẻ qua Bitwarden hoặc 1Password cho các thành viên trong team.

3. **Cấu hình `.gitignore` cho Hot Updater & các file Môi trường:**
   - Để tránh rò rỉ token bảo mật hoặc commit các file build/logs tạm thời lên Git, bạn cần thêm các cấu hình sau vào file `.gitignore` ở gốc dự án (vẫn cho phép commit các file template `.example` để làm mẫu):

     ```gitignore
     # hot-updater
     .env.hotupdater
     .hot-updater/output
     .hot-updater/log

     # Environments & Secrets (Chặn các file cấu hình thật, giữ lại file .example làm mẫu)
     .env
     .env.development
     .env.staging
     .env.production

     # build directory
     dist/
     ```

4. **Luồng Chuyển Channel trên App:**
   - Do cơ chế caching bundle của Hot Updater, khi QA muốn đổi từ Channel A (`V567APP-199`) sang Channel B (`V567APP-200`), luôn khuyến nghị thực hiện thao tác: **Reset về `stg` -> Nhập Channel B -> Switch**.

5. **Cấu hình Proguard cho react-native-config (Android):**
   - Khi build bản Release, Proguard có thể làm ẩn/xóa lớp `BuildConfig` khiến cho app bị crash hoặc không đọc được config. Cần thêm dòng sau vào file `android/app/proguard-rules.pro`:
     ```proguard
     -keep class com.myapp.BuildConfig { *; }
     ```
     *(Thay thế `com.myapp` bằng package name/namespace thực tế của dự án)*
