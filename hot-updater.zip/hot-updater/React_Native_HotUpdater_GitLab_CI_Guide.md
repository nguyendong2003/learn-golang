# CI/CD Pipeline Automation Guide: React Native & Hot Updater (GitLab CI/CD)

**Dành cho React Native CLI 0.86.0 (sử dụng GitLab CI/CD)**

---

## 1. Tổng Quan Quy Trình Làm Việc (Overall Workflow)

Tích hợp Hot Updater vào GitLab CI/CD giúp tự động hóa toàn bộ quá trình giao code từ Developer tới QA Tester và End-User mà **không cần thực hiện các bản build Native tốn thời gian (20–30 phút)** ngoại trừ khi có sự thay đổi ở tầng Native (Pod, Gradle, Native Library).

### Sơ đồ quy trình tổng quan (E2E Flow)

```
[ DEVELOPER ]
   │
   ├─► 1. Phát triển Task (vd: V567APP-199) trên Feature Branch
   │      │
   │      ├─► Cần QA Test Task lẻ? ────────────────────────────────────────────────────────┐
   │      │                                                                               │
   │      ▼                                                                               ▼
   ├─► 2. Tạo Merge Request (PR) vào `develop`                              [ GITLAB CI/CD (Web UI) ]
   │      │                                                                       │
   │      ▼                                                                       ├─► Trigger thủ công Job:
   ├─► 3. Review & Merge PR vào `develop`                                         │   `deploy_task_ota`
   │      │                                                                       │   (Truyền TASK_CHANNEL="V567APP-199")
   │      ▼                                                                       │
   │   [ GITLAB CI/CD (Tự động) ]                                                 ▼
   │      │                                                                [ QA TESTER ]
   │      ├─► Chạy Job: `deploy_staging_ota`                                      │
   │      │   (Build Bundle với `.env.staging` -> Push lên Channel `stg`)        ├─► 1. Mở Staging App
   │      │                                                                       ├─► 2. Bấm nút 🔥 (Floating Action Button)
   │      ▼                                                                       ├─► 3. Nhập "V567APP-199" & Switch
   ├─► 4. Sẵn sàng Release sản phẩm?                                             └─► 4. App tải Bundle mới nhất & Test
   │      │
   │      ▼
   ├─► 5. Push Release Tag (vd: `v1.0.0`) hoặc Merge vào `main`
   │      │
   │      ▼
   │   [ GITLAB CI/CD (Tự động) ]
   │      │
   │      └─► Chạy Job: `deploy_production_ota`
   │          (Build Bundle với `.env.production` -> Push lên Channel `production`)
   │
   ▼
[ END USER / PRODUCTION ]
   └─► App Production tự động kiểm tra và cập nhật OTA ở lần khởi động tiếp theo
```

---

## 2. Quản Lý Variables / Secrets Trên GitLab CI/CD

Trước khi triển khai, bạn cần khai báo các biến môi trường tại **Settings -> CI/CD -> Variables** trên dự án GitLab.

### Danh sách Variables bắt buộc:

| Key Variable                                  | Loại Variable   | Mô tả                                              |
| :-------------------------------------------- | :-------------- | :------------------------------------------------- |
| `HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID`           | Variable        | Account ID tài khoản Cloudflare                    |
| `HOT_UPDATER_CLOUDFLARE_API_TOKEN`            | Masked / Secret | API Token truy cập Cloudflare D1                   |
| `HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID`       | Variable        | Database ID của Cloudflare D1                      |
| `HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME`       | Variable        | Name của Cloudflare R2 Bucket                      |
| `HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID`     | Masked / Secret | Access Key ID của R2 Storage                       |
| `HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY` | Masked / Secret | Secret Access Key của R2 Storage                   |
| `ENV_STAGING_FILE`                            | **File**        | Nội dung file `.env.staging` (Chọn Type = File)    |
| `ENV_PRODUCTION_FILE`                         | **File**        | Nội dung file `.env.production` (Chọn Type = File) |

---

## 3. Cấu Hình File `.gitlab-ci.yml` Hoàn Chỉnh

Tạo hoặc cập nhật file `.gitlab-ci.yml` tại thư mục gốc của dự án:

```yaml
default:
  image: node:22
  cache:
    key:
      files:
        - package-lock.json
    paths:
      - .npm/

variables:
  NPM_CONFIG_CACHE: '$CI_PROJECT_DIR/.npm'

stages:
  - check
  - deploy-ota

.before_script_template: &before_script_template
  before_script:
    - npm ci

# ==============================================================================
# JOB 1: CHECK NATIVE CHANGES (Kiểm tra xem có thay đổi Native code hay không)
# ==============================================================================
check_native_changes:
  stage: check
  script:
    - npm ci
    - npm run ci:check-native
  rules:
    - if: '$CI_COMMIT_BRANCH == "develop" || $CI_COMMIT_BRANCH == "staging" || $CI_COMMIT_BRANCH == "main"'

# ==============================================================================
# JOB 2: STAGING OTA DEPLOY (Tự động deploy cho channel stg)
# ==============================================================================
deploy_staging_ota:
  <<: *before_script_template
  stage: deploy-ota
  needs: ['check_native_changes']
  script:
    - cp $ENV_STAGING_FILE .env.staging
    - npm run hot:stg
  rules:
    - if: '$CI_COMMIT_BRANCH == "develop" || $CI_COMMIT_BRANCH == "staging"'
      changes:
        - 'src/**/*'
        - 'App.tsx'
        - 'package.json'
        - 'package-lock.json'
        - 'hot-updater.config.ts'

# ==============================================================================
# JOB 3: TASK / EPHEMERAL CHANNEL DEPLOY (Trigger thủ công cho Task lẻ)
# ==============================================================================
deploy_task_ota:
  <<: *before_script_template
  stage: deploy-ota
  script:
    - |
      if [ -z "$TASK_CHANNEL" ]; then
        echo "❌ LỖI: Cần truyền biến TASK_CHANNEL (ví dụ: V567APP-199) khi trigger job này!"
        exit 1
      fi
    - cp $ENV_STAGING_FILE .env.staging
    - echo "🚀 Deploying OTA for channel: $TASK_CHANNEL"
    - |
      if [ "$PLATFORM" = "ios" ]; then
        npm run hot:task:ios -- "$TASK_CHANNEL"
      elif [ "$PLATFORM" = "android" ]; then
        npm run hot:task:android -- "$TASK_CHANNEL"
      else
        npm run hot:task:ios -- "$TASK_CHANNEL"
        npm run hot:task:android -- "$TASK_CHANNEL"
      fi
  rules:
    - if: '$CI_PIPELINE_SOURCE == "web" || $CI_PIPELINE_SOURCE == "schedule"'
      when: manual
      allow_failure: true

# ==============================================================================
# JOB 4: PRODUCTION OTA DEPLOY (Tự động deploy cho Production)
# ==============================================================================
deploy_production_ota:
  <<: *before_script_template
  stage: deploy-ota
  needs: ['check_native_changes']
  script:
    - cp $ENV_PRODUCTION_FILE .env.production
    - npm run hot:prod:ios
    - npm run hot:prod:android
  rules:
    - if: '$CI_COMMIT_TAG =~ /^v\d+\.\d+\.\d+/ || $CI_COMMIT_BRANCH == "main"'
      changes:
        - 'src/**/*'
        - 'App.tsx'
        - 'package.json'
        - 'package-lock.json'
        - 'hot-updater.config.ts'
```

---

## 4. Giải Thích Chi Tiết Từng Job Trong File `.gitlab-ci.yml`

Dưới đây là bảng phân tích chi tiết về từng Job trong pipeline để cả team (Dev, QA, DevOps) dễ dàng nắm bắt:

---

### 🔍 4.1. Job `check_native_changes`

- **Mục đích:** Kiểm tra xem commit mới có làm thay đổi mã nguồn Native (`android/`, `ios/`) hay không. Nếu có thay đổi Native, Job sẽ báo lỗi để chặn các Job deploy OTA phía sau, tránh việc đẩy bản cập nhật JS làm crash app của người dùng.
- **Ai dùng / kích hoạt:** **Hệ thống GitLab CI/CD tự động chạy**.
- **Khi nào dùng:** Mỗi khi có commit/push vào các branch quan trọng (`develop`, `staging`, `main`).
- **Hoạt động ra sao:** Chạy script Node.js (`scripts/check-native-changes.js`) để kiểm tra `git diff`. Nếu phát hiện có chỉnh sửa ở folder `android/` hoặc `ios/`, nó sẽ ngắt Pipeline.

---

### 🧪 4.2. Job `deploy_staging_ota`

- **Mục đích:** Tự động đóng gói JavaScript bundle với cấu hình Staging (`.env.staging`) và tải lên Cloudflare D1/R2 dưới **Channel `stg`**. Đây là channel mặc định mà tất cả app Staging trên máy QA/Tester kết nối tới.
- **Ai dùng / kích hoạt:** **Hệ thống GitLab CI/CD tự động chạy**.
- **Khi nào dùng:** Khi Developer tạo Merge Request và **merge code thành công vào branch `develop` hoặc `staging`**.
- **Dùng để làm gì:** Cập nhật bản build Staging chung cho toàn bộ team QA. Ngay khi code được merge vào `develop`, QA chỉ cần mở app Staging lên là có ngay tính năng mới mà không cần cài lại app.

---

### 🚀 4.3. Job `deploy_task_ota`

- **Mục đích:** Đóng gói code trên một Feature Branch riêng lẻ và đẩy lên Cloudflare dưới một **Ephemeral Channel (Channel tạm thời)** mang tên của Jira Ticket (ví dụ: `V567APP-199`).
- **Ai dùng / kích hoạt:** **Developer hoặc QA Tester kích hoạt thủ công (Manual)** trên giao diện GitLab Web UI.
- **Khi nào dùng:** Khi Developer vừa làm xong một Task (đang nằm trên Feature Branch, chưa merge vào `develop`) và muốn gửi riêng bản này cho QA test độc lập.
- **Các bước thao tác để kích hoạt:**
  1. Vào GitLab -> **Build** -> **Pipelines** -> Bấm nút **Run pipeline**.
  2. Chọn Feature Branch (ví dụ: `feature/V567APP-199`).
  3. Thêm Variable:
     - `TASK_CHANNEL`: `V567APP-199` _(Tên Ticket)_
     - `PLATFORM`: `all` _(Hoặc `ios` / `android`)_
  4. Bấm **Run pipeline** -> Tìm job `deploy_task_ota` và bấm nút ▶️ **Play**.
- **Dùng để làm gì:** Giúp QA dùng nút 🔥 trên app Staging gõ tên task `V567APP-199` để switch sang test riêng tính năng đó, không ảnh hưởng tới bản Staging chung (`stg`).

---

## 🚀 4.4. Job `deploy_production_ota`

- **Mục đích:** Đóng gói JavaScript bundle với cấu hình Production (`.env.production`) và tải lên Cloudflare D1/R2 dưới **Channel `production`**.
- **Ai dùng / kích hoạt:** **Hệ thống GitLab CI/CD tự động chạy** (hoặc Tech Lead khi Release).
- **Khi nào dùng:** Khi tạo một **Release Tag** mới (ví dụ: `v1.0.0`) hoặc khi merge code vào branch `main`.
- **Dùng để làm gì:** Phát hành bản sửa lỗi hotfix hoặc tính năng mới trực tiếp tới ứng dụng của khách hàng end-user trên App Store / Google Play mà không cần chờ duyệt lại ứng dụng từ Apple / Google.

---

## 5. Script Kiểm Tra Native Changes (`scripts/check-native-changes.js`)

Tạo file `scripts/check-native-changes.js` ở thư mục gốc dự án:

```javascript
const { execSync } = require('child_process');

try {
  // Lấy danh sách các file thay đổi trong commit hiện tại
  const diffFiles = execSync('git diff-tree --no-commit-id --name-only -r HEAD')
    .toString()
    .split('\n');

  const nativePaths = ['android/', 'ios/'];

  const hasNativeChanges = diffFiles.some((file) =>
    nativePaths.some((path) => file.startsWith(path)),
  );

  if (hasNativeChanges) {
    console.log(
      '⚠️ [WARNING]: Native changes detected in commit! Skipped Hot Update. Full Native Build is required.',
    );
    process.exit(1); // Trả về lỗi để ngắt pipeline OTA
  } else {
    console.log(
      '✅ Only JS/Asset changes detected. Proceeding with Hot Update deploy...',
    );
    process.exit(0);
  }
} catch (error) {
  console.error('Error checking git diff:', error);
  process.exit(0);
}
```

Khai báo trong `package.json`:

```json
"scripts": {
  "ci:check-native": "node scripts/check-native-changes.js"
}
```

---

## 6. Ma Trận Tóm Tắt Luồng GitLab CI/CD

| Job Name                | Người dùng / Kích hoạt    | Thời điểm sử dụng                   | Mục đích chính                              | Kênh Deploy (Channel) |
| :---------------------- | :------------------------ | :---------------------------------- | :------------------------------------------ | :-------------------- |
| `check_native_changes`  | GitLab CI (Tự động)       | Khi push code lên `develop`/`main`  | Kiểm tra & chặn OTA nếu sửa code Native     | _(Không deploy)_      |
| `deploy_staging_ota`    | GitLab CI (Tự động)       | Khi Merge PR vào `develop`          | Cập nhật bản Staging chung cho toàn bộ QA   | `stg`                 |
| `deploy_task_ota`       | Developer / QA (Thủ công) | Đang làm Feature Branch, chưa merge | Cho QA test riêng 1 Task lẻ trước khi merge | `[Jira-Ticket-ID]`    |
| `deploy_production_ota` | GitLab CI / Tech Lead     | Khi Push Tag `v*` hoặc Merge `main` | Cập nhật app cho khách hàng (End-Users)     | `production`          |
