# Hướng Dẫn Chi Tiết Triển Khai: Multi-Environment, Hot Updater, và GitLab CI/CD trên ReactNativeCli0860v4

Tài liệu này ghi lại chi tiết toàn bộ các bước đã thực hiện để thiết lập thành công hệ thống cấu hình đa môi trường (Multi-Environment), Over-The-Air (OTA) update sử dụng Hot-Updater và tự động hóa với GitLab CI/CD trên dự án **ReactNativeCli0860v4** (React Native 0.86.0).

---

## Bước 1: Cài đặt các package cần thiết

Tiến hành cài đặt các thư viện lõi phục vụ cấu hình môi trường và Hot-Updater client:
```bash
cd ReactNativeCli0860v4
npm install react-native-config @hot-updater/react-native hot-updater @hot-updater/bare @hot-updater/cloudflare
npm install --save-dev @types/node
```
* **`react-native-config`:** Đọc các biến môi trường từ file `.env.*` trong cả code Javascript và Native (Java/Kotlin/Obj-C).
* **`@hot-updater/react-native`:** Client SDK chạy trong ứng dụng React Native.
* **`hot-updater` & plugins:** CLI đóng gói và các adapter lưu trữ đám mây (Cloudflare D1 & R2).
* **`@types/node`:** Cung cấp kiểu dữ liệu TypeScript cho đối tượng toàn cục `process`.

---

## Bước 2: Cấu hình bỏ qua (.gitignore)

Để tránh việc rò rỉ token bảo mật hoặc commit các file log/build tạm thời lên Git, chúng ta cập nhật file **[.gitignore](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/.gitignore)** ở gốc dự án bằng cách thêm các dòng sau vào cuối file:

```gitignore
# hot-updater
.env.hotupdater
.hot-updater/output
.hot-updater/log

# Environments & Secrets
.env
.env.development
.env.staging
.env.production
```

---

## Bước 3: Tạo các file cấu hình môi trường (.env)

Tạo 3 file cấu hình môi trường ở thư mục gốc của dự án:

### 1. File `.env.development`
Dùng cho môi trường chạy thử nghiệm local (Metro server):
```ini
ENV=development
APP_NAME="MyApp Dev"
API_URL=https://api-dev.example.com
ANDROID_APPLICATION_ID=com.reactnativecli0860v4.dev
HOT_UPDATER_ENABLED=false
DEVELOPMENT_MODE=true
HOT_UPDATER_BASE_URL=https://hot-update.staging.workers.dev/api/check-update
ANDROID_VERSION_CODE=1
ANDROID_VERSION_NAME=1.0.0
```

### 2. File `.env.staging`
Dùng cho môi trường Staging test OTA của QA:
```ini
ENV=staging
APP_NAME="MyApp Stg"
API_URL=https://api-stg.example.com
ANDROID_APPLICATION_ID=com.reactnativecli0860v4.stg
HOT_UPDATER_ENABLED=true
DEVELOPMENT_MODE=true
HOT_UPDATER_BASE_URL=https://hot-update.staging.workers.dev/api/check-update
ANDROID_VERSION_CODE=1
ANDROID_VERSION_NAME=1.0.0
```

### 3. File `.env.production`
Dùng cho môi trường thực tế (Production):
```ini
ENV=production
APP_NAME="MyApp"
API_URL=https://api.example.com
ANDROID_APPLICATION_ID=com.reactnativecli0860v4
HOT_UPDATER_ENABLED=true
DEVELOPMENT_MODE=false
HOT_UPDATER_BASE_URL=https://hot-update.production.workers.dev/api/check-update
ANDROID_VERSION_CODE=1
ANDROID_VERSION_NAME=1.0.0
```

---

## Bước 4: Cấu hình đa môi trường cho Android (Flavors)

Chỉnh sửa file **[android/app/build.gradle](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/android/app/build.gradle)** để tự động map file `.env` tương ứng và phân chia build flavors:

1. **Thêm mapping file env ở đầu file (ngay dưới các plugin):**
   ```groovy
   project.ext.envConfigFiles = [
       development: ".env.development",
       staging: ".env.staging",
       production: ".env.production"
   ]
   apply from: project(':react-native-config').projectDir.getPath() + "/dotenv.gradle"
   ```
2. **Sửa defaultConfig trong `build.gradle` để đọc biến động và khai báo package cho react-native-config:**
   ```groovy
    defaultConfig {
        applicationId project.env.get("ANDROID_APPLICATION_ID")
        minSdkVersion rootProject.ext.minSdkVersion
        targetSdkVersion rootProject.ext.targetSdkVersion
        versionCode project.env.get("ANDROID_VERSION_CODE").toInteger()
        versionName project.env.get("ANDROID_VERSION_NAME")
        resValue 'string', 'build_config_package', 'com.reactnativecli0860v4'
    }
   ```
3. **Thêm cấu hình flavors ở cuối khối `android { ... }`:**
   ```groovy
   flavorDimensions "default"
   productFlavors {
       development {
           dimension "default"
           resValue "string", "app_name", "MyApp Dev"
       }
       staging {
           dimension "default"
           resValue "string", "app_name", "MyApp Stg"
       }
       production {
           dimension "default"
           resValue "string", "app_name", "MyApp"
       }
   }
   ```

4. **Cấu hình Proguard tránh mất file BuildConfig ở bản Release:**
   Thêm cấu hình sau vào file **[android/app/proguard-rules.pro](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/android/app/proguard-rules.pro)**:
   ```proguard
   # react-native-config
   -keep class com.reactnativecli0860v4.BuildConfig { *; }
   ```

---

## Bước 5: Cấu hình phía Server Hot-Updater

Tạo file cấu hình **[hot-updater.config.ts](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/hot-updater.config.ts)** ở thư mục gốc dự án để kết nối tới Cloudflare R2 & D1:

```typescript
import { bare } from '@hot-updater/bare';
import { d1Database, r2Storage } from '@hot-updater/cloudflare';
import { defineConfig } from 'hot-updater';
import fs from 'fs';
import path from 'path';

// Nạp thủ công biến môi trường từ .env.hotupdater để đảm bảo các tiến trình con (Nuxt console) có biến cấu hình Cloudflare
const envPath = path.resolve(__dirname, '.env.hotupdater');
if (fs.existsSync(envPath)) {
  const envConfig = fs.readFileSync(envPath, 'utf8');
  envConfig.split('\n').forEach((line) => {
    const match = line.match(/^\s*([\w.-]+)\s*=\s*(.*)?\s*$/);
    if (match) {
      const key = match[1];
      let value = match[2] || '';
      if (value.startsWith('"') && value.endsWith('"')) {
        value = value.substring(1, value.length - 1);
      } else if (value.startsWith("'") && value.endsWith("'")) {
        value = value.substring(1, value.length - 1);
      }
      process.env[key] = value.trim();
    }
  });
}

export default defineConfig({
  updateStrategy: 'appVersion',
  build: bare({ enableHermes: true }),
  storage: r2Storage({
    bucketName: process.env.HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME!,
    accountId: process.env.HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID!,
    credentials: {
      accessKeyId: process.env.HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID!,
      secretAccessKey: process.env.HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY!,
    },
  }),
  database: d1Database({
    databaseId: process.env.HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID!,
    accountId: process.env.HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID!,
    cloudflareApiToken: process.env.HOT_UPDATER_CLOUDFLARE_API_TOKEN!,
  }),
});
```

---

## Bước 6: Tạo giao diện Dev Channel Switcher cho QA

Tạo component **[DevChannelSwitcher.tsx](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/src/components/DevChannelSwitcher.tsx)** hiển thị nút Floating Button cứu hộ (🔥).

Component này gọi đúng API của client SDK `@hot-updater/react-native` để:
* **Đọc kênh hiện tại:** `HotUpdater.getChannel()` (trả về kết quả đồng bộ).
* **Reset kênh về staging mặc định:** `await HotUpdater.resetChannel()`.
* **Chuyển kênh qua cập nhật:** Gọi `HotUpdater.checkForUpdate({ channel: targetChannel })` để kiểm tra bản cập nhật trên kênh đích và tải bundle tương ứng về máy rồi reload.

---

## Bước 7: Tích hợp vào Entrypoint của ứng dụng

Cập nhật file **[App.tsx](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/App.tsx)** để bọc ứng dụng:

```typescript
import React from 'react';
import { StatusBar, StyleSheet, useColorScheme, View } from 'react-native';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { NewAppScreen } from '@react-native/new-app-screen';
import Config from 'react-native-config';
import { HotUpdater } from '@hot-updater/react-native';
import DevChannelSwitcher from './src/components/DevChannelSwitcher';

const isDevMode = Config.DEVELOPMENT_MODE === 'true';
const isHotUpdateEnabled = Config.HOT_UPDATER_ENABLED === 'true';

function MainApp() {
  const isDarkMode = useColorScheme() === 'dark';
  const safeAreaInsets = useSafeAreaInsets();

  return (
    <View style={styles.container}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      <NewAppScreen templateFileName="App.tsx" safeAreaInsets={safeAreaInsets} />
      {/* Dev Channel Switcher chỉ hiển thị ở Staging/Dev */}
      {isDevMode && <DevChannelSwitcher />}
    </View>
  );
}

function MainAppWrapper() {
  return (
    <SafeAreaProvider>
      <MainApp />
    </SafeAreaProvider>
  );
}

const HotUpdatedApp = HotUpdater.wrap({
  baseURL: Config.HOT_UPDATER_BASE_URL || '',
  updateStrategy: 'appVersion',
  updateMode: 'auto',
})(MainAppWrapper);

export default function App() {
  if (!isHotUpdateEnabled) {
    return <MainAppWrapper />;
  }
  return <HotUpdatedApp />;
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});
```

---

## Bước 8: Bổ sung cấu hình kiểu dữ liệu TypeScript

Cập nhật **[tsconfig.json](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/tsconfig.json)** để nạp kiểu dữ liệu của Node.js vào phạm vi biên dịch toàn cục (sửa lỗi thiếu đối tượng `process`):

```json
  "compilerOptions": {
    "types": ["jest", "node"]
  }
```

---

## Bước 9: Tạo script lấy phiên bản động và cấu hình các script trong package.json

1. **Tạo file helper `scripts/get-version.js` ở thư mục gốc:**
   Tạo file **[scripts/get-version.js](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/scripts/get-version.js)** để trích xuất an toàn phiên bản từ các file `.env`:
   ```javascript
   const fs = require('fs');
   const path = require('path');

   const envFile = process.argv[2] || '.env.staging';
   try {
     const envPath = path.resolve(process.cwd(), envFile);
     if (!fs.existsSync(envPath)) {
       console.error(`Error: File ${envFile} not found`);
       process.exit(1);
     }

     const content = fs.readFileSync(envPath, 'utf8');
     const line = content.split('\n').find(l => l.startsWith('ANDROID_VERSION_NAME='));
     if (!line) {
       console.error(`Error: ANDROID_VERSION_NAME not found in ${envFile}`);
       process.exit(1);
     }

     const version = line.split('=')[1].replace(/['"\r]/g, '').trim();
     console.log(version);
   } catch (error) {
     console.error('Error reading version:', error);
     process.exit(1);
   }
   ```

2. **Cập nhật package.json:**
   Cập nhật **[package.json](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/package.json)** để khai báo các câu lệnh chạy local theo flavor và deploy OTA tự động (sử dụng file helper ở trên):
   ```json
     "scripts": {
       ...
       "aos:dev": "ENVFILE=.env.development react-native run-android --mode=developmentDebug --appIdSuffix=dev",
       "aos:stg": "ENVFILE=.env.staging react-native run-android --mode=stagingDebug --appIdSuffix=stg",
       "aos:prod": "ENVFILE=.env.production react-native run-android --mode=productionRelease",
       "hot:console": "npx hot-updater console",
       "hot:stg:ios": "ENVFILE=.env.staging npx hot-updater deploy -p ios -t $(node scripts/get-version.js .env.staging) --channel stg",
       "hot:stg:android": "ENVFILE=.env.staging npx hot-updater deploy -p android -t $(node scripts/get-version.js .env.staging) --channel stg",
       "hot:stg": "npm run hot:stg:ios && npm run hot:stg:android",
       "hot:task:ios": "ENVFILE=.env.staging npx hot-updater deploy -p ios -t $(node scripts/get-version.js .env.staging) --channel",
       "hot:task:android": "ENVFILE=.env.staging npx hot-updater deploy -p android -t $(node scripts/get-version.js .env.staging) --channel",
       "hot:prod:ios": "ENVFILE=.env.production npx hot-updater deploy -p ios -t $(node scripts/get-version.js .env.production) --channel production",
       "hot:prod:android": "ENVFILE=.env.production npx hot-updater deploy -p android -t $(node scripts/get-version.js .env.production) --channel production",
       "ci:check-native": "node scripts/check-native-changes.js"
     }
   ```

---

## Bước 10: Thiết lập luồng kiểm soát GitLab CI/CD

1. Tạo script kiểm tra Native changes **[scripts/check-native-changes.js](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/scripts/check-native-changes.js)**.
2. Tạo file cấu hình pipeline **[.gitlab-ci.yml](file:///home/gmo/Documents/Learning/LearnJS/react-native-migration-project/ReactNativeCli0860v4/.gitlab-ci.yml)** sử dụng `image: node:22`.

---

## Kết quả kiểm tra biên dịch (Validation Results)

Dự án đã được kiểm thử kiểu dữ liệu TypeScript thành công bằng lệnh:
```bash
npx tsc --noEmit
```
* **Kết quả:** Lệnh hoàn thành thành công với **Exit Code 0** (Không có bất kỳ lỗi biên dịch hay kiểu dữ liệu nào trong dự án).
* Dự án sẵn sàng chạy thử và build trên các thiết bị mô phỏng.
