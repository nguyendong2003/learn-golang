# BÁO CÁO PHÂN TÍCH: GIẢI PHÁP TÍCH HỢP GITLAB CI/CD VỚI CLOUDFLARE OTA (HOT-UPDATER) TRONG DỰ ÁN COLLABORATION (BA & DEVELOPER)

Báo cáo này đề xuất giải pháp tối ưu hóa luồng phối hợp làm việc (Collaboration Workflow) giữa **Business Analyst (BA)** và **Developer (Dev)** trên một mã nguồn dự án React Native, tích hợp hệ thống **OTA Hot-Updater (Cloudflare Workers/D1/R2)** và tự động hóa qua **GitLab CI/CD**.

---

## 1. PHÂN TÍCH BÀI TOÁN & THÁCH THỨC

Dự án mobile hiện tại có sự tham gia của 3 vai trò chính trong vòng đời phát triển giao diện:
1. **BA (Business Analyst):** Đọc code để viết tài liệu Detail Design (DD) hoặc tự tay tạo các trang mẫu (Prototype) trực quan (chưa có logic nghiệp vụ phức tạp hay gọi API thực tế) và đẩy lên nhánh phụ để TL (Team Lead) duyệt.
2. **TL (Team Lead) / Senior Mobile Dev:** Đánh giá tính khả thi kỹ thuật, duyệt code Prototype của BA trước khi ghép nối vào luồng phát triển chính thức.
3. **Developer (Dev):** Tiếp nhận màn hình Prototype đã được duyệt, hoàn thiện mã nguồn bằng cách thêm logic xử lý nghiệp vụ, xử lý state, gọi API (Mapping API), vá lỗi và kiểm thử đơn vị, sau đó merge vào nhánh chính thức để build ứng dụng.

### Các vấn đề phát sinh khi có nhiều BA và Dev cùng làm việc:
* **Xung đột phiên bản (Version Conflicts):** Nhiều BA và Dev tạo ra các Pull Request / Merge Request (MR) song song. Nếu không phân luồng rõ ràng, các bản cập nhật OTA sẽ đè lên nhau, gây lỗi giao diện hoặc mất code.
* **Review phức tạp:** TL và BA cần xem thử giao diện thực tế trên thiết bị thật trước khi merge MR. Nếu chỉ dùng một kênh OTA chung (`stg` hoặc `production`), việc cập nhật một MR này sẽ làm gián đoạn việc kiểm thử của MR khác.
* **Xử lý MR không tuần tự (Out-of-order & Skip/Revert):** Không phải MR nào cũng được merge theo thứ tự tạo ra. Có những tính năng bị hủy bỏ (Revert), tạm hoãn (Skip), hoặc đẩy nhanh tiến độ (Fast-track) vượt trước các tính năng khác.
* **Phiên bản Native lỗi thời:** Một số thay đổi giao diện hoặc logic của BA/Dev có thể đi kèm với việc cài đặt thêm thư viện chứa mã Native (Android/iOS). Nếu thiết bị đang chạy shell Native cũ tải OTA mới chứa thư viện Native đó, ứng dụng sẽ bị crash ngay lập tức.

---

## 2. KIẾN TRÚC MÔ HÌNH NHÁNH (GIT BRANCHING MODEL)

Để giải quyết triệt để sự xung đột và tối ưu hóa luồng làm việc, chúng tôi đề xuất mô hình phân nhánh Git như sau:

```mermaid
gitGraph
    commit id: "Initial"
    branch ba-prototype
    branch develop
    checkout ba-prototype
    commit id: "Base Prototype"
    branch ba/feature-A
    checkout ba/feature-A
    commit id: "BA: Proto Page A"
    checkout ba-prototype
    merge ba/feature-A id: "TL Merge Proto A" tag: "OTA: prototype"
    checkout develop
    commit id: "Base Dev APIs"
    branch feature/api-A
    checkout feature/api-A
    merge ba-prototype id: "Merge Proto A to Dev Branch"
    commit id: "Dev: Add Logic & API A"
    checkout develop
    merge feature/api-A id: "Merge Feature A to Dev" tag: "OTA: staging"
    checkout main
    merge develop id: "Release 1.0.0" tag: "OTA: production"
```

### Chi tiết vai trò của từng nhánh:

| Tên Nhánh | Đối Tượng Sử Dụng | Mục Đích | Kênh OTA Tương Ứng (Cloudflare) |
| :--- | :--- | :--- | :--- |
| **`main`** | Toàn bộ Team (TL release) | Chứa mã nguồn ổn định nhất đang chạy ngoài thực tế. | **`production`** |
| **`develop`** | Developers & QA | Tích hợp mã nguồn của các Developer sau khi hoàn thiện logic/API. QA test trên nhánh này. | **`staging`** |
| **`ba-prototype`** | BAs & Team Lead | Tích hợp các trang Prototype do BA xây dựng sau khi được TL duyệt qua MR. | **`prototype`** |
| **`ba/proto-[feature]`** | Từng BA riêng lẻ | Nhánh tính năng của BA để viết Prototype màn hình. | Nhánh riêng (OTA qua **Dynamic Channel**) |
| **`feature/[feature]`** | Từng Developer riêng lẻ | Nhánh tính năng của Dev, tách ra từ `develop` mới nhất, sau đó merge giao diện từ `ba-prototype` hoặc nhánh BA tương ứng để hoàn thiện logic/API. | Nhánh riêng (OTA qua **Dynamic Channel**) |

---

## 3. CHIẾN LƯỢC KÊNH OTA (CLOUDFLARE CHANNEL STRATEGY)

Hệ thống `hot-updater` cho phép chúng ta deploy mã nguồn lên các **Kênh (Channels)** khác nhau. Chúng ta tận dụng tính năng này để phân tách môi trường kiểm thử:

### 3.1. Các Kênh OTA Tĩnh (Static Channels)
Các kênh này tương ứng trực tiếp với các nhánh chính trên Git:
1. **`production` (Nhánh `main`):** Bản chính thức dành cho người dùng cuối. 
2. **`staging` (Nhánh `develop`):** Dành cho QA chạy hồi quy (Regression Test) các tính năng đã hoàn thiện logic và API.
3. **`prototype` (Nhánh `ba-prototype`):** Dành cho BA, PO (Product Owner) xem trước các trang thiết kế mẫu để đối chiếu với tài liệu Detail Design trước khi bàn giao cho Dev.

### 3.2. Các Kênh OTA Động (Dynamic Channels - MR Previews)
Mỗi khi BA hoặc Dev tạo một Merge Request (MR) trên GitLab (ví dụ: MR số `105`), hệ thống GitLab CI/CD sẽ tự động triển khai một bản build OTA lên một kênh động tên là: **`mr-105`**.
* **Mục đích:** TL có thể mở trực tiếp điện thoại lên, chuyển sang kênh `mr-105` để xem thử giao diện và trải nghiệm ứng dụng của MR đó trên thiết bị thật trước khi nhấn nút "Merge" trên GitLab.
* **Thời gian tồn tại:** Kênh này sẽ bị vô hiệu hóa hoặc xóa thông tin khỏi database D1 khi MR tương ứng được Merge hoặc Close.

---

## 4. GIẢI PHÁP CHUYỂN ĐỔI KÊNH LINH HOẠT (DEVELOPER MENU / CHANNEL SWITCHER)

Để BA, TL, QA có thể tự do chuyển đổi giữa các phiên bản giao diện mà không cần phải cài lại file APK/IPA nhiều lần, chúng ta sẽ xây dựng một **Channel Switcher** nằm trong ứng dụng (chỉ hiển thị ở phiên bản build thử nghiệm Debug/Staging, bị ẩn ở bản Production).

### 4.1. Cách hoạt động của API `hot-updater`
Dựa trên cấu trúc SDK `@hot-updater/react-native` đã phân tích, chúng ta có thể sử dụng các hàm sau để thực hiện chuyển kênh trực tiếp tại runtime:
* `HotUpdater.getChannel()`: Lấy kênh hiện tại app đang subscribe.
* `HotUpdater.getDefaultChannel()`: Lấy kênh mặc định cấu hình cứng ban đầu (ví dụ: `stg`).
* `HotUpdater.isChannelSwitched()`: Kiểm tra xem app có đang chạy ở chế độ ghi đè kênh hay không.
* `HotUpdater.checkForUpdate({ channel: selectedChannel })`: Yêu cầu kiểm tra bản cập nhật trên kênh cụ thể.
* `HotUpdater.updateBundle({ ... })`: Tải và cài đặt bundle.
* `HotUpdater.reload()`: Khởi động lại bundle JS để áp dụng giao diện mới.
* `HotUpdater.resetChannel()`: Xoá ghi đè kênh, quay về kênh mặc định ban đầu.

### 4.2. Code mẫu tích hợp Component chọn Channel (React Native)

Chúng ta có thể thêm một góc ẩn (ví dụ: gõ 5 lần vào góc trên bên phải màn hình) để mở bảng điều khiển Developer:

```tsx
import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Modal, TextInput, StyleSheet, ActivityIndicator, Alert } from 'react-native';
import { HotUpdater } from '@hot-updater/react-native';

export function DevChannelSelector() {
  const [visible, setVisible] = useState(false);
  const [currentChannel, setCurrentChannel] = useState('production');
  const [customChannel, setCustomChannel] = useState('');
  const [loading, setLoading] = useState(false);
  const [statusText, setStatusText] = useState('');

  useEffect(() => {
    // Lấy kênh đang hoạt động
    const activeChannel = HotUpdater.getChannel();
    setCurrentChannel(activeChannel || 'production');
  }, [visible]);

  const handleSwitchChannel = async (channelName: string) => {
    if (!channelName) return;
    setLoading(true);
    setStatusText(`Đang kiểm tra kênh: ${channelName}...`);

    try {
      // 1. Kiểm tra bản cập nhật trên kênh đích
      const updateInfo = await HotUpdater.checkForUpdate({
        channel: channelName,
        updateStrategy: 'appVersion',
      });

      if (!updateInfo) {
        setLoading(false);
        Alert.alert('Thông báo', `Kênh "${channelName}" không có bản cập nhật mới hoặc không tồn tại.`);
        return;
      }

      // 2. Tải và cài đặt Bundle mới
      setStatusText('Đang tải bản cập nhật mới...');
      const success = await updateInfo.updateBundle();

      if (success) {
        setStatusText('Tải thành công! Đang khởi động lại app...');
        setTimeout(async () => {
          await HotUpdater.reload();
        }, 1000);
      } else {
        setLoading(false);
        Alert.alert('Lỗi', 'Không thể áp dụng bản cập nhật OTA.');
      }
    } catch (error: any) {
      setLoading(false);
      Alert.alert('Lỗi kết nối', error.message || 'Không thể kiểm tra cập nhật.');
    }
  };

  const handleResetToDefault = async () => {
    setLoading(true);
    setStatusText('Đang khôi phục về kênh mặc định...');
    try {
      const ok = await HotUpdater.resetChannel();
      if (ok) {
        setStatusText('Khôi phục thành công! Đang khởi động lại...');
        setTimeout(async () => {
          await HotUpdater.reload();
        }, 1000);
      } else {
        setLoading(false);
        Alert.alert('Lỗi', 'Không thể reset kênh.');
      }
    } catch (e) {
      setLoading(false);
      Alert.alert('Lỗi', 'Có lỗi xảy ra khi reset kênh.');
    }
  };

  return (
    <>
      {/* Nút bấm ẩn ở góc màn hình để mở (Dành cho Tester/BA/TL) */}
      <TouchableOpacity 
        style={styles.floatingTrigger}
        onLongPress={() => setVisible(true)}
      >
        <Text style={styles.triggerText}>⚙️ Dev</Text>
      </TouchableOpacity>

      <Modal visible={visible} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Cấu Hình Kênh OTA (Hot-Updater)</Text>
            
            <Text style={styles.channelLabel}>
              Kênh hiện tại: <Text style={styles.boldText}>{currentChannel}</Text> 
              {HotUpdater.isChannelSwitched() ? ' (Ghi đè)' : ' (Mặc định)'}
            </Text>

            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#007bff" />
                <Text style={styles.statusText}>{statusText}</Text>
              </View>
            ) : (
              <>
                {/* Lựa chọn các Kênh Tĩnh */}
                <Text style={styles.sectionLabel}>Kênh Tĩnh Hệ Thống:</Text>
                <View style={styles.buttonGroup}>
                  {['prototype', 'staging', 'production'].map((ch) => (
                    <TouchableOpacity
                      key={ch}
                      style={[styles.channelBtn, currentChannel === ch && styles.activeBtn]}
                      onPress={() => handleSwitchChannel(ch)}
                    >
                      <Text style={[styles.btnText, currentChannel === ch && styles.activeBtnText]}>{ch}</Text>
                    </TouchableOpacity>
                  ))}
                </View>

                {/* Nhập Kênh Động cho Merge Request */}
                <Text style={styles.sectionLabel}>Nhập Kênh Merge Request (Ví dụ: mr-105):</Text>
                <View style={styles.inputContainer}>
                  <TextInput
                    style={styles.textInput}
                    placeholder="Tên kênh MR hoặc Task"
                    value={customChannel}
                    onChangeText={setCustomChannel}
                    autoCapitalize="none"
                  />
                  <TouchableOpacity
                    style={styles.submitBtn}
                    onPress={() => handleSwitchChannel(customChannel.trim())}
                  >
                    <Text style={styles.submitBtnText}>Switch</Text>
                  </TouchableOpacity>
                </View>

                {/* Reset về mặc định */}
                <TouchableOpacity style={styles.resetBtn} onPress={handleResetToDefault}>
                  <Text style={styles.resetBtnText}>Khôi phục Kênh Mặc Định</Text>
                </TouchableOpacity>

                {/* Đóng Modal */}
                <TouchableOpacity style={styles.closeBtn} onPress={() => setVisible(false)}>
                  <Text style={styles.closeBtnText}>Đóng</Text>
                </TouchableOpacity>
              </>
            )}
          </View>
        </View>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  floatingTrigger: {
    position: 'absolute',
    top: 50,
    right: 10,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    padding: 8,
    borderRadius: 5,
    zIndex: 9999,
  },
  triggerText: { color: '#fff', fontSize: 12, fontWeight: 'bold' },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center' },
  modalContent: { width: '90%', backgroundColor: '#fff', borderRadius: 12, padding: 20, elevation: 5 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15, textAlign: 'center', color: '#333' },
  channelLabel: { fontSize: 14, marginBottom: 15, color: '#666' },
  boldText: { fontWeight: 'bold', color: '#007bff' },
  sectionLabel: { fontSize: 13, fontWeight: 'bold', marginTop: 10, marginBottom: 8, color: '#555' },
  buttonGroup: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 15 },
  channelBtn: { flex: 1, padding: 10, backgroundColor: '#f1f1f1', marginHorizontal: 4, borderRadius: 6, alignItems: 'center' },
  activeBtn: { backgroundColor: '#007bff' },
  btnText: { fontSize: 13, color: '#333' },
  activeBtnText: { color: '#fff', fontWeight: 'bold' },
  inputContainer: { flexDirection: 'row', marginBottom: 15 },
  textInput: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 6, paddingHorizontal: 10, height: 40, marginRight: 8 },
  submitBtn: { backgroundColor: '#28a745', justifyContent: 'center', paddingHorizontal: 15, borderRadius: 6 },
  submitBtnText: { color: '#fff', fontWeight: 'bold' },
  resetBtn: { backgroundColor: '#ffc107', padding: 10, borderRadius: 6, alignItems: 'center', marginVertical: 8 },
  resetBtnText: { color: '#212529', fontWeight: 'bold' },
  closeBtn: { borderHeight: 1, borderColor: '#ccc', padding: 10, borderRadius: 6, alignItems: 'center', marginTop: 8 },
  closeBtnText: { color: '#555' },
  loadingContainer: { padding: 30, alignItems: 'center' },
  statusText: { marginTop: 10, color: '#555', fontStyle: 'italic' },
});
```

---

## 5. THIẾT KẾ PIPELINE GITLAB CI/CD ĐỂ TỰ ĐỘNG HÓA OTA

Hệ thống GitLab CI/CD sẽ tự động chạy biên dịch bundle JS và đẩy lên Cloudflare Workers thông qua `hot-updater` CLI mỗi khi có sự kiện thay đổi mã nguồn.

### 5.1. File cấu hình mẫu `.gitlab-ci.yml`

```yaml
stages:
  - install
  - build_native
  - deploy_ota
  - cleanup_ota

variables:
  NODE_VERSION: "22.11.0"
  TARGET_VERSION: "1.0" # Bắt buộc phải khớp với versionName trong android/app/build.gradle

cache:
  key:
    files:
      - package-lock.json
  paths:
    - node_modules/

# 1. Cài đặt dependencies dự án
install_dependencies:
  stage: install
  image: node:$NODE_VERSION
  script:
    - npm ci
  only:
    - merge_requests
    - ba-prototype
    - develop
    - main

# 2. Tự động build Native APK khi phát hiện có thay đổi mã nguồn Native
build_staging_apk:
  stage: build_native
  image: reactnativecommunity/android-build-tools:latest
  before_script:
    - npm install -g firebase-tools
  script:
    - echo "Phát hiện thay đổi Native. Bắt đầu build Native Shell..."
    - cd ReactNativeCli0860v2
    # Đặt kênh mặc định là stg trước khi biên dịch native shell
    - npx hot-updater channel set stg
    - cd android && ./gradlew clean && ./gradlew assembleRelease
    # Phân phối file APK lên Firebase App Distribution
    - echo "Uploading APK to Firebase App Distribution..."
    - firebase appdistribution:distribute android/app/build/outputs/apk/release/app-release.apk --app "$FIREBASE_ANDROID_APP_ID" --token "$FIREBASE_TOKEN" --groups "testers,bas"
  rules:
    # Chỉ kích hoạt khi có thay đổi trong thư mục native hoặc file quản lý thư viện
    - changes:
        - ReactNativeCli0860v2/android/**/*
        - ReactNativeCli0860v2/package.json
        - ReactNativeCli0860v2/package-lock.json

# 3. Deploy OTA cho Merge Request (Kênh động)
deploy_mr_ota:
  stage: deploy_ota
  image: node:$NODE_VERSION
  script:
    - echo "Đang deploy OTA cho Merge Request $CI_MERGE_REQUEST_IID lên kênh mr-$CI_MERGE_REQUEST_IID"
    # Tạo file credentials từ biến môi trường của GitLab CI/CD
    - echo "HOT_UPDATER_CLOUDFLARE_API_TOKEN=$HOT_UPDATER_CLOUDFLARE_API_TOKEN" > ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID=$HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME=$HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID=$HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY=$HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID=$HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID" >> ReactNativeCli0860v2/.env.hotupdater
    # Chạy deploy lên kênh động mr-xx
    - cd ReactNativeCli0860v2
    - npx hot-updater deploy -p android -t "$TARGET_VERSION" --channel "mr-$CI_MERGE_REQUEST_IID"
  only:
    - merge_requests

# 4. Deploy OTA cho BA Prototype (Kênh prototype)
deploy_prototype_ota:
  stage: deploy_ota
  image: node:$NODE_VERSION
  script:
    - echo "Đang deploy OTA cho BA Prototype lên kênh prototype"
    - echo "HOT_UPDATER_CLOUDFLARE_API_TOKEN=$HOT_UPDATER_CLOUDFLARE_API_TOKEN" > ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID=$HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME=$HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID=$HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY=$HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID=$HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - cd ReactNativeCli0860v2
    - npx hot-updater deploy -p android -t "$TARGET_VERSION" --channel "prototype"
  only:
    - ba-prototype

# 5. Deploy OTA cho Developers & QA (Kênh staging)
deploy_staging_ota:
  stage: deploy_ota
  image: node:$NODE_VERSION
  script:
    - echo "Đang deploy OTA lên kênh staging"
    - echo "HOT_UPDATER_CLOUDFLARE_API_TOKEN=$HOT_UPDATER_CLOUDFLARE_API_TOKEN" > ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID=$HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME=$HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID=$HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY=$HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID=$HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - cd ReactNativeCli0860v2
    - npx hot-updater deploy -p android -t "$TARGET_VERSION" --channel "stg"
  only:
    - develop

# 6. Deploy OTA Production chính thức (Kênh production)
deploy_production_ota:
  stage: deploy_ota
  image: node:$NODE_VERSION
  script:
    - echo "Đang deploy OTA lên kênh production"
    - echo "HOT_UPDATER_CLOUDFLARE_API_TOKEN=$HOT_UPDATER_CLOUDFLARE_API_TOKEN" > ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID=$HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME=$HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID=$HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY=$HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY" >> ReactNativeCli0860v2/.env.hotupdater
    - echo "HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID=$HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID" >> ReactNativeCli0860v2/.env.hotupdater
    - cd ReactNativeCli0860v2
    - npx hot-updater deploy -p android -t "$TARGET_VERSION" --channel "production"
  only:
    - main

# 7. Cleanup các Kênh động khi Merge Request bị đóng hoặc merge
cleanup_mr_channel:
  stage: cleanup_ota
  image: node:$NODE_VERSION
  variables:
    GIT_STRATEGY: none
  script:
    - echo "Dọn dẹp kênh động mr-$CI_MERGE_REQUEST_IID"
    # Gọi D1 SQL (qua wrangler hoặc Cloudflare API) để xoá thông tin channel hoặc set inactive
    # wrangler d1 execute <db-name> --command="DELETE FROM channels WHERE name = 'mr-$CI_MERGE_REQUEST_IID'"
  when: on_success
  only:
    - merge_requests
```

---

## 6. QUẢN LÝ REVERT VÀ TRÁNH XUNG ĐỘT (ROLLBACK & CONFLICT MANAGEMENT)

Khi có quá nhiều BA và Dev cùng thao tác, các thay đổi mã nguồn (commits) có thể không tuần tự hoặc xảy ra lỗi cần huỷ bỏ. Chúng ta xử lý bằng các phương pháp sau:

### 6.1. Nguyên tắc Revert/Skip Code bằng Git (Khuyên dùng cho Code chính)
* Không dùng phương pháp thay đổi trực tiếp file nén trên Cloudflare mà không đồng bộ Git. 
* Khi muốn hủy bỏ (Revert) một bản cập nhật:
  1. Tiến hành chạy lệnh `git revert [commit_hash]` trên local.
  2. Tạo Merge Request đưa code revert đó vào nhánh chính tương ứng (`ba-prototype` hoặc `develop`).
  3. Khi code revert được merge, GitLab CI/CD sẽ tự động build một bundle mới sạch hơn và upload lên Cloudflare với số **`bundleId` lớn hơn**.
  4. Client app khi mở lên sẽ thấy phiên bản mới lớn hơn (thực chất chứa code cũ đã revert) và tự động tải về cài đặt. Đây là cách **Rollforward** an toàn nhất, đảm bảo tính nhất quán giữa Git và Server.

### 6.2. Thực hiện Rollback bằng cách Vô hiệu hóa (Disable) trên Console hoặc dùng CLI

Trong `hot-updater`, cơ chế **Rollback** không được thiết kế dưới dạng một nút bấm có tên "Rollback" riêng biệt, mà được thực hiện bằng cách **vô hiệu hóa (Disable) phiên bản bị lỗi**. Khi phiên bản lỗi nhất bị vô hiệu hóa, Cloudflare Worker sẽ tự động bỏ qua nó và tìm đến phiên bản hoạt động bình thường kế trước đó.

#### Cách 1: Thao tác trên Giao diện Web Console (npm run hot:console)
1. Trong danh sách các phiên bản, **Click chọn vào phiên bản lỗi mới nhất** (ví dụ: `019fa83e-3d16-775d-9bef-0aaaa4db4a61` trong ảnh của bạn) để mở thanh chi tiết **Bundle Detail** ở cạnh phải màn hình.
2. Tại thanh chi tiết, tìm công tắc **Enabled** (đang có màu cam).
3. **Gạt công tắc Enabled sang OFF (màu xám)** để vô hiệu hóa phiên bản lỗi này.
4. Nhấn nút **Save Changes** ở ngay dưới để lưu cấu hình vào Cloudflare D1.

> [!NOTE]
> Sau khi bạn nhấn lưu, trong danh sách bundle, cột `ENABLED` của phiên bản lỗi đó sẽ mất dấu check xanh. 
> Khi client app thực hiện kiểm tra bản cập nhật, Cloudflare Worker sẽ lấy phiên bản **Enabled** mới nhất còn lại. Nếu thiết bị của người dùng đã lỡ cài phiên bản lỗi đó trước đó, SDK ở Client sẽ phát hiện ra phiên bản hiện tại lớn hơn phiên bản khả dụng trên server và tự động thực hiện tiến trình **`ROLLBACK`** để hạ cấp về phiên bản cũ an toàn.

#### Cách 2: Sử dụng dòng lệnh CLI (Nhanh nhất)
Thay vì mở trình duyệt, Team Lead có thể chạy trực tiếp lệnh sau để roll back phiên bản lỗi mới nhất của một kênh cụ thể:
```bash
# Cấu trúc: npx hot-updater rollback <tên-kênh> -p <nền-tảng>
# Ví dụ: Rollback hệ điều hành Android trên kênh stg
npx hot-updater rollback stg -p android
```
Lệnh này sẽ tự động kết nối D1 Database, tìm bản build đang hoạt động mới nhất trên kênh `stg` của Android và chuyển trạng thái `enabled` của nó thành `false`.

```mermaid
flowchart TD
    A[Phát hiện lỗi nghiêm trọng trên Production] --> B{Lựa chọn cách xử lý}
    B -- Dùng Git --> C[Git Revert -> Commit -> CI/CD build Bundle mới (Rollforward)]
    B -- Dùng Console --> D[Click Bundle lỗi -> Tắt Enabled -> Save Changes]
    B -- Dùng CLI --> E[Chạy lệnh: npx hot-updater rollback channel -p platform]
    D --> F[Client App tự động nhận diện & hạ cấp về bản cũ (Rollback)]
    E --> F
```

---

## 7. QUY TRÌNH HỢP TÁC CHI TIẾT (STEP-BY-STEP WORKFLOW)

Dưới đây là sơ đồ phối hợp thực tế hàng ngày:

```
[BA] -- Tạo prototype trên nhánh ba/proto-A --> [GitLab MR] -- (Tự động OTA mr-X) --> [TL/BA duyệt trên máy thật]
                                                                        |
[develop] <-- Merge và OTA staging <-- [Dev hoàn thiện logic/API] <-- [TL Merge vào ba-prototype]
    |
[main] <-- Merge và OTA production
```

### Bước 1: BA thiết kế Prototype và viết DD
* BA kéo code từ nhánh `ba-prototype` mới nhất.
* Viết tài liệu Detail Design (DD) dựa trên code hiện tại.
* Tạo thêm màn hình Prototype tĩnh trên nhánh `ba/proto-login`.
* Đẩy code lên GitLab và tạo Merge Request (MR) vào nhánh `ba-prototype`.
  > [!NOTE]
  > Nếu MR này có thay đổi về Native (ví dụ: cài đặt thêm thư viện mới trong `package.json`), GitLab CI/CD sẽ tự động chạy Job build ra file APK/IPA thử nghiệm mới, đẩy lên Firebase App Distribution và gửi link tải về kênh chat (Zalo/Slack). BA/Tester cần tải và cập nhật bản cài đặt Native này trước khi test. Nếu chỉ sửa file JS/TS, họ bỏ qua bước này.

### Bước 2: Duyệt Prototype
* GitLab CI/CD bắt được MR, tự động chạy đóng gói OTA và đẩy lên Cloudflare Workers tại channel `mr-105` (nếu MR id là 105).
* BA và TL mở **Staging App** (bản cài vật lý đã có sẵn trên điện thoại), mở **DevChannelSelector** lên, gõ `mr-105` và bấm **Switch**.
* Ứng dụng tự reload và hiển thị giao diện BA vừa thiết kế. TL thực hiện đánh giá trực quan. Nếu OK, TL nhấn nút **Approve & Merge** trên GitLab để đưa code vào nhánh `ba-prototype`. Kênh `prototype` của hệ thống lúc này cũng được tự động cập nhật bản này.

### Bước 3: Dev triển khai Logic & API
* Developer nhận task làm logic cho màn hình này.
* Dev tạo nhánh `feature/logic-login` tách ra từ nhánh `develop` mới nhất (nhánh chứa cấu trúc nền tảng và các tích hợp API thực tế của dự án).
* Chạy lệnh `git merge ba-prototype` (hoặc merge trực tiếp từ nhánh `ba/proto-login` của BA) vào nhánh `feature/logic-login` để mang giao diện Prototype đã duyệt vào môi trường phát triển logic.
* Tiến hành viết logic xử lý, validate form, kết nối API và viết test.
* Sau khi xong, Dev đẩy code lên GitLab và tạo MR vào nhánh `develop`.
  > [!NOTE]
  > Tương tự bước 1, nếu Dev có cài thêm thư viện Native mới, GitLab CI/CD sẽ tự động build file APK/IPA mới để cập nhật cho BA/Tester qua Firebase App Distribution. BA/Tester cần tải và cài đặt đè bản mới này trước khi tiến hành test ở Bước 4.

### Bước 4: Test Staging & Release
* Khi QA xác nhận MR của Dev hoạt động tốt, TL merge code vào nhánh `develop`.
* GitLab CI/CD tự động deploy OTA lên kênh `staging`. QA mở Staging App, chuyển sang kênh `staging` để chạy test hồi quy tổng thể.
* Cuối cùng, khi đến ngày Release, TL merge `develop` vào `main`. Pipeline tự động deploy OTA lên kênh `production`. Tất cả người dùng cuối sẽ nhận được tính năng mới sau 2 lần mở app.

---

## 8. CHIẾN LƯỢC PHÂN PHỐI BẢN APP CHO BA / TESTER (APP DISTRIBUTION)

Để tối ưu hóa luồng làm việc, BAs và Testers **không cần tự thiết lập môi trường lập trình hay build code trên máy tính**. Chúng ta chia sản phẩm thành **2 phiên bản Native Shell (Bản cài vật lý)** riêng biệt:

1. **Bản App Thử Nghiệm (Staging/Beta Shell):** Dành cho BA, Tester và TL. Bản này cài đặt một lần duy nhất, **tích hợp bộ chuyển kênh `DevChannelSelector`** để chuyển đổi và tải các bản cập nhật JS Bundle khác nhau từ Cloudflare trong 3 giây.
2. **Bản App Chính Thức (Production App):** Dành cho người dùng cuối trên App Store/CH Play. Bản này khóa cứng kênh `production` và loại bỏ hoàn toàn bộ chuyển kênh Dev để đảm bảo bảo mật.

### 8.1. Nơi lưu trữ file build APK/IPA (Distribution Hosts)
Tuyệt đối **không đưa các file build APK/IPA vật lý lên Git** (vì dung lượng file binary rất lớn). Các file này sẽ được CI/CD tự động upload lên các dịch vụ lưu trữ/phân phối chuyên dụng sau:
* **Firebase App Distribution (Khuyên dùng cho cả Android & iOS):**
  * **Cách hoạt động:** Hoàn toàn miễn phí. Sau khi GitLab CI/CD build xong file APK/IPA, nó sẽ sử dụng Firebase CLI để đẩy trực tiếp file lên Firebase Console.
  * **Cách tải về:** Hệ thống tự động gửi email thông báo có phiên bản mới đến các thành viên trong nhóm (BA/Tester). BA/Tester chỉ cần mở link tải nội bộ trên điện thoại, đăng nhập email là có thể tải xuống và cài đặt (đối với Android) hoặc thông qua app TestFlight (đối với iOS).
* **Cloudflare R2 Bucket (Tự host link tải tiện ích):**
  * **Cách hoạt động:** Tận dụng chính Bucket R2 sẵn có. Pipeline upload file APK lên một thư mục riêng biệt (ví dụ: `r2://app-shells/staging-latest.apk`).
  * **Cách tải về:** Tạo một trang web HTML tĩnh cực kỳ đơn giản chứa mã QR code dẫn thẳng tới link tải file APK này trên R2. BA/Tester chỉ cần dùng camera điện thoại quét mã QR là tự động tải và cài đặt đè lên bản cũ.

### 8.2. Luồng kích hoạt Build Native Shell chạy ở đâu và thuộc bước nào?
Luồng build native shell vật lý này được tự động hóa hoàn toàn và được quy hoạch chặt chẽ nhằm tiết kiệm tài nguyên build:
* **Luồng chạy ở đâu và Khi nào?**
  * Chạy tự động trong **GitLab CI/CD**.
  * Để tiết kiệm thời gian (build native mất 15-20 phút, trong khi build JS OTA chỉ mất 1-2 phút), Pipeline sẽ sử dụng quy tắc `rules:changes` để **chỉ kích hoạt job build APK/IPA khi phát hiện có thay đổi mã nguồn Native**:
    * Có thay đổi trong thư mục `android/` hoặc `ios/`.
    * Có thay đổi trong file quản lý thư viện `package.json`, `package-lock.json`, `Podfile.lock` (báo hiệu có cài thêm thư viện npm mới có chứa mã native).
  * Nếu các MR chỉ thay đổi file JS/TS thông thường, GitLab CI/CD sẽ tự động **bỏ qua** việc build native và chỉ chạy cập nhật JS Bundle lên Cloudflare OTA.
* **Nằm ở bước nào trong quy trình phối hợp?**
  * Đây là **Bước đồng bộ Native (Native Sync/Bootstrap)**, diễn ra trước khi kiểm thử:
    1. **Dev cài thêm thư viện Native mới** (ví dụ: thư viện Bluetooth) -> Tạo MR.
    2. **GitLab CI/CD tự động build bản APK/IPA mới** -> Upload lên Firebase App Distribution/Cloudflare R2 -> Tự động bắn thông báo kèm link tải về kênh chat (Slack/Zalo/Teams).
    3. **BA/Tester nhận thông báo**, click link tải phiên bản Native Shell mới nhất về điện thoại để cài đè (cập nhật phần native thô).
    4. **Sau khi cài đặt**, BA/Tester tiếp tục sử dụng app này để kiểm thử các tính năng JS tiếp theo thông qua OTA (chọn kênh trên `DevChannelSelector`) mà không cần tải lại file APK/IPA nữa, cho đến khi Dev cập nhật thêm thư viện native mới tiếp theo.

### 8.3. Bảng Quy Hoạch Chi Tiết Theo Giai Đoạn

Để trả lời trực diện câu hỏi của Sếp, dưới đây là bảng phân định rõ ràng về **Bản App**, **Nhánh Git (Branch)**, và **Kênh OTA (Channel)** mà BA và Tester sẽ sử dụng tương ứng trong từng giai đoạn làm việc:

| Đối tượng | Giai đoạn / Mục đích kiểm thử | Bản App (Native) | Nhánh Git (Branch) | Kênh OTA cần chọn (Channel) |
| :--- | :--- | :--- | :--- | :--- |
| **BA** | **Tự kiểm tra Prototype của chính mình** (khi đang làm và trước khi merge) | **Staging/Beta Shell** | Nhánh tính năng cá nhân:<br>`ba/proto-[tên-tính-năng]` | Kênh động của MR:<br>**`mr-[Mã MR]`** (ví dụ: `mr-105`) |
| **BA** | **TL & BA nghiệm thu toàn bộ màn hình Prototype** (sau khi đã được TL duyệt và merge) | **Staging/Beta Shell** | Nhánh tích hợp prototype:<br>`ba-prototype` | Kênh tĩnh hệ thống:<br>**`prototype`** |
| **Tester (QA)** | **Kiểm thử chi tiết code của Dev** (đã hoàn thiện logic & API thực tế, trước khi merge) | **Staging/Beta Shell** | Nhánh tính năng của Dev:<br>`feature/[tên-tính-năng]` | Kênh động của MR:<br>**`mr-[Mã MR]`** (ví dụ: `mr-106`) |
| **Tester (QA)** | **Kiểm thử hồi quy tích hợp hệ thống** (chuẩn bị release sản phẩm) | **Staging/Beta Shell** | Nhánh phát triển chính:<br>`develop` | Kênh tĩnh hệ thống:<br>**`staging`** (hoặc `stg`) |

---

## 9. KẾT LUẬN & DANH SÁCH KHUYẾN NGHỊ ĐỂ TRIỂN KHAI

Để dự án hoạt động trơn tru theo mô hình này, chúng tôi kiến nghị thực hiện các bước sau:

1. **[ ] Cài đặt Module Kênh Mặc Định (Staging Shell):** Build và phân phối cho BA/QA một file cài đặt APK/IPA riêng biệt có chứa component **`DevChannelSelector`** và được thiết lập kênh mặc định là `staging` hoặc `prototype` (`npx hot-updater channel set stg` trước khi build file cài đặt). Bản cài đặt trên Store cho người dùng cuối thì khoá cứng kênh `production` và ẩn `DevChannelSelector`.
2. **[ ] Phân quyền Cloudflare D1/R2:** Thiết lập GitLab CI/CD Variables với API Token của Cloudflare có đủ quyền ghi vào D1 và R2 như tài liệu tích hợp hôm qua.
3. **[ ] Kiểm soát Thư viện Native:** Yêu cầu các thành viên (đặc biệt là BA) **không tự ý cài thêm các thư viện chứa mã native** (các thư viện phải chạy `pod install` hoặc sửa code java/kotlin) mà chưa có sự đồng ý của TL. Nếu có thư viện native mới, **bắt buộc phải build lại file APK/IPA cài đặt (Native Shell)** chứ không thể cập nhật qua OTA.
4. **[ ] Đào tạo Git cho BA:** Hướng dẫn BA sử dụng Git cơ bản (pull, commit, push, tạo MR) thông qua các giao diện trực quan như Sourcetree hoặc VS Code Git Extension để tránh xung đột mã nguồn.
