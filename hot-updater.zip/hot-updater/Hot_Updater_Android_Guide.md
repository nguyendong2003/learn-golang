# Hot Updater — Hướng dẫn triển khai (Android, Cloudflare)

**Phạm vi:** Android trước, iOS bổ sung sau khi có hạ tầng Mac build (Fastlane đã có sẵn, chỉ chưa nối OTA)
**Hạ tầng OTA:** Cloudflare R2 (storage) + Cloudflare D1 (database) — chọn thay vì AWS S3/Postgres vì egress miễn phí, phù hợp khối lượng tải bundle liên tục trong ngày (xem lý do chi tiết ở mục 7)

---

## 1. Tổng quan cơ chế

Hot Updater tách app React Native thành 2 phần:
- **Native shell** (Android APK) — build qua Fastlane như hiện tại, cài qua DeployGate, không đổi
- **JavaScript bundle** — phần code thay đổi hàng ngày, đẩy thẳng lên Cloudflare, app tự tải về và reload, không cần build/cài lại

**Giới hạn quan trọng:** chỉ áp dụng cho thay đổi JavaScript/Assets (hình ảnh, font). Nếu thêm native module mới, sửa `AndroidManifest`, hoặc cập nhật dependency có native code — vẫn phải build lại APK qua Fastlane + DeployGate như bình thường (xem mục 6).

**Khái niệm Channel:** thay vì 1 môi trường staging chung, tạo nhiều "làn đường" riêng:
- `stg` — channel mặc định, phản ánh code nhánh staging chính, toàn team dùng
- `[Tên-task]` — channel tạm thời cho từng task/ticket riêng, ai cần test task nào thì switch sang channel đó ngay trên app đã cài, không cài lại

---

## 2. Setup hạ tầng Cloudflare

### 2.1 Chuẩn bị

- Node.js 20+
- Tài khoản Cloudflare (đăng ký tại [cloudflare.com](https://cloudflare.com) nếu chưa có)
- Cloudflare API Token có quyền **D1 Edit** — tạo tại `https://dash.cloudflare.com/{account-id}/api-tokens`

### 2.2 Cài package

```bash
npm install hot-updater --save-dev
```

### 2.3 Chạy setup tự động

```bash
npx hot-updater init
```

Lệnh này chạy interactive setup, tự động tạo:
- **R2 bucket** (lưu bundle JS + assets)
- **D1 database** (lưu metadata: channel nào đang chạy bundle nào, version nào)
- **Cloudflare Worker** (endpoint để app check update)

Sau khi chạy xong, file `.env.hotupdater` được tạo với các key:

```
HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID=your-account-id
HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME=your-r2-bucket-name
HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID=your-r2-access-key-id
HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY=your-r2-secret-access-key
HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID=your-d1-database-id
HOT_UPDATER_CLOUDFLARE_API_TOKEN=your-api-token
HOT_UPDATER_CLOUDFLARE_WORKER_NAME=your-worker-name
```

**File này chứa credential nhạy cảm — không commit lên GitLab.** Chia sẻ qua kênh bảo mật riêng khi onboard thành viên mới.

### 2.4 File cấu hình được sinh ra tự động

`hot-updater.config.ts`:

```ts
import { bare } from "@hot-updater/bare";
import { d1Database, r2Storage } from "@hot-updater/cloudflare";
import { defineConfig } from "hot-updater";
import { config } from "dotenv";

config({ path: ".env.hotupdater" });

export default defineConfig({
  build: bare({ enableHermes: true }),
  storage: r2Storage({
    bucketName: process.env.HOT_UPDATER_CLOUDFLARE_R2_BUCKET_NAME!,
    accountId: process.env.HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID!,
    credentials: {
      accessKeyId: process.env.HOT_UPDATER_CLOUDFLARE_R2_ACCESS_KEY_ID!,
      secretAccessKey: process.env.HOT_UPDATER_CLOUDFLARE_R2_SECRET_ACCESS_KEY!,
    },
  }),
  database: d1Database({
    databaseId: process.env.HOT_UPDATER_CLOUDFLARE_D1_DATABASE_ID!,
    accountId: process.env.HOT_UPDATER_CLOUDFLARE_ACCOUNT_ID!,
    cloudflareApiToken: process.env.HOT_UPDATER_CLOUDFLARE_API_TOKEN!,
  }),
});
```

---

## 3. Tích hợp vào project React Native (Android)

### 3.1 Wrap App component

```tsx
import { HotUpdater } from "@hot-updater/react-native";

function App() {
  return (
    <View>
      <Text>Hello World</Text>
    </View>
  );
}

export default HotUpdater.wrap({
  baseURL: "https://<your-worker-name>.<your-subdomain>.workers.dev/api/check-update",
  updateStrategy: "appVersion", // hoặc "fingerprint"
  fallbackComponent: ({ progress, status }) => (
    <View style={{ flex: 1, padding: 20, justifyContent: "center", alignItems: "center", backgroundColor: "rgba(0,0,0,0.5)" }}>
      <Text style={{ color: "white", fontSize: 20, fontWeight: "bold" }}>
        {status === "UPDATING" ? "Updating..." : "Checking for Update..."}
      </Text>
      {progress > 0 ? (
        <Text style={{ color: "white", fontSize: 20, fontWeight: "bold" }}>
          {Math.round(progress * 100)}%
        </Text>
      ) : null}
    </View>
  ),
})(App);
```

Khuyến nghị bọc thêm điều kiện `DEVELOPMENT_MODE` để cơ chế OTA chỉ hoạt động trên bản staging/internal testing, không bao giờ chạm vào bản production.

### 3.2 Thêm native code (Android)

File `android/app/src/main/java/com/<ten-app>/MainApplication.kt`:

```kotlin
package com.hotupdaterexample

import android.app.Application
import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactHost
import com.facebook.react.ReactNativeApplicationEntryPoint.loadReactNative
import com.facebook.react.defaults.DefaultReactHost.getDefaultReactHost
import com.hotupdater.HotUpdater

class MainApplication : Application(), ReactApplication {

  override val reactHost: ReactHost by lazy {
    getDefaultReactHost(
      context = applicationContext,
      packageList = PackageList(this).packages,
      jsBundleFilePath = HotUpdater.getJSBundleFile(applicationContext),
    )
  }

  override fun onCreate() {
    super.onCreate()
    loadReactNative(this)
  }
}
```

Điểm mấu chốt: `jsBundleFilePath = HotUpdater.getJSBundleFile(applicationContext)` — thay vì app luôn load bundle đóng gói sẵn trong APK, giờ nó check xem có bundle mới hơn đã tải về từ Cloudflare chưa.

### 3.3 Kiểm tra setup

1. Vào Cloudflare dashboard — xác nhận đã có bucket R2, database D1, worker mới tạo
2. Build APK 1 lần (qua Fastlane như bình thường), cài vào máy test
3. Deploy thử 1 bundle (xem mục 4-5), xác nhận app tự nhận update

---

## 4. Deploy script (`package.json`)

```json
"hot:console":        "npx hot-updater console",
"hot:stg:android":    "ENVFILE=.env.stg npx hot-updater deploy -p android -t \"<app-version>\" --channel stg",
"hot:task:android":   "ENVFILE=.env.stg npx hot-updater deploy -p android -t \"<app-version>\" --channel"
```

Giải thích lệnh deploy:

```
ENVFILE=.env.stg  npx hot-updater deploy  -p android  -t "<app-version>"  --channel stg
│                  │                       │            │                      │
│                  │                       │            │                      └─ Channel nhận bundle
│                  │                       │            └─ Version targeting: chỉ áp dụng app đúng version này
│                  │                       └─ Nền tảng: android
│                  └─ Lệnh deploy Hot Updater CLI
└─ Inject file .env.stg làm config môi trường (API endpoint, feature flags...)
```

**Vì sao cần `ENVFILE`:** bundle JS bake các giá trị từ `.env` vào lúc build — chỉ định đúng file đảm bảo bundle deploy đúng môi trường staging, không lẫn config production.

---

## 5. Quy trình làm việc hàng ngày

### 5.1 Dev deploy 1 task lên channel riêng

```bash
yarn hot:task:android <ten-task>
# ví dụ: yarn hot:task:android V567APP-199
```

- Bundle JS hiện tại ở local được đóng gói và đẩy lên channel `<ten-task>`
- Mất khoảng 1–2 phút, thay vì build lại APK (~15-20 phút)
- Báo QA qua Jira/chat: "Task `<ten-task>` đã deploy lên channel, không cần build lại"

**Lưu ý:** mỗi lần deploy lại cùng 1 channel, bundle cũ bị ghi đè. QA đang ở channel đó chỉ cần đợi app tự tải bundle mới, không cần thao tác gì thêm.

### 5.2 QA switch sang channel cần test

1. Mở app bản staging trên thiết bị
2. Mở Channel Switcher (UI nội bộ, chỉ hiện khi `DEVELOPMENT_MODE=true`)
3. Nhập tên channel (VD: `V567APP-199`) → Switch
4. App tự tải bundle tương ứng và reload

**Lưu ý quan trọng:** phải Reset về channel `stg` mặc định trước khi chuyển sang channel khác — không chuyển thẳng giữa 2 ephemeral channel với nhau.

### 5.3 Release — merge vào staging chính

Sau khi PR được approve và merge vào nhánh staging:

```bash
yarn hot:stg:android
```

Toàn bộ team đang ở channel `stg` sẽ tự nhận bundle mới từ lần mở app tiếp theo.

**Chỉ chạy lệnh này sau khi code đã ổn định trên nhánh staging** — deploy code dở dang lên `stg` sẽ ảnh hưởng toàn team, không chỉ 1 người test.

### 5.4 Dashboard & Rollback

```bash
yarn hot:console
```

Mở giao diện quản lý local, xem toàn bộ channel/bundle đang active, rollback về bundle cũ chỉ bằng vài click nếu phát hiện lỗi sau khi deploy.

---

## 6. Khi nào cần build lại APK qua DeployGate (không dùng Hot Updater được)

Hot Updater chỉ xử lý phần JavaScript/Assets. Các trường hợp sau **bắt buộc quay lại luồng build + DeployGate cũ**:

| Tình huống | Lý do |
|---|---|
| Thêm/xóa native module (thư viện có phần code Kotlin/Java/Swift) | Cần biên dịch lại native shell |
| Sửa `AndroidManifest.xml` (thêm permission, thay đổi cấu hình) | Nằm ngoài phần JS bundle |
| Cập nhật dependency có native code | Tương tự thêm native module |
| Đổi version app một cách chính thức (không phải patch nhỏ) | Cần đồng bộ version targeting của Hot Updater với native shell mới |

**Quy trình khi rơi vào các trường hợp trên:**

1. Build APK qua Fastlane như luồng hiện tại
2. Đẩy build mới lên DeployGate như bình thường
3. QA/team cài lại bản APK mới từ DeployGate
4. Sau khi cài bản APK mới, quay lại dùng Hot Updater cho các thay đổi JS tiếp theo (channel `stg` vẫn giữ nguyên, không cần dựng lại)

Nói cách khác: **DeployGate xử lý "thay vỏ", Hot Updater xử lý "thay ruột"** — 2 luồng chạy song song, không thay thế nhau, chọn đúng luồng theo loại thay đổi.

---

## 7. Vì sao chọn Cloudflare thay vì AWS S3/Postgres

| | Cloudflare R2 + D1 | AWS S3 + RDS Postgres |
|---|---|---|
| Egress (tải bundle) | **Miễn phí, mọi khối lượng** | $0.09/GB sau 100GB free đầu |
| Storage | $0.015/GB/tháng | $0.023/GB/tháng |
| Chi phí database nhỏ | D1 free tier gần như luôn đủ | RDS tính phí instance chạy 24/7 dù data nhỏ |
| Phù hợp use case này | Bundle OTA = egress cao liên tục trong ngày, đúng điểm mạnh R2 | Hợp lý hơn nếu đã có RDS instance dùng chung sẵn cho việc khác |

Với việc dev/QA tải bundle nhiều lần/ngày, và nếu áp dụng chuẩn này cho **nhiều dự án cùng lúc**, egress cộng dồn trên S3 sẽ đáng kể theo thời gian trong khi R2 giữ nguyên $0 — đây là lý do chính chọn Cloudflare cho hạng mục này, khác với các quyết định hạ tầng khác (RunAI, Jira) vốn ưu tiên AWS vì đã có sẵn.

**Lưu ý compliance:** đây là nhà cung cấp ngoài mới (ngoài AWS), nên review qua RMD/Legal nếu áp dụng chuẩn thức — rủi ro thấp vì chỉ chứa JS bundle nội bộ để test, không phải dữ liệu khách hàng.

---

## 8. Lưu ý khi mở rộng

- Khi có hạ tầng Mac build (mục tiêu sau), thêm script `hot:task:ios`/`hot:stg:ios` tương tự — cùng 1 Worker/R2/D1, không cần dựng lại hạ tầng riêng cho iOS, chỉ thêm bước build+sign iOS qua Fastlane
- Nếu áp dụng chuẩn này cho nhiều dự án, cân nhắc 1 Cloudflare Worker + R2 + D1 dùng chung (multi-project, phân biệt bằng prefix bucket/channel) thay vì mỗi dự án tự dựng riêng — tiết kiệm effort DevOps CoE, nhưng cần thiết kế cô lập dữ liệu giữa các dự án ngay từ đầu

---

---

## 9. BA sử dụng Hot Updater để tự chốt spec UI với khách hàng

Áp dụng cho luồng: BA viết spec bằng AI → Dev Agent code UI → BA tự deploy và show trực tiếp cho khách hàng trên điện thoại đã cài sẵn app (không cần khách tự cài, không cần thao tác switch channel phía khách).

### 9.1 Yêu cầu máy BA

| Cần cài | Không cần |
|---|---|
| Node.js (đúng version project, quản lý qua nvm/fnm) | Android Studio |
| Yarn/npm | Android SDK / Emulator |
| Git + SSH key hoặc token truy cập GitLab | Xcode |
| AI coding agent (Cursor/Claude Code) | Toolchain build native bất kỳ |
| File `.env.stg` / `.env.hotupdater` (nhận qua kênh bảo mật, không commit) | |

**Vì sao nhẹ:** lệnh `hot-updater deploy` chỉ chạy Metro bundler (thuần JS trong Node), không đụng tới thư mục `android/`. BA test trực tiếp trên điện thoại đã cài sẵn APK từ trước — không cần emulator, không cần build local.

Việc 1 lần duy nhất trước khi bắt đầu: clone repo, chạy `yarn install`. Sau đó BA chỉ lặp lại chu trình ở mục 9.6.

### 9.2 Điều kiện tiên quyết trước khi BA bắt đầu

- APK native shell phải được build sẵn 1 lần qua Fastlane, đẩy lên DeployGate, và cài trên điện thoại BA từ trước
- Nếu spec ban đầu đã biết cần tính năng native nào đó (camera, GPS, biometric...), phải build đủ native module đó ngay từ bản APK đầu tiên — nếu phát hiện thiếu giữa chừng, phải quay lại build lại qua Fastlane + DeployGate (xem mục 6), mất lợi thế tốc độ của luồng này

### 9.3 Quy tắc quản lý branch — 1 task = 1 branch = 1 channel

- BA tạo branch riêng từ nhánh `develop`/staging cho từng task/màn hình mình phụ trách
- Deploy lên channel cùng tên với branch/task — demo khách hàng luôn chạy đúng từ channel đó, không lẫn code của người khác
- Chỉ merge vào `develop` (rồi mới chạy `hot:stg`) **sau khi khách hàng đã accept** spec, qua GitLab Merge Request — MR cần được duyệt trước khi merge (khác với việc tạo GitLab Issue, không cần duyệt, để giữ tốc độ ở khâu làm việc; bước duyệt chỉ đặt ở khâu hợp nhất code vào nhánh chung)

### 9.4 Tổ chức file để giảm conflict

- **Spec `.md`**: tách theo từng màn hình/tính năng, không dồn chung 1 file lớn nhiều BA cùng sửa — đây là nguồn conflict dễ xảy ra nhất nếu tổ chức sai
- **UI component**: tự nhiên đã tách theo màn hình trong React Native — nếu 2 BA không đụng cùng 1 màn hình, gần như không bao giờ conflict
- **File dùng chung** (navigation config, shared component, theme): rủi ro conflict thật sự nằm ở đây — BA cần báo Technical Lead trước khi sửa, không tự ý thay đổi

### 9.5 Khi xảy ra conflict

BA không tự resolve conflict — escalate thẳng cho Technical Lead. BA không cần thành thạo git để xử lý conflict phức tạp, đúng vai trò đã phân định trong cấu trúc FDE (BA tập trung nghiệp vụ + UI, Technical Lead xử lý kỹ thuật).

### 9.6 Chu trình lặp lại hàng ngày của BA

```
Sửa/viết spec (.md) → Dev Agent code UI → yarn hot:task:android <task>
        ↓
Xem trên điện thoại đã cài sẵn APK, show trực tiếp cho khách hàng
        ↓
Lặp lại đến khi khách hàng accept
        ↓
Tạo Merge Request → Technical Lead/PM duyệt → merge vào develop → yarn hot:stg:android
```

---

## Tài liệu tham khảo

- Bài chia sẻ thực tế (dev.to): [Tích hợp Hot Update vào dự án để tối ưu thời gian cho internal testing](https://dev.to/trng_trnhc_cd88085f/tich-hop-hot-update-vao-du-an-de-toi-uu-thoi-gian-cho-internal-testing-iag)
- GitHub Hot Updater: [github.com/gronxb/hot-updater](https://github.com/gronxb/hot-updater)
- Docs chính thức: [hot-updater.dev](https://hot-updater.dev)
- Setup Cloudflare chi tiết: [hot-updater.dev/docs/managed/cloudflare](https://hot-updater.dev/docs/managed/cloudflare)
