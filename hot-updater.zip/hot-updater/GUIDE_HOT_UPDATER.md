# Hướng Dẫn Từng Bước Tích Hợp OTA Hot Update Bằng `hot-updater` (Android + Cloudflare)

Tài liệu này hướng dẫn chi tiết cách thiết lập cơ chế OTA Hot Update cho dự án React Native CLI hiện có của bạn (`ReactNativeCli0860v2`) sử dụng thư viện **`hot-updater`** kết hợp với hạ tầng **Cloudflare D1, R2, và Workers** theo đúng tiêu chuẩn kỹ thuật trong tài liệu của anh Minh.

---

## 🏗 Tổng Quan Kiến Trúc Luồng Hoạt Động

1. **Client App (`ReactNativeCli0860v2`):** Sử dụng SDK `@hot-updater/react-native` để tự động kiểm tra bản cập nhật và reload JS bundle khi có phiên bản mới.
2. **Cloudflare Worker:** Làm Endpoint API xử lý logic kiểm tra cập nhật (`/api/check-update`).
3. **Cloudflare D1 Database:** Lưu trữ cơ sở dữ liệu metadata về các channel (Staging, Production, Task) và các version bundle đang active.
4. **Cloudflare R2 Bucket:** Lưu trữ file JS bundle và assets tĩnh sau khi đóng gói.
5. **Console Admin:** Giao diện điều khiển chạy local (`npx hot-updater console`) giúp dev/QA quản lý, phân phối hoặc rollback các bundle nhanh chóng.

---

## 🚀 HƯỚNG DẪN TRIỂN KHAI CHI TIẾT

### BƯỚC 1: Chuẩn Bị Tài Khoản Cloudflare

Để chạy công cụ thiết lập tự động, bạn cần chuẩn bị:

1. **Account ID:** Đăng nhập vào Cloudflare Dashboard, Account ID sẽ nằm ở thanh URL hoặc trang chính của Account.
2. **API Token:** Tạo tại [dash.cloudflare.com/profile/api-tokens](https://dash.cloudflare.com/profile/api-tokens) với các quyền sau:
   - **Account > D1 > Edit**
   - **Account > Workers KV Storage > Edit**
   - **Account > Workers Scripts > Edit**
   - **Account > Workers R2 Storage > Edit**

---

### BƯỚC 2: Cài Đặt và Khởi Tạo Hot Updater

Tại thư mục gốc của project `ReactNativeCli0860v2`, thực hiện các bước sau:

1. **Cài đặt thư viện dev dependency:**

   ```bash
   npm install hot-updater --save-dev
   ```

2. **Chạy lệnh thiết lập tự động:**

   ```bash
   npx hot-updater init
   ```

   _Quá trình này là interactive setup (câu hỏi lựa chọn):_
   - **Select a build plugin**: Chọn **Bare** (React Native CLI).
   - **Select a provider**: Chọn **Cloudflare D1 + R2 + Worker**.
   - **Đăng nhập trình duyệt (Wrangler OAuth)**: CLI tự động mở trình duyệt. Nhấn **Allow** để cấp quyền.
   - **Account List**: Nhấn **Enter** chọn tài khoản Cloudflare của bạn.
   - **Enter the D1 API Token**: Dán **API Token** đã tạo ở Bước 1 vào.
   - **R2 List**: Chọn `Create New R2 Bucket` $\rightarrow$ Nhập tên bucket (Ví dụ: `test-hot-updater-bucket`).
   - **Enter the R2 Access Key ID / Secret Access Key**:
     - Truy cập đường dẫn hiển thị trên terminal (hoặc vào Cloudflare Dashboard > **R2** > **Overview** > **Manage R2 API Tokens**).
     - Nhấp chọn **Create Account API token** (Khuyên dùng cho production/CI) hoặc **Create User API token** (Dùng cho cá nhân test) $\rightarrow$ Chọn quyền **Object Read & Write** (hoặc Admin Read & Write) $\rightarrow$ Nhấn Create.
     - Copy **Access Key ID** và **Secret Access Key** được tạo ra (nằm ở mục **"Use the following credentials for S3 clients"**) dán lần lượt vào terminal. (Lưu ý: Không copy phần "Token value" ở trên và các key này chỉ hiển thị một lần duy nhất lúc tạo).
   - **D1 List**: Chọn `Create New D1 Database` $\rightarrow$ Nhập tên DB (Ví dụ: `test-d1-database`).
   - **Apply Migrations**: Khi CLI hỏi `About to apply 5 migration(s) ... continue? (Y/n)`, gõ **Y** rồi nhấn **Enter** để chạy tạo bảng dữ liệu.

   > [!TIP]
   > **Xử lý sự cố thường gặp lúc chạy `init`:**
   >
   > - **Lỗi 10007 (Chưa có subdomain workers.dev)**: Nếu gặp lỗi `You do not have a workers.dev subdomain. Please go to...`, bạn chỉ cần click vào link hiển thị ở terminal (hoặc vào Cloudflare Dashboard > chọn **Workers & Pages** ở menu bên trái). Chỉ cần truy cập trang này lần đầu tiên, Cloudflare sẽ tự động tạo subdomain `workers.dev` cho bạn (hiển thị ở phần Account Details bên phải). Sau đó, quay lại terminal chạy lại lệnh `init` là xong.
   > - **Lỗi R2 403 (Chưa kích hoạt R2)**: Nếu gặp lỗi `Please enable R2 through the Cloudflare Dashboard`, bạn bắt buộc phải đăng nhập Cloudflare Dashboard > R2 và nhấn kích hoạt R2 (yêu cầu điền thẻ Visa/Mastercard để xác minh chống spam, 10GB lưu trữ đầu là hoàn toàn miễn phí).
   > - **Đổi tài khoản Cloudflare trên Terminal**: Nếu CLI tự nhận tài khoản Wrangler cũ đã lưu trên máy, hãy nhấn `Ctrl + C` để hủy lệnh. Sau đó chạy lệnh `npx wrangler logout` để đăng xuất, rồi chạy lại `npx hot-updater init` để đăng nhập tài khoản mới.

3. **Kiểm tra file được tạo ra:**
   - **`.env.hotupdater`:** Chứa toàn bộ thông tin cấu hình Cloudflare và credentials.
     > [!WARNING]
     > File này chứa thông tin bảo mật quan trọng. Bạn phải thêm `.env.hotupdater` vào file `.gitignore` để tránh bị commit lên git repo.
   - **`hot-updater.config.ts`:** File định cấu hình plugin build bundle bare, trỏ các kết nối tới R2 và D1 trên Cloudflare.

---

### BƯỚC 3: Cấu Hình Native Android (Client)

1. **Cài đặt SDK React Native Client:**

   ```bash
   npm install @hot-updater/react-native
   ```

2. **Cấu hình bọc (wrap) Component chính trong `App.tsx`:**
   Mở file entry point của app (ví dụ: `App.tsx` hoặc `App.js`) và thực hiện bọc root component:

   ```tsx
   import { HotUpdater } from '@hot-updater/react-native';

   function App() {
     // Code giao diện hiện tại của bạn
     return (
       <View
         style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}
       >
         <Text>Phiên bản thử nghiệm Hot Update 1.0.0</Text>
       </View>
     );
   }

   // Bọc App Component
   export default HotUpdater.wrap({
     baseURL:
       'https://<your-worker-name>.<your-subdomain>.workers.dev/api/check-update',
     updateStrategy: 'appVersion', // "appVersion" hoặc "fingerprint"
     fallbackComponent: ({ progress, status }) => (
       <View
         style={{
           flex: 1,
           justifyContent: 'center',
           alignItems: 'center',
           backgroundColor: 'rgba(0,0,0,0.7)',
         }}
       >
         <Text style={{ color: 'white', fontSize: 18 }}>
           {status === 'UPDATING'
             ? 'Đang cập nhật mã nguồn...'
             : 'Đang kiểm tra phiên bản mới...'}
         </Text>
         {progress > 0 && (
           <Text style={{ color: 'white', fontSize: 16, marginTop: 10 }}>
             Tiến trình: {Math.round(progress * 100)}%
           </Text>
         )}
       </View>
     ),
   })(App);
   ```

   > [!TIP]
   > **Cách tìm thông tin để điền `baseURL` từ giao diện Cloudflare Workers & Pages:**
   >
   > 1. Truy cập trang quản trị Cloudflare (https://dash.cloudflare.com/), chọn mục **Compute** > **Workers & Pages**.
   > 2. **Tên Worker:** Tên của Worker được hiển thị ở đầu mỗi box (Ví dụ: `test-hot-updater-worker-1`). Bạn cũng có thể xem giá trị `HOT_UPDATER_CLOUDFLARE_WORKER_NAME` trong file `.env.hotupdater`.
   > 3. **Subdomain:** Được hiển thị ở góc dưới bên phải màn hình tại phần **Account Details** (Ví dụ: `messi123.workers.dev`), hoặc hiển thị ngay bên dưới tên Worker.
   > 4. Ghép lại thành `baseURL` theo cú pháp:
   >    `https://<tên-worker>.<subdomain>/api/check-update`

3. **Cấu hình Native Gradle (MainApplication.kt):**
   Mở file MainApplication.kt ở `android/app/src/main/java/com/ReactNativeCli0860v2/MainApplication.kt` hoặc tương đương:
   Thay thế dòng gán `jsBundleFilePath` mặc định bằng logic kiểm tra của Hot Updater:

   ```kotlin
   import com.hotupdater.HotUpdater // Import library

   // ...
   override val reactHost: ReactHost by lazy {
     getDefaultReactHost(
       context = applicationContext,
       packageList = PackageList(this).packages,
       jsBundleFilePath = HotUpdater.getJSBundleFile(applicationContext), // Trỏ đường dẫn đọc bundle OTA
     )
   }
   ```

4. **Cấu hình Kênh mặc định (Default Channel) cho ứng dụng Native:**
   Mặc định nếu bạn không cấu hình gì, client app sẽ kiểm tra bản cập nhật ở kênh `production`. Để trỏ client app về kênh khác làm mặc định (ví dụ kênh `stg` để test), bạn chạy lệnh sau ở thư mục gốc của project:
   ```bash
   npx hot-updater channel set stg
   ```
   _Lệnh này sẽ tự động sửa đổi cấu hình hệ thống Native tại các file sau:_
   - **Android:** Chỉnh sửa file [AndroidManifest.xml](`android/app/src/main/AndroidManifest.xml`), tự động thêm dòng meta-data vào trong thẻ `<application>`:
     ```xml
     <meta-data android:name="com.hotupdater.CHANNEL" android:value="stg"/>
     ```
   - **iOS:** Chỉnh sửa file `Info.plist` (nằm ở `ios/ReactNativeCli0860v2/Info.plist`), tự động thêm khoá `com.hotupdater.CHANNEL` với giá trị là `stg`.
     _(Lưu ý bắt buộc: Vì đây là thay đổi ở native files, bạn phải thực hiện lệnh này trước khi build APK native shell. Nếu thực hiện sau khi build, bạn bắt buộc phải chạy lệnh build lại APK thì app mới nhận diện đúng kênh `stg`)._

---

### BƯỚC 4: Tạo Script Trong `package.json`

Thêm các script tiện ích vào phần `"scripts"` trong `package.json` để thao tác nhanh:

```json
"scripts": {
  "android:release": "react-native run-android --mode=release",
  "hot:console": "npx hot-updater console",
  "hot:stg:android": "npx hot-updater deploy -p android -t \"1.0\" --channel stg",
  "hot:task:android": "npx hot-updater deploy -p android -t \"1.0\" --channel"
}
```

#### 📖 Hướng dẫn sử dụng các câu lệnh:

1. **`npm run android:release`**:
   - **Tác dụng:** Biên dịch ứng dụng ở chế độ Release và tự động cài đặt trực tiếp lên thiết bị Android đã kết nối.
   - **Cách dùng:** Chạy trực tiếp lệnh:
     ```bash
     npm run android:release
     ```

2. **`npm run hot:console`**:
   - **Tác dụng:** Mở bảng điều khiển admin (giao diện Web dashboard) ở local để quản lý cập nhật.
   - **Cách dùng:** Chạy trực tiếp lệnh:
     ```bash
     npm run hot:console
     ```
     Sau đó mở trình duyệt truy cập đường dẫn được hiển thị trên terminal (thường là `http://localhost:4321`) để quản lý các bundle, các channel hoặc thực hiện rollback.

3. **`npm run hot:stg:android`**:
   - **Tác dụng:** Biên dịch và đóng gói code JS/TypeScript thành bundle rồi đẩy trực tiếp lên kênh Staging (`stg`) cố định cho Android.
   - **Cách dùng:** Chạy trực tiếp lệnh:
     ```bash
     npm run hot:stg:android
     ```

4. **`npm run hot:task:android`**:
   - **Tác dụng:** Biên dịch và đẩy bundle lên một kênh động tùy chọn (thường đặt tên kênh theo mã Task, Jira hoặc tên tính năng đang làm việc).
   - **Cách dùng (truyền thêm tên kênh mong muốn vào cuối):**
     - **Với npm:** Sử dụng ký tự đặc biệt `--` để truyền tên kênh:
       ```bash
       npm run hot:task:android -- <tên-kênh>
       # Ví dụ: npm run hot:task:android -- task-102
       ```
     - **Với yarn:**
       ```bash
       yarn hot:task:android <tên-kênh>
       # Ví dụ: yarn hot:task:android task-102
       ```
     - **Với pnpm:**
       ```bash
       pnpm hot:task:android <tên-kênh>
       # Ví dụ: pnpm hot:task:android task-102
       ```

---

_Lưu ý quan trọng về tham số `-t "1.0"` (Target Version):_

- Tham số `-t` là viết tắt của **Target Version**. Giá trị này **bắt buộc phải trùng khớp hoàn toàn** với phiên bản ứng dụng Native (`versionName` trong file `android/app/build.gradle`).
- **Tại sao cần thiết:** Để đảm bảo tính tương thích, `hot-updater` sẽ chỉ tải bản cập nhật OTA về điện thoại nếu phiên bản Native cài trên máy trùng với phiên bản bạn deploy.
- **Cách tìm đúng phiên bản để điền:**
  - **Android:** Xem dòng `versionName` trong file `android/app/build.gradle` (ở dự án này mặc định đang là `"1.0"`).
  - **iOS:** Xem dòng `Version` (hoặc `CFBundleShortVersionString`) trong file `Info.plist`.
- Nếu sau này bạn cập nhật ứng dụng Native lên bản `1.1` hay `2.0` (ví dụ sửa native module, nâng SDK), bạn bắt buộc phải sửa lại tham số `-t` này trong file `package.json` thành `-t "1.1"` hoặc `-t "2.0"` tương ứng trước khi deploy OTA.

---

### BƯỚC 5: Quy Trình Deploy & Kiểm Thử

#### 1. Tạo Bản Build APK Góc (Native Shell)

> [!IMPORTANT]
> **ĐIỀU KIỆN TIÊN QUYẾT:** Trước khi chạy lệnh build APK dưới đây, bạn **bắt buộc** phải cấu hình Kênh mặc định cho native shell trỏ tới `stg` bằng cách chạy lệnh: `npx hot-updater channel set stg` (ở bước 3.4).
> Nếu không làm bước này, bản APK xuất ra sẽ tìm bản cập nhật ở kênh `production` theo mặc định, khiến app không thể nhận diện bản cập nhật được deploy lên kênh `stg` bằng lệnh `npm run hot:stg:android`.

- **Cách 1: Chạy build và tự động cài thẳng vào máy test (Nhanh nhất)**
  - Kết nối điện thoại Android của bạn với máy tính (đã bật "Tùy chọn cho nhà phát triển" và "Gỡ lỗi USB - USB Debugging").
  - Chạy một trong các lệnh sau tại thư mục gốc dự án:

    ```bash
    # Sử dụng npm script đã thêm ở Bước 4 (Khuyên dùng):
    npm run android:release

    # Hoặc chạy trực tiếp bằng npx:
    npx react-native run-android --mode=release

    # Hoặc truyền cờ qua script android mặc định:
    npm run android -- --mode=release
    ```

    _Lệnh này sẽ tự động biên dịch ứng dụng ở chế độ Release, cài đặt và mở app trực tiếp trên thiết bị của bạn._

- **Cách 2: Build ra file APK rồi cài qua dòng lệnh adb**
  - Chạy lệnh dọn dẹp cache và biên dịch ra file APK mới:
    ```bash
    cd android && ./gradlew clean && ./gradlew assembleRelease
    ```
  - Sau khi build hoàn tất, file APK sẽ nằm ở đường dẫn:
    `android/app/build/outputs/apk/release/app-release.apk`
  - Chạy lệnh sau để cài đặt file APK này vào thiết bị đã cắm cáp USB:
    ```bash
    # (Đứng ở thư mục gốc của project)
    adb install android/app/build/outputs/apk/release/app-release.apk
    ```

- **Cách 3: Cài đặt thủ công bằng cách gửi file vào điện thoại**
  - Sau khi chạy build ra file APK ở Cách 2, bạn gửi file `app-release.apk` vào điện thoại thông qua Zalo, Telegram, Google Drive hoặc dây cáp truyền file.
  - Mở ứng dụng Quản lý file trên điện thoại, tìm đến file APK đã tải về và nhấn vào nó để cài đặt (nhớ cho phép quyền "Cài đặt ứng dụng từ nguồn không xác định" nếu được hỏi).

> [!TIP]
> **Xử lý nếu lỡ build APK trước khi chạy lệnh `channel set stg`:**
> Nếu bạn đã lỡ cài APK lên máy và chạy deploy `npm run hot:stg:android` nhưng mở app không thấy cập nhật (do app vẫn đang tìm ở kênh `production` mặc định):
>
> 1. Chạy lệnh: `npx hot-updater channel set stg` tại thư mục gốc.
> 2. Dọn dẹp cache và biên dịch lại APK: `cd android && ./gradlew clean && ./gradlew assembleRelease`
> 3. Cài đè lại ứng dụng vào thiết bị: `adb install android/app/build/outputs/apk/release/app-release.apk`
> 4. Mở app lên $\rightarrow$ tắt hẳn đi $\rightarrow$ mở lại. Bạn **không cần chạy lại lệnh deploy** vì bản cập nhật đã nằm sẵn trên Cloudflare stg channel từ trước rồi, ứng dụng mới sẽ tự động nhận diện và tải về!

#### 2. Cập Nhật Code JS và Deploy Lên Cloudflare

- Sửa nội dung text hiển thị trong `App.tsx` (ví dụ: đổi thành `Text: "ĐÃ CẬP NHẬT OTA THÀNH CÔNG VỚI CLOUDFLARE 🎉"`).
- Deploy bundle JS mới lên channel `stg` bằng command:
  ```bash
  npm run hot:stg:android
  ```
  _(Quá trình này tự động chạy Metro bundler, nén file và upload trực tiếp lên Cloudflare R2, đồng thời cập nhật metadata vào Cloudflare D1 Database)_.

#### 3. Kiểm Tra Trên Thiết Bị

- Mở app trên điện thoại của bạn lên.
- App sẽ ngầm kết nối tới Cloudflare Worker ở chế độ nền để tải bundle về.
- Thoát app ra hoàn toàn (Kill App) và mở lại lần thứ 2 $\rightarrow$ **Nội dung giao diện sẽ tự động cập nhật sang text mới!**

#### 4. Sử dụng Console cục bộ

- Chạy command để mở bảng điều khiển trực quan:
  ```bash
  npm run hot:console
  ```
- Giao diện web local hiện ra cho phép bạn xem danh sách các bundle, tạo channel test mới (ví dụ channel theo tên Task như `task-102`), rollback phiên bản cũ chỉ bằng một cú click chuột.
