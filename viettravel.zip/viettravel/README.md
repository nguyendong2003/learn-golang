# VietTravel

Backend service and infrastructure configuration for the VietTravel project.

## Tech Stack

- Node.js + TypeScript
- NestJS
- Prisma ORM
- PostgreSQL
- Docker / docker-compose

## Folder Structure

```
.
├── be/                        # Backend (NestJS)
│   ├── prisma/                # Prisma schema, migrations, seeds
│   ├── generated/             # Prisma generated client
│   └── src/                   # Application source
│       ├── common/
│       │   ├── decorators/
│       │   ├── dtos/
│       │   ├── errors/
│       │   ├── filters/
│       │   └── interceptors/
│       ├── config/
│       ├── modules/
│       │   └── user/          # Example module
│       │       ├── dto/
│       │       │   ├── request/
│       │       │   │   ├── create-user.dto.ts
│       │       │   │   └── update-user.dto.ts
│       │       │   ├── response/
│       │       │   │   └── user-response.dto.ts
│       │       │   └── user.mapper.ts
│       │       ├── user.controller.ts
│       │       ├── user.module.ts
│       │       ├── user.repository.ts
│       │       └── user.service.ts
│       └── prisma/
├── docker-compose.yml
├── Makefile
└── README.md
```

## Prerequisites / Requirements

- Node.js 18+ (or 20+ recommended)
- [pnpm](https://pnpm.io/installation)
- Docker Desktop
- Prettier: VSCode extention (optional, but recommend, install then set it to default code formatter)

## Installation Guide (for the first time)

1. Install backend dependencies:

```bash
make be-install
```

2. Configure environment variables:

- Create new file be/.env
- Copy the environment values in [be/.env.example](be/.env.example) and paste into just created be/.env file
- Edit to match your real credentials.

3. Run docker compose

```bash
make docker-up
```

4. Generate Prisma client:

```bash
make prisma-regenerate
```

5. Apply migration:

```bash
make prisma-apply-migration
```

4. Seed database

```bash
make prisma-seed
```

6. Install packages

```bash
make be-install
```

7. Run BE

```bash
make be-run
```

## API Documentation (Swagger / Postman)

- Swagger: If enabled in the NestJS app, access it at `http://localhost:3001/docs`.
- Postman: Import the collection provided by the team (if available).

## Create new module

- At root folder:

```bash
make be-new-resource
```

- Rename the `{moduleName}.repository.service.ts` to `{moduleName}.repository.ts` for better naming. Then update related imports.

## Database / Migration Guide

- Apply existing migration(s):

```bash
make prisma-apply-migration
```

- Create new migration:

```bash
make prisma-new-migration
```

Then enter the name of migration

- Reset migration history:

```bash
make prisma-reset-migration
```
