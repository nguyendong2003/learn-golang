---
name: tanstack-query
description: TanStack Query architecture and rules for server state, queries, mutations, cache management, and API integration.
version: 1.0
---

# TanStack Query Skill

## Purpose

This skill defines official server-state architecture using:

- TanStack Query
- TypeScript
- API Layer

Goals:

- predictable data flow
- cache consistency
- reusable API hooks
- scalable server state
- minimal duplicate fetch
- AI-safe patterns

This applies to:

- auth
- users
- bookings
- approvals
- travel requests
- dashboard data
- CRUD resources

---

# Core Philosophy

TanStack Query manages:

Server State.

Not UI state.

Use:

TanStack Query

for:

- fetching
- cache
- sync
- server mutations
- background updates

Use:

Zustand

for:

- modal state
- sidebar
- wizard step
- local UI state

Never confuse both.

---

# Official Data Flow

Architecture:

```txt
API Layer
    ↓
Query Function
    ↓
useQuery/useMutation
    ↓
UI
```

Always follow this.

Avoid:

```txt
UI
  ↓
fetch()
```

---

# Server State Rule

Server data belongs to:

TanStack Query.

Examples:

- user profile
- booking list
- approval queue
- destinations

Never store these in:

- useState
- Zustand

unless temporary UI reason exists.

---

# API Layer Rule

Always separate API calls.

Correct:

```txt
api/
    auth/
    ├── queries.ts
    ├── types.ts
    ├── mutations.ts
    ├── index.ts
    booking/
```

Avoid:

fetch inside component.

Bad:

```tsx
useQuery({
  queryFn: () =>
    fetch('/users')
})
```

---

# API Function Pattern

API functions:

must be reusable.

Correct:

```ts
export async function
getUsers() {}
```

Avoid:

anonymous fetch logic.

---

# Query Architecture

Official flow:

```txt
query key
    +
query fn
    +
query hook
```

All required.

---

# Query Key Rule

Query keys:

must be stable.

Correct:

```ts
['users']
```

Single resource:

```ts
['user', id]
```

Filter:

```ts
['bookings', filters]
```

Avoid:

random string keys.

Bad:

```ts
'user-' + id
```

---

# Query Key Structure

Recommended:

```txt
resource
resource + id
resource + filters
```

Examples:

List:

```ts
['users']
```

Detail:

```ts
['users', userId]
```

Filter:

```ts
['bookings', params]
```

Keep predictable.

---

# Query Function Rule

Query function:

must call API layer.

Correct:

```ts
queryFn: getUsers
```

or:

```ts
queryFn: () =>
  getUser(id)
```

Avoid:

direct axios/fetch.

Bad:

```ts
queryFn: async () =>
  axios.get(...)
```

inside UI.

---

# Basic Query Example

Correct:

```ts
const usersQuery =
  useQuery({
    queryKey: ['users'],
    queryFn: getUsers,
  })
```

Pattern:

- key
- fn
- typed result

---

# Query Hook Pattern

Prefer:

custom hooks.

Correct:

```txt
hooks/
    use-users.ts
```

Example:

```ts
export function useUsers() {
  return useQuery(...)
}
```

Avoid:

duplicated query logic.

---

# Loading Rule

Loading state:

comes from query.

Use:

```ts
isLoading
```

or:

```ts
isPending
```

Avoid:

manual loading state.

Bad:

```tsx
useState(loading)
```

---

# Error Rule

Errors:

come from query.

Correct:

```ts
error
```

Avoid:

manual try/catch UI state.

Bad:

```tsx
useState(error)
```

---

# Empty State Rule

Handle:

- loading
- error
- empty
- success

Never assume data exists.

Bad:

```tsx
data.map()
```

without checks.

---

# Query Retry Rule

Use retry intentionally.

Default:

acceptable.

Disable when:

- auth
- forbidden
- validation

Example:

```ts
retry: false
```

Avoid:

infinite retries.

---

# Stale Time Rule

Always think about freshness.

Examples:

Static-ish:

```ts
staleTime:
5 * 60 * 1000
```

Realtime:

short.

Avoid:

default blindly.

---

# Cache Time Rule

Cache lifetime:

must be intentional.

Examples:

Large dataset:

short cache.

Profile:

longer cache.

Avoid:

unknown cache policy.

---

# Enabled Rule

Use enabled for dependent queries.

Example:

```ts
enabled: !!userId
```

Avoid:

query with invalid params.

Bad:

```ts
getUser(undefined)
```

---

# Dependent Query Rule

Pattern:

```txt
query A
    ↓
query B
```

Example:

profile

↓

bookings.

Use:

enabled.

---

# Pagination Rule

Paginated data:

must include page in key.

Correct:

```ts
['users', page]
```

Avoid:

same cache key.

Bad:

```ts
['users']
```

for every page.

---

# Filter Query Rule

Filters:

must exist in key.

Correct:

```ts
['bookings', filters]
```

Avoid:

hidden dependencies.

---

# Prefetch Rule

Use prefetch when:

navigation predictable.

Examples:

- detail page
- hover navigation

Pattern:

```ts
prefetchQuery()
```

Avoid:

unnecessary prefetch.

---

# Mutation Philosophy

Mutation:

changes server data.

Use:

useMutation.

Never:

useQuery for POST.

---

# Mutation Architecture

Flow:

```txt
API mutation
    ↓
mutation hook
    ↓
invalidate/update
    ↓
UI sync
```

Always.

---

# Mutation API Rule

Separate mutation API.

Correct:

```ts
createUser()
```

Avoid:

inline mutation fetch.

Bad:

```ts
mutationFn:
() => axios.post(...)
```

inside component.

---

# Basic Mutation Example

Correct:

```ts
const mutation =
  useMutation({
    mutationFn: createUser,
  })
```

---

# Mutation Hook Pattern

Prefer:

custom mutation hook.

Example:

```txt
use-create-user.ts
```

Avoid:

copy-paste mutation logic.

---

# Mutation State Rule

Use mutation state.

Available:

```ts
isPending
isSuccess
isError
```

Avoid:

manual state.

Bad:

```tsx
useState(submitting)
```

---

# Invalidation Rule

After mutation:

invalidate affected query.

Required.

Example:

Create user:

invalidate:

```ts
['users']
```

Pattern:

```ts
queryClient
.invalidateQueries()
```

Never skip invalidation.

---

# Invalidation Strategy

Think cache ownership.

Examples:

Create booking:

invalidate:

```ts
['bookings']
```

Update user:

invalidate:

```ts
['users', id]
```

Avoid:

global invalidate.

Bad:

```ts
invalidate everything
```

---

# Optimistic Update Rule

Use carefully.

Allowed:

- toggle
- like
- small updates

Avoid:

complex optimistic flows.

Pattern:

```txt
snapshot
update
rollback
```

Required.

---

# Mutation Error Rule

Handle mutation errors.

Use:

- toast
- inline error
- form error mapping

Never:

silent failure.

---

# Form + Mutation Rule

Forms:

should integrate mutation.

Flow:

```txt
RHF
    ↓
mutation
    ↓
success/error
```

Avoid:

manual fetch submit.

---

# Auth Query Rule

Auth-sensitive query:

must respect auth state.

Use:

enabled.

Avoid:

unauthorized fetch spam.

---

# SSR Hydration Rule

For Next.js:

support hydration.

Pattern:

server prefetch

+

hydrate.

Avoid:

double fetch.

---

# Query Select Rule

Use select:

for lightweight transform.

Example:

```ts
select:
(data) => data.items
```

Avoid:

heavy business logic.

---

# Background Refetch Rule

Use intentionally.

Allowed:

- dashboard
- live queue

Avoid:

unnecessary polling.

---

# Polling Rule

Polling:

must have reason.

Example:

approval queue.

Use:

```ts
refetchInterval
```

Avoid:

constant polling.

---

# Cancellation Rule

Query cancellation:

should be supported.

Especially:

- search
- autocomplete

Avoid:

race conditions.

---

# Query Naming Rule

Hooks:

must be clear.

Correct:

```txt
useUsers
useUser
useBookings
useCreateBooking
```

Avoid:

generic naming.

Bad:

```txt
useData
```

---

# Folder Structure

Recommended:

```txt
services/
hooks/
queries/
mutations/
```

Example:

```txt
services/user.api.ts
hooks/use-users.ts
hooks/use-create-user.ts
```

---

# AI Implementation Rules

AI must:

- separate API layer
- use stable query keys
- create reusable hooks
- invalidate cache
- use mutation for writes
- use enabled when needed
- handle loading/error state
- keep server state in query

AI must not:

- fetch in UI
- use useEffect fetch
- use Zustand for API cache
- skip invalidation
- use unstable keys
- duplicate query logic

---

# Anti Patterns

Forbidden:

## Fetch In Component

Bad:

```tsx
axios.get()
```

inside component.

---

## useEffect Fetch

Bad:

```tsx
useEffect(fetch)
```

instead of query.

---

## API Cache In Zustand

Bad:

server data in store.

---

## Missing Query Keys

Bad:

non-unique cache.

---

## Mutation Without Invalidate

Bad:

stale UI.

---

## Global Cache Destroy

Bad:

invalidate everything.

---

# Final Principle

TanStack Query owns:

Server State.

Queries:

Read data.

Mutations:

Write data.

Cache:

must stay predictable.

When uncertain:

Prefer reusable query hooks and stable cache rules.