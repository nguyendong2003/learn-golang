---
name: react-hook-form-zod-rules
description: React Hook Form + Zod + TypeScript form architecture and validation rules for scalable and type-safe forms.
version: 1.0
---

# React Hook Form + Zod Rules

## Purpose

This skill defines official form rules using:

- React Hook Form
- Zod
- TypeScript

Goals:

- type-safe forms
- schema-first validation
- reusable form architecture
- predictable validation
- minimal rerender
- AI-consistent implementation

This architecture applies to:

- register
- login
- profile
- booking
- approval
- search filters
- dynamic forms

---

# Core Philosophy

Form validation is:

Schema First.

Validation logic belongs to:

Zod.

Not UI.

React Hook Form handles:

- field state
- dirty state
- touched state
- submission state
- form lifecycle

Zod handles:

- validation
- transformation
- business input rules

---

# Official Stack

Form layer:

```txt
React Hook Form
        +
Zod
        +
TypeScript
```

Never replace with:

- local useState form
- manual validation
- duplicated validation logic

---

# Architecture Rules

Form architecture:

```txt
schema
    ↓
type inference
    ↓
useForm
    ↓
fields
    ↓
submit handler
```

Always follow this flow.

---

# Schema First Rule

Always create schema first.

Never build form before schema.

Correct:

```txt
schema
→ type
→ form
```

Wrong:

```txt
form
→ random validation
```

---

# File Structure

Recommended:

```txt
features/auth/
    schemas/
        register.schema.ts
    components/
        register-form.tsx
```

Schema and UI must be separated.

Avoid:

```txt
everything in one file
```

---

# Type Inference Rule

Never duplicate types.

Infer from Zod.

Correct:

```ts
type RegisterFormValues =
  z.infer<typeof registerSchema>
```

Wrong:

```ts
type RegisterForm = {}

const schema = z.object(...)
```

duplicated manually.

Single source of truth:

Zod schema.

---

# Register Form Example

Official example:

register fields:

- username
- email
- password

Schema:

```ts
import { z } from 'zod'

export const registerSchema = z.object({
  username: z
    .string()
    .min(3)
    .max(30),

  email: z
    .email(),

  password: z
    .string()
    .min(8),
})
```

Type:

```ts
export type RegisterFormValues =
  z.infer<typeof registerSchema>
```

---

# Validation Rules

Validation belongs to Zod.

Never validate in JSX.

Bad:

```tsx
if(password.length < 8)
```

inside component.

Good:

```ts
schema validation
```

---

# Username Rules

Official username validation:

Required:

- string
- trimmed
- 3–30 chars
- alphanumeric
- underscore allowed

Example:

```ts
username: z
  .string()
  .trim()
  .min(3)
  .max(30)
  .regex(/^[a-zA-Z0-9_]+$/)
```

Avoid:

weak validation.

---

# Email Rules

Always validate email.

Required:

- trim
- normalize
- valid format

Example:

```ts
email: z
  .email()
  .trim()
  .toLowerCase()
```

Avoid:

manual regex email validation.

Prefer:

Zod email.

---

# Password Rules

Password rules:

Minimum:

8 chars.

Recommended:

- uppercase
- lowercase
- number
- special char

Example:

```ts
password: z
  .string()
  .min(8)
  .regex(...)
```

Avoid:

weak password acceptance.

---

# useForm Rules

Always use:

zodResolver.

Example:

```ts
const form = useForm<
  RegisterFormValues
>({
  resolver:
    zodResolver(registerSchema),
})
```

Never skip resolver.

Bad:

manual validation.

---

# Default Values Rule

Always define:

defaultValues.

Correct:

```ts
defaultValues: {
  username: '',
  email: '',
  password: '',
}
```

Avoid:

undefined field state.

---

# Register Rule

Use RHF register.

Correct:

```tsx
<Input
  {...register('email')}
/>
```

Avoid:

manual state sync.

Bad:

```tsx
value
onChange
useState
```

for basic field.

---

# Controlled Components Rule

Use Controller only when needed.

Allowed:

- date picker
- select
- custom component
- rich input

Avoid:

Controller everywhere.

Prefer:

register.

---

# Form Submission Rule

Submission:

must be typed.

Correct:

```ts
const onSubmit = (
  data: RegisterFormValues
) => {}
```

Avoid:

```ts
any
```

or unknown form payload.

---

# Async Submission Rule

Always handle:

- loading
- success
- error

Pattern:

```txt
submit
→ loading
→ request
→ success/error
```

Never:

silent failure.

---

# Error Handling Rule

Errors come from:

RHF.

Correct:

```tsx
errors.email?.message
```

Avoid:

manual error state.

Bad:

```tsx
useState(error)
```

---

# Error Message Rule

Validation messages:

must be human-readable.

Good:

```ts
.min(8, 'Password must be at least 8 characters')
```

Bad:

```txt
invalid field
```

or unclear messages.

---

# Server Error Mapping

Client validation:

≠

Server validation.

Both are required.

Example:

Backend:

```txt
email already exists
```

Map to field:

```ts
setError(...)
```

Pattern:

```ts
setError('email', {
  message:
    'Email already exists',
})
```

Never ignore backend errors.

---

# Form State Rule

Use RHF formState.

Allowed:

```ts
isSubmitting
isValid
dirtyFields
errors
```

Avoid:

duplicated local state.

Bad:

```tsx
useState(isLoading)
```

for form state.

---

# Submission UX Rules

Submit button:

must react to state.

Good:

disabled during submit.

Example:

```tsx
disabled={isSubmitting}
```

Avoid:

multiple submit clicks.

---

# Form Component Rules

Forms:

must be composable.

Prefer:

```txt
Form
Field
Label
Control
Message
```

Pattern.

Avoid:

large monolithic form JSX.

---

# Accessibility Rules

Every field:

must include:

- label
- aria state
- error association

Avoid:

placeholder-only UX.

Bad:

no label.

---

# Transformation Rules

Normalize input in schema.

Example:

email:

```ts
.toLowerCase()
.trim()
```

Avoid:

manual transform in submit.

---

# Business Validation Rule

Complex validation:

use refine.

Example:

confirm password.

Correct:

```ts
.refine(...)
```

Avoid:

JSX validation logic.

---

# Confirm Password Example

Example:

```ts
.refine(
  (data) =>
    data.password ===
    data.confirmPassword,
)
```

Message:

clear and targeted.

---

# Form Provider Rule

Large forms:

use FormProvider.

Example:

multi-step booking form.

Avoid:

prop drilling register.

---

# Reset Rules

Use:

```ts
reset()
```

after successful flow.

Avoid:

manual clearing.

Bad:

```tsx
setValue(...)
```

for entire form.

---

# Performance Rules

Prefer:

RHF uncontrolled model.

Benefits:

- fewer rerenders
- faster forms
- scalable

Avoid:

controlled text fields by default.

---

# AI Implementation Rules

AI must:

- create schema first
- infer types from schema
- use zodResolver
- prefer register
- use Controller only if required
- keep validation in Zod
- map backend errors
- use typed submit handler

AI must not:

- use any
- duplicate types
- validate in JSX
- use local state for form
- skip schema
- manually manage errors

---

# Anti Patterns

Forbidden:

## Validation In JSX

Bad:

```tsx
if(field === '')
```

---

## Duplicate Types

Bad:

manual interface +
schema.

---

## useState Form

Bad:

```tsx
useState
```

for full form.

---

## Manual Error State

Bad:

```tsx
useState(error)
```

---

## Controller Everywhere

Bad:

Controller for simple input.

---

# Final Principle

Forms are:

Schema First

Type Safe

Reusable

Validation Driven

Predictable

When uncertain:

Prefer Zod +
React Hook Form conventions.