---
name: shadcn-ui
description: shadcn/ui component architecture, styling patterns, and reusable UI rules for Next.js applications.
version: 1.0
---

# shadcn/ui Skill

## Purpose

This skill defines official UI architecture using:

- shadcn/ui
- Tailwind v4
- TypeScript
- Next.js

Goals:

- reusable UI
- accessible components
- consistent design
- scalable component system
- predictable AI-generated UI
- minimal styling duplication

This applies to:

- forms
- dialogs
- dashboard UI
- tables
- filters
- navigation
- admin pages
- travel booking interfaces

---

# Core Philosophy

shadcn/ui is:

Component Ownership.

Not:

UI library dependency.

Generated components belong to:

the project.

Team owns:

- code
- styles
- behavior
- customization

This is:

copy-and-own architecture.

---

# Official UI Stack

UI layer:

```txt
shadcn/ui
      +
Tailwind v4
      +
cva
      +
clsx/cn
```

Avoid:

multiple UI systems.

Bad:

```txt
shadcn
+
mui
+
antd
```

mixed together.

---

# Component Philosophy

Components should be:

- reusable
- composable
- accessible
- small
- predictable

Avoid:

page-specific giant components.

---

# Ownership Rule

Generated component:

belongs to project.

Allowed:

- edit
- extend
- customize

Do not treat as:

third-party black box.

---

# Component Layering

Architecture:

```txt
Primitive UI
      ↓
Shared UI
      ↓
Business Component
      ↓
Page
```

Always follow.

---

# Primitive Layer

Primitive:

generic UI.

Examples:

- Button
- Input
- Dialog
- Card
- Sheet

Location:

```txt
components/ui
```

No business logic.

---

# Shared Layer

Reusable composition.

Examples:

- DataTable
- SearchInput
- ConfirmDialog
- FormField

Location:

```txt
components/shared
```

May combine primitives.

---

# Business Layer

Feature component.

Examples:

- BookingForm
- ApprovalCard
- TravelSummary

Location:

feature folder.

Contains:

business behavior.

---

# Folder Structure

Recommended:

```txt
components/
    ui/
    shared/

features/
    booking/
        components/
```

Avoid:

single component folder.

Bad:

```txt
components/
    everything
```

---

# Styling Philosophy

Styling:

must use Tailwind.

Avoid:

inline CSS.

Bad:

```tsx
style={}
```

Prefer:

utility classes.

---

# cn Utility Rule

Always use:

```ts
cn()
```

for conditional class merging.

Correct:

```tsx
className={cn(
  base,
  className
)}
```

Avoid:

manual concat.

Bad:

```tsx
className={
  'a ' + className
}
```

---

# Variant Philosophy

Variants:

must use:

cva.

Purpose:

- reusable styling
- predictable API
- scalable components

Avoid:

class explosion.

---

# Button Variant Rule

Buttons:

must support variants.

Example:

- default
- secondary
- destructive
- outline
- ghost
- link

Avoid:

multiple duplicated button files.

Bad:

```txt
PrimaryButton
DangerButton
```

---

# Button Example

Correct:

```ts
buttonVariants
```

Usage:

```tsx
<Button
  variant="outline"
/>
```

Not:

separate components.

---

# Size Variant Rule

Reusable components:

should support size.

Examples:

- sm
- default
- lg
- icon

Avoid:

hardcoded dimensions.

---

# Component API Rule

Props:

must stay simple.

Good:

```tsx
<Button
  variant=""
  size=""
/>
```

Avoid:

huge prop surface.

Bad:

20+ boolean props.

---

# Accessibility Philosophy

Accessibility:

required.

Not optional.

shadcn primitives:

already help.

Do not break them.

---

# Accessibility Rules

Must preserve:

- focus state
- keyboard navigation
- aria support
- semantic HTML

Avoid:

div button.

Bad:

```tsx
<div onClick>
```

Use:

Button.

---

# Focus Rules

Never remove:

focus ring blindly.

Bad:

```txt
outline-none
```

without replacement.

Prefer:

accessible focus styles.

---

# Dialog Rule

Use:

Dialog

for:

- modal
- confirmation
- detail preview

Avoid:

custom modal.

Bad:

manual overlay.

---

# Sheet Rule

Use:

Sheet

for:

- sidebar
- mobile menu
- side panel

Avoid:

custom slide panel.

---

# Dropdown Rule

Use:

DropdownMenu

for:

- actions
- contextual menus
- row menu

Avoid:

manual dropdown state.

---

# Command Rule

Use:

Command

for:

- searchable picker
- quick search
- combobox

Avoid:

building from scratch.

---

# Popover Rule

Use:

Popover

for:

- floating UI
- lightweight overlay
- inline actions

Avoid:

dialog misuse.

---

# Tooltip Rule

Tooltips:

must be lightweight.

Use:

Tooltip.

Avoid:

important information hidden only in tooltip.

---

# Card Rule

Card:

for grouped content.

Examples:

- booking summary
- dashboard metric
- travel detail

Avoid:

nested card chaos.

---

# Table Rule

Tables:

must support:

- loading
- empty
- responsive
- actions

Prefer:

DataTable abstraction.

Avoid:

raw table duplication.

---

# Form Rule

Forms:

must integrate:

- RHF
- Zod
- shadcn Form

Pattern:

```txt
Form
Field
Control
Label
Message
```

Avoid:

manual form layout duplication.

---

# Input Rule

Input:

should remain generic.

No business logic.

Bad:

```tsx
<Input
  validateUser
/>
```

Business logic belongs elsewhere.

---

# Business Logic Rule

Never place:

business logic

inside:

ui primitives.

Bad:

```tsx
Button
  +
API call
```

Good:

Button

receives:

handler.

---

# State Rule

UI primitive:

should not own app state.

Allowed:

- open
- hover
- local interaction

Avoid:

API logic.

---

# Theme Rule

Use:

CSS variables

and

Tailwind semantic tokens.

Avoid:

hardcoded color.

Bad:

```txt
text-red-500
```

for business meaning.

Prefer:

```txt
text-destructive
```

---

# Dark Mode Rule

Must support:

dark mode.

Use:

semantic color system.

Avoid:

light-only classes.

---

# Responsive Rule

Components:

must adapt.

Use:

Tailwind breakpoints.

Avoid:

desktop-only layout.

---

# Animation Rule

Prefer:

minimal motion.

Use:

- transition
- animate-in
- animate-out

Avoid:

heavy animation libraries.

Unless necessary.

---

# Composition Philosophy

Compose.

Do not duplicate.

Example:

Dialog

+

Form

+

Button

↓

BookingDialog

Good.

Avoid:

copying same JSX.

---

# Shared Component Rule

If reused:

3+ times

extract.

Examples:

- EmptyState
- ConfirmDialog
- PageHeader
- SectionTitle

Avoid:

copy-paste UI.

---

# Icon Rule

Use:

consistent icon set.

Recommended:

lucide-react.

Avoid:

mixed icon packs.

---

# Naming Rule

Primitive:

PascalCase.

Examples:

```txt
Button
Dialog
Input
```

Business:

descriptive.

Examples:

```txt
BookingForm
ApprovalDialog
```

Avoid:

generic names.

Bad:

```txt
Box
Item
Thing
```

---

# Error State Rule

Components:

must support:

- loading
- disabled
- error

Example:

Button:

```tsx
disabled
```

Input:

error style.

---

# Skeleton Rule

Use:

Skeleton

for loading.

Avoid:

layout jump.

Bad:

blank page.

---

# Empty State Rule

Always design:

empty state.

Examples:

- no bookings
- no results
- no approval

Avoid:

empty table.

---

# AI Implementation Rules

AI must:

- use shadcn primitives
- preserve accessibility
- use cn()
- use cva variants
- compose UI
- separate business logic
- support responsive design
- follow semantic styling

AI must not:

- create custom modal unnecessarily
- mix UI libraries
- use inline CSS
- duplicate buttons
- break accessibility
- hardcode styles everywhere
- place API logic in UI

---

# Anti Patterns

Forbidden:

## Multiple UI Libraries

Bad:

```txt
shadcn
+
antd
```

---

## Inline Styling

Bad:

```tsx
style={}
```

---

## Business Logic In UI

Bad:

Button fetch.

---

## Duplicate Components

Bad:

multiple button copies.

---

## Accessibility Breakage

Bad:

clickable div.

---

## Hardcoded Colors

Bad:

business meaning via raw color.

---

# Final Principle

shadcn/ui is:

Owned UI System.

Components should be:

Composable

Accessible

Reusable

Predictable

When uncertain:

Prefer composition over duplication.