# Project Memory

This file serves as the long-term context for the AI agent. It should be updated whenever significant architectural decisions, conventions, or project-specific knowledge are established.

## Established Patterns
- UI Components: Mọi component UI mới phải được đặt trong `src/components/ui` và tuân thủ nguyên lý **Atomic Design**.

## Key Architectural Decisions
- [2026-05-18] Initialized `.agent` structure for standardized AI orchestration.
- [2026-05-18] Implemented Premium Login Form with Next.js App Router and strict TS typing.
- [2026-05-18] Refined Login UI with Vietnamese localization and advanced animations.

## Known Challenges & Gotchas
- *None identified yet.*

## Project Goals
- Maintain a highly modular and testable codebase.
- Ensure 100% compliance with established `.agent/rules`.
