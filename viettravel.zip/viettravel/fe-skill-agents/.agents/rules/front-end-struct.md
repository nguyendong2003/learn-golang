**description**: Folder layout and rules for NextJS Front-end 

```typescript
app/
│
├── layout/
├── api/
|   |
|   ├── auth
|   ├── user
|   ├── hotel
|       ├── type
|       ├── queries
|       ├── mutations
|       ├── index
│
├── assets/
|   ├── fonts/
|   ├── images/
|   ├── svg/
│
├── components/
│   │
│   ├── ui/
│   │   └── table.ts
|   |   ├── form.ts
|   |   ├── ...
│   │
│   ├── common/
│   │   ├── paginate
│   │   ├── pagination
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   ├── 
│   │   └── ...  
│
├── modules/
|   ├──hotel management/
|       ├──components/
|       ├── schema/         
|       ├── type/
|       ├── index
│
├── shared/
│
├── hook/
└── common/
├── lib/
├── utils/
├──...
```