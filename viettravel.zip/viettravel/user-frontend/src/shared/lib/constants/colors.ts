export const DESTINATION_COLORS = {
  haLong: {
    bg: '#0c4a6e',
    stripe: '#083b5a',
  },
  sapa: {
    bg: '#2d6a4f',
    stripe: '#1b4332',
  },
  hoiAn: {
    bg: '#92400e',
    stripe: '#6b2f09',
  },
  phuQuoc: {
    bg: '#0369a1',
    stripe: '#024d79',
  },
  nhaTrang: {
    bg: '#0e7490',
    stripe: '#0a5570',
  },
  daLat: {
    bg: '#5b21b6',
    stripe: '#3d1580',
  },
  trekking: {
    bg: '#3f6212',
    stripe: '#2d4a0d',
  },
} as const

export const LOYALTY_TIER_COLORS = {
  bronze: {
    text: '#a16207',
    bg: '#fef9c3',
  },
  silver: {
    text: '#6b7280',
    bg: '#f3f4f6',
  },
  gold: {
    text: '#92400e',
    bg: '#fef3c7',
  },
  platinum: {
    text: '#1e3a5f',
    bg: '#e0effe',
  },
} as const
