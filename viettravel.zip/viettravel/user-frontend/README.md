# VietTravel User Frontend

Frontend application for the VietTravel user-facing website.

## Tech Stack

- Next.js 16 App Router
- React 19
- TypeScript
- Tailwind CSS 4
- TanStack Query
- Axios
- React Hook Form
- Zod
- Zustand
- Day.js
- pnpm

## Requirements

- Node.js 20+
- pnpm

## Installation

Install dependencies:

```bash
pnpm install
```

Create local environment file:

```bash
cp .env.example .env.local
```

Update `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8080/api
```

Run development server:

```bash
pnpm dev
```

Open:

```txt
http://localhost:3000
```

## Scripts

```bash
pnpm dev
pnpm build
pnpm start
pnpm lint
pnpm typecheck
```

## Project Structure

```txt
src/
  app/                # Next.js App Router
    (public)/         # Public routes
    (dashboard)/      # Dashboard routes
    api/              # Route handlers
    layout.tsx
    providers.tsx
    globals.css

  features/           # Business/domain modules
    auth/
    tour/

  shared/             # Reusable global code
    ui/               # Generic UI components
    layouts/          # Shared layouts
    hooks/            # Shared hooks
    lib/
      api/            # Axios, interceptors, query client
      constants/      # App constants, routes, storage keys, colors, env
      configs/        # App/site configs
      utils/          # Shared utilities
    types/            # Shared TypeScript types
    validations/      # Shared Zod schemas

  assets/
    fonts/
    icons/
    images/
```

## Feature Structure

Each feature should keep its own domain code together.

```txt
features/<feature>/
  api/
  components/
  hooks/
  store/
  types/
  validations/
  constants/
  index.ts
```

Put code inside a feature when it belongs only to that feature.

Move code to `shared` only when it is reused by multiple features.

## Common Setup

### API Client

Shared API setup lives in:

```txt
src/shared/lib/api/
  axios.ts
  interceptors.ts
  query-client.ts
  index.ts
```

Use:

```ts
import { apiClient } from '@/shared/lib/api'
```

The API base URL comes from:

```ts
env.apiUrl
```

Source:

```txt
src/shared/lib/constants/env.ts
```

### React Query

The shared query client is created in:

```txt
src/shared/lib/api/query-client.ts
```

It is mounted in:

```txt
src/app/providers.tsx
```

### Colors

Global CSS color tokens live in:

```txt
src/app/globals.css
```

Example usage:

```tsx
className="bg-primary text-white hover:bg-primary-hover"
```

Data-driven colors live in:

```txt
src/shared/lib/constants/colors.ts
```

Use them for destination cards, loyalty tiers, badges, or image themes.

### Fonts

The project uses local BE Vietnam Pro fonts from:

```txt
src/assets/fonts/
```

Fonts are configured in:

```txt
src/app/layout.tsx
```

No Google Fonts network request is required during build.

### Utilities

Shared utilities live in:

```txt
src/shared/lib/utils/
```

Current utilities:

- `cn`
- `formatCurrency`
- `formatDate`

### Constants

Shared constants live in:

```txt
src/shared/lib/constants/
```

Current constants:

- `APP_NAME`
- `ROUTES`
- `STORAGE_KEYS`
- `DESTINATION_COLORS`
- `LOYALTY_TIER_COLORS`
- `env`

## Code Organization Rules

- Keep route files inside `src/app`.
- Keep feature-specific logic inside `src/features/<feature>`.
- Keep reusable UI in `src/shared/ui`.
- Keep shared layouts in `src/shared/layouts`.
- Keep shared non-UI logic in `src/shared/lib`.
- Do not move code to `shared` until at least two features need it.
- Do not hardcode API URLs, storage keys, routes, or shared colors in feature code.

## Validation Before Commit

Run:

```bash
pnpm lint
pnpm typecheck
pnpm build
```
