import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const SignupSchema = z
  .strictObject({
    email: z.email('Invalid email address'),
    username: z.string().trim().min(1, 'Username is required').max(50, 'Username must be at most 50 characters'),
    password: z
      .string()
      .trim()
      .min(6, 'Password must be at least 6 characters')
      .max(36, 'Password must be at most 36 characters'),
    name: z
      .string()
      .trim()
      .min(2, 'Name must be at least 2 characters')
      .max(100, 'Name must be at most 100 characters'),
    phone: z.string().regex(/^(03|05|07|08|09)[0-9]{8}$/, 'Invalid phone number'),
  })
  .meta({ id: 'Signup' })

export class SignupDto extends createZodDto(SignupSchema) {}
