import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const LoginSchema = z
  .strictObject({
    email: z.email('Invalid email address'),
    password: z
      .string()
      .trim()
      .min(6, 'Password must be at least 6 characters')
      .max(36, 'Password must be at most 36 characters'),
  })
  .meta({ id: 'Login' })

export class LoginDto extends createZodDto(LoginSchema) {}
