import { LoginResponseDto } from '@/modules/auth/dto/response/login-response.dto'

type LoginUserPayload = {
  id: string
  email: string
  username: string
  name: string
  phone: string
}

export class AuthMapper {
  static toLoginResponse(accessToken: string, user: LoginUserPayload): InstanceType<typeof LoginResponseDto> {
    return {
      accessToken,
      user: {
        id: user.id,
        email: user.email,
        username: user.username,
        name: user.name,
        phone: user.phone,
      },
    }
  }
}
