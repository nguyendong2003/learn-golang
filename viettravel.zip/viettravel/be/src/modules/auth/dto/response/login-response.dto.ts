import { createZodDto } from 'nestjs-zod'
import z from 'zod'

export const LoginResponseSchema = z
  .strictObject({
    accessToken: z.string(),
    user: z.object({
      id: z.string(),
      email: z.email(),
      username: z.string(),
      name: z.string(),
      phone: z.string(),
    }),
  })
  .meta({ id: 'LoginResponse' })

export class LoginResponseDto extends createZodDto(LoginResponseSchema) {}
