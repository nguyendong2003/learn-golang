import { Body, Controller, Post, UseGuards } from '@nestjs/common'
import { AuthService } from '@/modules/auth/auth.service'
import { SignupDto } from '@/modules/auth/dto/request/signup.dto'
import { Public } from '@/common/decorators/public.decorator'
import { LocalAuthGuard } from '@/common/guards/local.guard'
import { CurrentUser } from '@/common/decorators/current-user.decorator'
import { LoginResponseDto } from '@/modules/auth/dto/response/login-response.dto'
import { LoginDto } from '@/modules/auth/dto/request/login.dto'
import { UserResponseDto } from '../user/dto/response/user-response.dto'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { ApiTags } from '@nestjs/swagger'

@Controller('auth')
@ApiTags('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Public()
  @Post('signup')
  @ApiSuccessResponse({ type: UserResponseDto, description: 'User registered successfully' })
  @SuccessMessage('User registered successfully')
  async signup(@Body() dto: SignupDto): Promise<UserResponseDto> {
    return this.authService.signup(dto)
  }

  @Public()
  @Post('login')
  @UseGuards(LocalAuthGuard)
  @ApiSuccessResponse({ type: LoginResponseDto, description: 'User logged in successfully' })
  @SuccessMessage('User logged in successfully')
  async login(@Body() _dto: LoginDto, @CurrentUser() user: any): Promise<LoginResponseDto> {
    return this.authService.login(user)
  }
}
