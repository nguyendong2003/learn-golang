import { Module } from '@nestjs/common'
import { ConfigModule, ConfigService } from '@nestjs/config'
import { JwtModule } from '@nestjs/jwt'
import { PassportModule } from '@nestjs/passport'
import { AuthService } from '@/modules/auth/auth.service'
import { AuthController } from '@/modules/auth/auth.controller'
import { AuthRepository } from '@/modules/auth/auth.repository'
import { PrismaModule } from '@/prisma/prisma.module'
import { JwtStrategy } from '@/modules/auth/strategies/jwt.strategy'
import { Env } from '@/config/env.validation'
import { LocalStrategy } from '@/modules/auth/strategies/local.strategy'

@Module({
  imports: [
    PrismaModule,
    PassportModule,
    JwtModule.registerAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService<Env, true>) => ({
        secret: configService.getOrThrow('JWT_ACCESS_SECRET'),
        signOptions: {
          expiresIn: configService.getOrThrow('JWT_ACCESS_TTL'),
        },
      }),
    }),
  ],
  providers: [AuthService, AuthRepository, JwtStrategy, LocalStrategy],
  controllers: [AuthController],
})
export class AuthModule {}
