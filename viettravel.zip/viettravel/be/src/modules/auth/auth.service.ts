import { PrismaService } from '@/prisma/prisma.service'
import { Injectable } from '@nestjs/common'
import { JwtService } from '@nestjs/jwt'
import * as bcrypt from 'bcrypt'
import { SignupDto } from '@/modules/auth/dto/request/signup.dto'
import { ResourceConflictException, ResourceNotFoundException } from '@/common/errors/business.exception'
import { LoginResponseDto } from '@/modules/auth/dto/response/login-response.dto'
import { RoleCode } from '@/common/enums/role.enum'
import { AuthRepository } from '@/modules/auth/auth.repository'
import { UserResponseDto } from '@/modules/user/dto/response/user-response.dto'
import { UsersMapper } from '@/modules/user/dto/user.mapper'
import { AuthMapper } from '@/modules/auth/dto/auth.mapper'

@Injectable()
export class AuthService {
  constructor(
    private readonly repository: AuthRepository,
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
  ) {}

  async signup(signUpDto: SignupDto): Promise<UserResponseDto> {
    const { email, username, password, name, phone } = signUpDto

    const existingUser = await this.prisma.user.findFirst({
      where: {
        OR: [{ email: email }, { username: username }],
      },
    })

    if (existingUser) {
      throw new ResourceConflictException('Email or username already exists!')
    }

    const defaultRole = await this.repository.findRoleByCode(RoleCode.USER)

    if (!defaultRole) {
      throw new ResourceNotFoundException('System has not been configured with a default role.')
    }

    const saltRounds = 10
    const hashedPassword = await bcrypt.hash(password, saltRounds)

    const newUser = await this.prisma.user.create({
      data: {
        email,
        username,
        password: hashedPassword,
        name,
        phone,
        userRoles: {
          create: {
            roleId: defaultRole.id,
          },
        },
      },
    })

    return UsersMapper.toResponse(newUser)
  }

  async validateUser(email: string, pass: string): Promise<any> {
    const user = await this.prisma.user.findUnique({
      where: { email },
    })

    if (user && (await bcrypt.compare(pass, user.password))) {
      const { password, ...result } = user
      return result
    }

    return null
  }

  async login(user: any): Promise<LoginResponseDto> {
    const payload = {
      email: user.email,
      sub: user.id,
      roleId: user.roleId,
    }

    const accessToken = this.jwtService.sign(payload)
    return AuthMapper.toLoginResponse(accessToken, {
      id: user.id,
      email: user.email,
      username: user.username,
      name: user.name,
      phone: user.phone,
    })
  }
}
