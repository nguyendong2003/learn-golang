import { Role } from '@/generated/prisma/browser'
import { PrismaService } from '@/prisma/prisma.service'
import { Injectable } from '@nestjs/common'

@Injectable()
export class AuthRepository {
  constructor(private readonly prisma: PrismaService) {}

  async findRoleByCode(code: string): Promise<Role | null> {
    return this.prisma.role.findUnique({
      where: { code },
    })
  }
}
