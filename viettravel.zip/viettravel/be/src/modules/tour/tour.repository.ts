import { Injectable } from '@nestjs/common'
import { Prisma } from '@/generated/prisma/client'

import { PrismaService } from '@/prisma/prisma.service'
import { TOUR_INCLUDE, TourWithRelations } from '@/modules/tour/dto/tour.mapper'

@Injectable()
export class TourRepository {
  constructor(private prisma: PrismaService) {}

  async findMany(skip?: number, take?: number, where: Prisma.TourWhereInput = {}): Promise<TourWithRelations[]> {
    return this.prisma.tour.findMany({
      where: { deletedAt: null, ...where },
      skip: skip ?? 0,
      take: take ?? 100,
      include: TOUR_INCLUDE,
      orderBy: { createdAt: 'desc' },
    })
  }

  async count(where: Prisma.TourWhereInput = {}) {
    return this.prisma.tour.count({ where: { deletedAt: null, ...where } })
  }

  async findById(id: string): Promise<TourWithRelations | null> {
    return this.prisma.tour.findFirst({
      where: { id, deletedAt: null },
      include: TOUR_INCLUDE,
    })
  }

  async findByCode(code: string): Promise<TourWithRelations | null> {
    return this.prisma.tour.findFirst({
      where: { code, deletedAt: null },
      include: TOUR_INCLUDE,
    })
  }

  async findByCodeExcludingId(code: string, excludeId: string): Promise<TourWithRelations | null> {
    return this.prisma.tour.findFirst({
      where: { code, deletedAt: null, id: { not: excludeId } },
      include: TOUR_INCLUDE,
    })
  }
}
