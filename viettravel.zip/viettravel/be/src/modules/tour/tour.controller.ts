import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Post, Put, Query } from '@nestjs/common'
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger'

import { CurrentUser } from '@/common/decorators/current-user.decorator'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { ApiErrorResponse } from '@/common/decorators/api-error-responses.decorator'
import { ApiCreatedSuccessResponse } from '@/common/decorators/api-created-success-response.decorator'
import { PaginatedResult } from '@/common/dtos/pagination'

import { CreateTourDto } from '@/modules/tour/dto/request/create-tour.dto'
import { QueryTourDto } from '@/modules/tour/dto/request/query-tour.dto'
import { UpdateTourDto } from '@/modules/tour/dto/request/update-tour.dto'
import { TourResponseDto } from '@/modules/tour/dto/response/tour-response.dto'
import { TourService } from '@/modules/tour/tour.service'

@ApiBearerAuth()
@ApiTags('tours')
@Controller('tours')
export class TourController {
  constructor(private readonly tourService: TourService) {}

  @Get()
  @Permission(PermissionCode.TOUR_READ)
  @SuccessMessage('Tours retrieved successfully')
  @ApiSuccessResponse({ type: TourResponseDto, isArray: true, hasMeta: true })
  @ApiErrorResponse('Invalid tour list query')
  async getTours(
    @CurrentUser('id') currentUserId: string,
    @Query() query: QueryTourDto,
  ): Promise<PaginatedResult<TourResponseDto>> {
    return await this.tourService.getTours(currentUserId, query)
  }

  @Get(':id')
  @Permission(PermissionCode.TOUR_READ)
  @SuccessMessage('Tour retrieved successfully')
  @ApiParam({ name: 'id', type: String, description: 'Tour ID (UUID)' })
  @ApiSuccessResponse({ type: TourResponseDto, description: 'Tour retrieved successfully' })
  @ApiErrorResponse('Invalid tour id or tour not found')
  async getTourById(
    @CurrentUser('id') currentUserId: string,
    @Param('id', new ParseUUIDPipe()) id: string,
  ): Promise<TourResponseDto> {
    return await this.tourService.getTourById(currentUserId, id)
  }

  @Post()
  @Permission(PermissionCode.TOUR_CREATE)
  @SuccessMessage('Tour created successfully')
  @ApiCreatedSuccessResponse({ type: TourResponseDto, description: 'Tour created successfully' })
  @ApiErrorResponse('Invalid tour payload')
  async createTour(
    @CurrentUser('id') currentUserId: string,
    @Body() createTourDto: CreateTourDto,
  ): Promise<TourResponseDto> {
    return await this.tourService.createTour(currentUserId, createTourDto)
  }

  @Put(':id')
  @Permission(PermissionCode.TOUR_UPDATE)
  @SuccessMessage('Tour updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'Tour ID (UUID)' })
  @ApiSuccessResponse({ type: TourResponseDto, description: 'Tour updated successfully' })
  @ApiErrorResponse('Invalid tour id or payload')
  async updateTour(
    @CurrentUser('id') currentUserId: string,
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateTourDto: UpdateTourDto,
  ): Promise<TourResponseDto> {
    return await this.tourService.updateTour(currentUserId, id, updateTourDto)
  }

  @Delete(':id')
  @Permission(PermissionCode.TOUR_DELETE)
  @SuccessMessage('Tour deleted successfully')
  @ApiParam({ name: 'id', type: String, description: 'Tour ID (UUID)' })
  @ApiSuccessResponse({ type: TourResponseDto, hasData: false, description: 'Tour deleted successfully' })
  @ApiErrorResponse('Invalid tour id or tour not found')
  async deleteTour(
    @CurrentUser('id') currentUserId: string,
    @Param('id', new ParseUUIDPipe()) id: string,
  ): Promise<void> {
    return await this.tourService.deleteTour(currentUserId, id)
  }
}
