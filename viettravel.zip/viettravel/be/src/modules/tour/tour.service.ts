import { Injectable, Logger } from '@nestjs/common'

import { Prisma } from '@/generated/prisma/client'
import { TourStatusEnum } from '@/generated/prisma/enums'
import { PrismaService } from '@/prisma/prisma.service'
import { PaginatedResult, PaginationHelper } from '@/common/dtos/pagination'
import {
  AppBadRequestException,
  AppForbiddenException,
  ResourceConflictException,
  ResourceNotFoundException,
} from '@/common/errors/business.exception'
import { RoleCode } from '@/common/enums/role.enum'
import { TourMapper, TourWithRelations } from '@/modules/tour/dto/tour.mapper'
import { CreateTourDto } from '@/modules/tour/dto/request/create-tour.dto'
import { QueryTourDto } from '@/modules/tour/dto/request/query-tour.dto'
import { UpdateTourDto } from '@/modules/tour/dto/request/update-tour.dto'
import { TourResponseDto } from '@/modules/tour/dto/response/tour-response.dto'
import { TourRepository } from '@/modules/tour/tour.repository'

type ActorContext = {
  isAdmin: boolean
  agentId: string | null
}

const RELATION_DELETION_ERROR = 'Failed to sync tour relations'

function normalizeTourCode(code: string) {
  return code.trim()
}

function generateTourCode() {
  return `TOUR-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`
}

@Injectable()
export class TourService {
  private readonly logger = new Logger(TourService.name)

  constructor(
    private readonly prisma: PrismaService,
    private readonly tourRepository: TourRepository,
  ) {}

  async getTours(currentUserId: string, query: QueryTourDto): Promise<PaginatedResult<TourResponseDto>> {
    try {
      const actor = await this.resolveActorContext(currentUserId)
      const { page, limit, search, status, departureId } = query
      const { skip, take } = PaginationHelper.getSkipTake(page, limit)
      const where = this.buildWhere(actor, { search, status, departureId })

      const [tours, total] = await Promise.all([
        this.tourRepository.findMany(skip, take, where),
        this.tourRepository.count(where),
      ])

      return new PaginatedResult(TourMapper.toResponseList(tours), PaginationHelper.getMeta(page, limit, total))
    } catch (error) {
      this.logger.error(`Failed to get tours: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async getTourById(currentUserId: string, id: string): Promise<TourResponseDto> {
    try {
      const actor = await this.resolveActorContext(currentUserId)
      const tour = await this.requireVisibleTour(id, actor)
      return TourMapper.toResponse(tour)
    } catch (error) {
      if (error instanceof ResourceNotFoundException || error instanceof AppForbiddenException) throw error
      this.logger.error(`Failed to get tour ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async createTour(currentUserId: string, dto: CreateTourDto): Promise<TourResponseDto> {
    try {
      const actor = await this.resolveActorContext(currentUserId)
      const agentId = await this.requireAgentOwnershipForWrite(currentUserId, actor)

      await this.validateCreatePayload(dto)

      const code = await this.resolveUniqueCode(dto.code)
      const created = await this.prisma.$transaction(async (tx) => {
        const tour = await tx.tour.create({
          data: {
            agentId,
            name: dto.name,
            code,
            departureId: dto.departureId,
            durationDays: dto.durationDays,
            durationNights: dto.durationNights,
            minGuests: dto.minGuests,
            maxGuests: dto.maxGuests,
            description: dto.description,
            highlights: dto.highlights,
            inclusions: dto.inclusions,
            exclusions: dto.exclusions,
            importantNote: dto.importantNote ?? null,
            cancellationPolicy: dto.cancellationPolicy,
            videoUrl: dto.videoUrl ?? null,
            brochurePdfUrl: dto.brochurePdfUrl ?? null,
            status: dto.status ?? TourStatusEnum.DRAFT,
          },
        })

        await this.syncRelations(tx, tour.id, {
          tourCategoryIds: dto.tourCategoryIds,
          transportationCategoryIds: dto.transportationCategoryIds,
          destinationIds: dto.destinationIds,
        })

        await tx.staffAuditLog.create({
          data: {
            userId: currentUserId,
            action: `Created tour ${tour.id}`,
          },
        })

        return this.requireTourById(tx, tour.id)
      })

      return TourMapper.toResponse(created)
    } catch (error) {
      if (
        error instanceof AppBadRequestException ||
        error instanceof AppForbiddenException ||
        error instanceof ResourceConflictException ||
        error instanceof ResourceNotFoundException
      ) {
        throw error
      }
      this.logger.error(`Failed to create tour: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async updateTour(currentUserId: string, id: string, dto: UpdateTourDto): Promise<TourResponseDto> {
    try {
      const actor = await this.resolveActorContext(currentUserId)
      await this.requireVisibleTour(id, actor)

      if (dto.code) {
        const codeConflict = await this.tourRepository.findByCodeExcludingId(normalizeTourCode(dto.code), id)
        if (codeConflict) {
          throw new ResourceConflictException('Tour with this code already exists')
        }
      }

      await this.validateUpdatePayload(dto)

      const updated = await this.prisma.$transaction(async (tx) => {
        const tour = await tx.tour.update({
          where: { id },
          data: {
            name: dto.name,
            code: dto.code ? normalizeTourCode(dto.code) : undefined,
            departureId: dto.departureId,
            durationDays: dto.durationDays,
            durationNights: dto.durationNights,
            minGuests: dto.minGuests,
            maxGuests: dto.maxGuests,
            description: dto.description,
            highlights: dto.highlights,
            inclusions: dto.inclusions,
            exclusions: dto.exclusions,
            importantNote: dto.importantNote,
            cancellationPolicy: dto.cancellationPolicy,
            videoUrl: dto.videoUrl,
            brochurePdfUrl: dto.brochurePdfUrl,
            status: dto.status,
          },
        })

        await this.syncRelations(tx, tour.id, {
          tourCategoryIds: dto.tourCategoryIds,
          transportationCategoryIds: dto.transportationCategoryIds,
          destinationIds: dto.destinationIds,
        })

        await tx.staffAuditLog.create({
          data: {
            userId: currentUserId,
            action: `Updated tour ${tour.id}`,
          },
        })

        return this.requireTourById(tx, tour.id)
      })

      return TourMapper.toResponse(updated)
    } catch (error) {
      if (
        error instanceof AppBadRequestException ||
        error instanceof AppForbiddenException ||
        error instanceof ResourceConflictException ||
        error instanceof ResourceNotFoundException
      ) {
        throw error
      }
      this.logger.error(`Failed to update tour ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async deleteTour(currentUserId: string, id: string): Promise<void> {
    try {
      const actor = await this.resolveActorContext(currentUserId)
      await this.requireVisibleTour(id, actor)

      await this.prisma.$transaction(async (tx) => {
        await tx.tour.update({
          where: { id },
          data: { deletedAt: new Date() },
        })

        await tx.staffAuditLog.create({
          data: {
            userId: currentUserId,
            action: `Soft deleted tour ${id}`,
          },
        })
      })
    } catch (error) {
      if (error instanceof AppForbiddenException || error instanceof ResourceNotFoundException) throw error
      this.logger.error(`Failed to delete tour ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  private async resolveActorContext(userId: string): Promise<ActorContext> {
    const user = await this.prisma.user.findFirst({
      where: { id: userId, deletedAt: null },
      include: {
        agent: true,
        userRoles: {
          include: {
            role: true,
          },
        },
      },
    })

    if (!user) {
      throw new ResourceNotFoundException('User not found')
    }

    return {
      isAdmin: user.userRoles.some((userRole) => userRole.role.code === RoleCode.ADMIN),
      agentId: user.agent && !user.agent.deletedAt ? user.agent.id : null,
    }
  }

  private buildWhere(
    actor: ActorContext,
    filters: {
      search?: string
      status?: TourStatusEnum
      departureId?: string
    },
  ): Prisma.TourWhereInput {
    const where: Prisma.TourWhereInput = {}

    if (!actor.isAdmin) {
      if (!actor.agentId) {
        throw new AppForbiddenException('Only agent accounts can access tours')
      }

      where.agentId = actor.agentId
    }

    if (filters.departureId) {
      where.departureId = filters.departureId
    }

    if (filters.status) {
      where.status = filters.status
    }

    if (filters.search) {
      where.OR = [
        { name: { contains: filters.search, mode: 'insensitive' } },
        { code: { contains: filters.search, mode: 'insensitive' } },
      ]
    }

    return where
  }

  private async requireVisibleTour(id: string, actor: ActorContext): Promise<TourWithRelations> {
    const tour = await this.requireTourById(this.prisma, id)

    if (!actor.isAdmin && tour.agentId !== actor.agentId) {
      throw new AppForbiddenException('You do not have permission to access this tour')
    }

    return tour
  }

  private async requireAgentOwnershipForWrite(currentUserId: string, actor: ActorContext): Promise<string> {
    if (actor.agentId) {
      return actor.agentId
    }

    if (actor.isAdmin) {
      throw new AppBadRequestException('Admin accounts must be associated with an agent profile to create tours')
    }

    throw new AppForbiddenException(`Only agent accounts can create tours (user ${currentUserId})`)
  }

  private async validateCreatePayload(dto: CreateTourDto) {
    await this.validateReferencedRecords({
      departureId: dto.departureId,
      tourCategoryIds: dto.tourCategoryIds,
      transportationCategoryIds: dto.transportationCategoryIds,
      destinationIds: dto.destinationIds,
    })
  }

  private async validateUpdatePayload(dto: UpdateTourDto) {
    await this.validateReferencedRecords({
      departureId: dto.departureId,
      tourCategoryIds: dto.tourCategoryIds,
      transportationCategoryIds: dto.transportationCategoryIds,
      destinationIds: dto.destinationIds,
    })
  }

  private async validateReferencedRecords(payload: {
    departureId?: string
    tourCategoryIds?: string[]
    transportationCategoryIds?: string[]
    destinationIds?: string[]
  }) {
    if (payload.departureId) {
      const departure = await this.prisma.destination.findFirst({
        where: { id: payload.departureId, deletedAt: null },
      })

      if (!departure) {
        throw new ResourceNotFoundException('Departure destination not found')
      }
    }

    if (payload.tourCategoryIds) {
      const tourCategories = await this.prisma.tourCategory.findMany({
        where: { id: { in: payload.tourCategoryIds }, deletedAt: null },
        select: { id: true },
      })

      if (tourCategories.length !== payload.tourCategoryIds.length) {
        throw new ResourceNotFoundException('One or more tour categories not found')
      }
    }

    if (payload.transportationCategoryIds) {
      const transportationCategories = await this.prisma.transportationCategory.findMany({
        where: { id: { in: payload.transportationCategoryIds }, deletedAt: null },
        select: { id: true },
      })

      if (transportationCategories.length !== payload.transportationCategoryIds.length) {
        throw new ResourceNotFoundException('One or more transportation categories not found')
      }
    }

    if (payload.destinationIds) {
      const destinations = await this.prisma.destination.findMany({
        where: { id: { in: payload.destinationIds }, deletedAt: null },
        select: { id: true },
      })

      if (destinations.length !== payload.destinationIds.length) {
        throw new ResourceNotFoundException('One or more destinations not found')
      }
    }
  }

  private async resolveUniqueCode(inputCode?: string): Promise<string> {
    if (inputCode) {
      const code = normalizeTourCode(inputCode)
      const existing = await this.tourRepository.findByCode(code)
      if (existing) {
        throw new ResourceConflictException('Tour with this code already exists')
      }
      return code
    }

    for (let attempt = 0; attempt < 5; attempt += 1) {
      const generatedCode = generateTourCode()
      const existing = await this.tourRepository.findByCode(generatedCode)
      if (!existing) {
        return generatedCode
      }
    }

    throw new AppBadRequestException('Unable to generate a unique tour code')
  }

  private async syncRelations(
    tx: Prisma.TransactionClient,
    tourId: string,
    payload: {
      tourCategoryIds?: string[]
      transportationCategoryIds?: string[]
      destinationIds?: string[]
    },
  ) {
    try {
      if (payload.tourCategoryIds) {
        await tx.tourCategoryRelation.deleteMany({ where: { tourId } })
        if (payload.tourCategoryIds.length > 0) {
          await tx.tourCategoryRelation.createMany({
            data: payload.tourCategoryIds.map((tourCategoryId) => ({
              tourId,
              tourCategoryId,
            })),
          })
        }
      }

      if (payload.transportationCategoryIds) {
        await tx.tourTransportation.deleteMany({ where: { tourId } })
        if (payload.transportationCategoryIds.length > 0) {
          await tx.tourTransportation.createMany({
            data: payload.transportationCategoryIds.map((transportationCategoryId) => ({
              tourId,
              transportationCategoryId,
            })),
          })
        }
      }

      if (payload.destinationIds) {
        await tx.tourDestination.deleteMany({ where: { tourId } })
        if (payload.destinationIds.length > 0) {
          await tx.tourDestination.createMany({
            data: payload.destinationIds.map((destinationId) => ({
              tourId,
              destinationId,
            })),
          })
        }
      }
    } catch (error) {
      this.logger.error(`${RELATION_DELETION_ERROR}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  private async requireTourById(client: PrismaService | Prisma.TransactionClient, id: string) {
    const tour = await client.tour.findFirst({
      where: { id, deletedAt: null },
      include: {
        tourCategoryRelations: true,
        tourDestinations: true,
        tourTransportations: true,
      },
    })

    if (!tour) {
      throw new ResourceNotFoundException('Tour not found')
    }

    return tour
  }
}
