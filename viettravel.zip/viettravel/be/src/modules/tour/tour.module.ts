import { Module } from '@nestjs/common'

import { TourController } from '@/modules/tour/tour.controller'
import { TourRepository } from '@/modules/tour/tour.repository'
import { TourService } from '@/modules/tour/tour.service'

@Module({
  imports: [],
  providers: [TourService, TourRepository],
  controllers: [TourController],
})
export class TourModule {}
