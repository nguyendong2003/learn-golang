import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

import { CreateTourSchema } from '@/modules/tour/dto/request/create-tour.dto'

export const UpdateTourSchema = CreateTourSchema.partial()
  .superRefine((value, ctx) => {
    if (value.minGuests !== undefined && value.maxGuests !== undefined && value.maxGuests < value.minGuests) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['maxGuests'],
        message: 'Max guests must be greater than or equal to min guests',
      })
    }
  })
  .meta({ id: 'UpdateTour' })

export class UpdateTourDto extends createZodDto(UpdateTourSchema) {}
