import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

import { TourStatusEnum } from '@/generated/prisma/enums'
import { PaginationQuerySchema } from '@/common/dtos/pagination.query'

export const QueryTourSchema = PaginationQuerySchema.extend({
  search: z.string().trim().optional(),
  status: z.enum(TourStatusEnum).optional(),
  departureId: z.string().uuid().optional(),
}).meta({ id: 'QueryTour' })

export class QueryTourDto extends createZodDto(QueryTourSchema) {}
