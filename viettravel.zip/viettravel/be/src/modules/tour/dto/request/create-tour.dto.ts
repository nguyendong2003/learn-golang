import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

import { TourStatusEnum } from '@/generated/prisma/enums'

const uniqueUuidArraySchema = (label: string) =>
  z
    .array(z.string().uuid())
    .min(1, `${label} is required`)
    .superRefine((values, ctx) => {
      if (new Set(values).size !== values.length) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: `${label} must not contain duplicates`,
        })
      }
    })

export const CreateTourSchema = z
  .strictObject({
    name: z.string().trim().min(1, 'Name is required').max(255, 'Name must be at most 255 characters'),
    code: z.string().trim().min(1, 'Code is required').max(50, 'Code must be at most 50 characters').optional(),
    departureId: z.string().uuid('Departure destination is required'),
    durationDays: z.number().int().positive('Duration days must be positive'),
    durationNights: z.number().int().nonnegative('Duration nights must be non-negative'),
    minGuests: z.number().int().positive('Min guests must be positive'),
    maxGuests: z.number().int().positive('Max guests must be positive'),
    description: z.string().trim().min(1, 'Description is required'),
    highlights: z.array(z.string().trim().min(1)).optional().default([]),
    inclusions: z.array(z.string().trim().min(1)).min(1, 'Inclusions are required'),
    exclusions: z.array(z.string().trim().min(1)).min(1, 'Exclusions are required'),
    importantNote: z.string().trim().optional().nullable(),
    cancellationPolicy: z.string().trim().min(1, 'Cancellation policy is required'),
    videoUrl: z.string().url('Invalid video URL').optional().nullable(),
    brochurePdfUrl: z.string().url('Invalid brochure PDF URL').optional().nullable(),
    status: z.enum(TourStatusEnum).optional().default('DRAFT'),
    tourCategoryIds: uniqueUuidArraySchema('Tour categories'),
    transportationCategoryIds: uniqueUuidArraySchema('Transportation categories'),
    destinationIds: uniqueUuidArraySchema('Tour destinations'),
  })
  .superRefine((value, ctx) => {
    if (value.maxGuests < value.minGuests) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['maxGuests'],
        message: 'Max guests must be greater than or equal to min guests',
      })
    }
  })
  .meta({ id: 'CreateTour' })

export class CreateTourDto extends createZodDto(CreateTourSchema) {}
