import { Prisma } from '@/generated/prisma/client'

import { TourResponseDto } from '@/modules/tour/dto/response/tour-response.dto'

export const TOUR_INCLUDE = {
  tourCategoryRelations: true,
  tourDestinations: true,
  tourTransportations: true,
} satisfies Prisma.TourInclude

export type TourWithRelations = Prisma.TourGetPayload<{ include: typeof TOUR_INCLUDE }>

export class TourMapper {
  static toResponse(tour: TourWithRelations): InstanceType<typeof TourResponseDto> {
    return {
      id: tour.id,
      agentId: tour.agentId,
      name: tour.name,
      code: tour.code,
      departureId: tour.departureId,
      durationDays: tour.durationDays,
      durationNights: tour.durationNights,
      minGuests: tour.minGuests,
      maxGuests: tour.maxGuests,
      description: tour.description,
      highlights: tour.highlights,
      inclusions: tour.inclusions,
      exclusions: tour.exclusions,
      importantNote: tour.importantNote,
      cancellationPolicy: tour.cancellationPolicy,
      videoUrl: tour.videoUrl,
      brochurePdfUrl: tour.brochurePdfUrl,
      status: tour.status ?? 'DRAFT',
      tourCategoryIds: tour.tourCategoryRelations.map((relation) => relation.tourCategoryId),
      transportationCategoryIds: tour.tourTransportations.map((relation) => relation.transportationCategoryId),
      destinationIds: tour.tourDestinations.map((relation) => relation.destinationId),
      createdAt: tour.createdAt.toISOString(),
      updatedAt: tour.updatedAt.toISOString(),
    }
  }

  static toResponseList(tours: TourWithRelations[]): Array<InstanceType<typeof TourResponseDto>> {
    return tours.map((tour) => TourMapper.toResponse(tour))
  }
}
