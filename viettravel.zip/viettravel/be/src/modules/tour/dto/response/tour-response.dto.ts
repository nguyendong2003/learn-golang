import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

import { TourStatusEnum } from '@/generated/prisma/enums'

export const TourResponseSchema = z
  .object({
    id: z.string().uuid(),
    agentId: z.string().uuid(),
    name: z.string(),
    code: z.string(),
    departureId: z.string().uuid(),
    durationDays: z.number().int(),
    durationNights: z.number().int(),
    minGuests: z.number().int(),
    maxGuests: z.number().int(),
    description: z.string(),
    highlights: z.array(z.string()),
    inclusions: z.array(z.string()),
    exclusions: z.array(z.string()),
    importantNote: z.string().nullable(),
    cancellationPolicy: z.string(),
    videoUrl: z.string().nullable(),
    brochurePdfUrl: z.string().nullable(),
    status: z.enum(TourStatusEnum),
    tourCategoryIds: z.array(z.string().uuid()),
    transportationCategoryIds: z.array(z.string().uuid()),
    destinationIds: z.array(z.string().uuid()),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .meta({ id: 'TourResponse' })

export class TourResponseDto extends createZodDto(TourResponseSchema) {}
