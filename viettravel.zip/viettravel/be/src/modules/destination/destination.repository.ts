import { Injectable } from '@nestjs/common'
import { PrismaService } from '@/prisma/prisma.service'
import { UpdateDestinationDto } from '@/modules/destination/dto/request/update-destination.dto'
import { CreateDestinationDto } from '@/modules/destination/dto/request/create-destination.dto'

@Injectable()
export class DestinationRepository {
  constructor(private prisma: PrismaService) {}

  async findMany(skip?: number, take?: number) {
    return this.prisma.destination.findMany({
      where: { deletedAt: null },
      skip: skip || 0,
      take: take || 100,
      orderBy: { createdAt: 'desc' },
    })
  }

  async count(where: Record<string, any> = {}) {
    return this.prisma.destination.count({ where: { deletedAt: null, ...where } })
  }

  async findById(id: string) {
    return this.prisma.destination.findUnique({
      where: { id, deletedAt: null },
    })
  }

  async findBySlug(slug: string) {
    return this.prisma.destination.findUnique({
      where: { slug, deletedAt: null },
    })
  }

  async findChildren(parentId: string) {
    return this.prisma.destination.findMany({
      where: { parentId, deletedAt: null },
      orderBy: { name: 'asc' },
    })
  }

  async findFeatured() {
    return this.prisma.destination.findMany({
      where: { isFeatured: true, deletedAt: null },
      orderBy: { createdAt: 'desc' },
    })
  }

  async create(createDestinationDto: CreateDestinationDto) {
    return this.prisma.destination.create({
      data: {
        ...createDestinationDto,
      },
    })
  }

  async update(id: string, updateDestinationDto: UpdateDestinationDto) {
    return this.prisma.destination.update({
      where: { id, deletedAt: null },
      data: updateDestinationDto,
    })
  }

  async delete(id: string) {
    return this.prisma.destination.update({
      where: { id, deletedAt: null },
      data: { deletedAt: new Date() },
    })
  }
}
