import { Injectable } from '@nestjs/common'
import { DestinationResponseDto } from '@/modules/destination/dto/response/destination-response.dto'
import { DestinationMapper } from '@/modules/destination/dto/destination.mapper'
import { UpdateDestinationDto } from '@/modules/destination/dto/request/update-destination.dto'
import { CreateDestinationDto } from '@/modules/destination/dto/request/create-destination.dto'
import { QueryDestinationDto } from '@/modules/destination/dto/request/query-destination.dto'
import { DestinationRepository } from '@/modules/destination/destination.repository'
import {
  AppBadRequestException,
  ResourceConflictException,
  ResourceNotFoundException,
} from '@/common/errors/business.exception'
import { Logger } from '@nestjs/common'
import { PaginatedResult, PaginationHelper } from '@/common/dtos/pagination'

@Injectable()
export class DestinationsService {
  private readonly logger = new Logger(DestinationsService.name)

  constructor(private destinationRepository: DestinationRepository) {}

  async getDestinations(query: QueryDestinationDto): Promise<PaginatedResult<DestinationResponseDto>> {
    try {
      const { page, limit } = query
      const { skip, take } = PaginationHelper.getSkipTake(page, limit)
      const [destinations, total] = await Promise.all([
        this.destinationRepository.findMany(skip, take),
        this.destinationRepository.count(),
      ])

      const data = DestinationMapper.toResponseList(destinations)
      const meta = PaginationHelper.getMeta(page, limit, total)

      return new PaginatedResult(data, meta)
    } catch (error) {
      this.logger.error(`Failed to get destinations: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async getDestinationById(id: string): Promise<DestinationResponseDto> {
    try {
      const destination = await this.destinationRepository.findById(id)
      if (!destination || destination.deletedAt) {
        throw new ResourceNotFoundException('Destination not found')
      }
      return DestinationMapper.toResponse(destination)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(`Failed to get destination ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async getDestinationBySlug(slug: string): Promise<DestinationResponseDto> {
    try {
      const destination = await this.destinationRepository.findBySlug(slug)
      if (!destination || destination.deletedAt) {
        throw new ResourceNotFoundException('Destination not found')
      }
      return DestinationMapper.toResponse(destination)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to get destination by slug ${slug}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async getDestinationChildren(parentId: string): Promise<DestinationResponseDto[]> {
    try {
      // Verify parent exists
      const parent = await this.destinationRepository.findById(parentId)
      if (!parent || parent.deletedAt) {
        throw new ResourceNotFoundException('Parent destination not found')
      }

      const children = await this.destinationRepository.findChildren(parentId)
      return DestinationMapper.toResponseList(children)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to get children for destination ${parentId}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async getFeaturedDestinations(): Promise<DestinationResponseDto[]> {
    try {
      const destinations = await this.destinationRepository.findFeatured()
      return DestinationMapper.toResponseList(destinations)
    } catch (error) {
      this.logger.error(
        `Failed to get featured destinations: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async createDestination(createDestinationDto: CreateDestinationDto): Promise<DestinationResponseDto> {
    try {
      // Check if slug already exists
      const existingSlug = await this.destinationRepository.findBySlug(createDestinationDto.slug)
      if (existingSlug) {
        throw new ResourceConflictException('Destination with this slug already exists')
      }

      // Verify parent exists if parentId is provided
      if (createDestinationDto.parentId) {
        const parent = await this.destinationRepository.findById(createDestinationDto.parentId)
        if (!parent || parent.deletedAt) {
          throw new ResourceNotFoundException('Parent destination not found')
        }
      }

      const destination = await this.destinationRepository.create(createDestinationDto)
      return DestinationMapper.toResponse(destination)
    } catch (error) {
      if (error instanceof (ResourceConflictException || ResourceNotFoundException)) throw error
      this.logger.error(`Failed to create destination: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async updateDestination(id: string, updateDestinationDto: UpdateDestinationDto): Promise<DestinationResponseDto> {
    try {
      const existing = await this.destinationRepository.findById(id)
      if (!existing || existing.deletedAt) {
        throw new ResourceNotFoundException('Destination not found')
      }

      // Check if new slug conflicts with other destinations
      if (updateDestinationDto.slug && updateDestinationDto.slug !== existing.slug) {
        const slugConflict = await this.destinationRepository.findBySlug(updateDestinationDto.slug)
        if (slugConflict && slugConflict.id !== id) {
          throw new ResourceConflictException('Destination with this slug already exists')
        }
      }

      // Verify new parent if parentId is being changed
      if (updateDestinationDto.parentId && updateDestinationDto.parentId !== existing.parentId) {
        const parent = await this.destinationRepository.findById(updateDestinationDto.parentId)
        if (!parent || parent.deletedAt) {
          throw new ResourceNotFoundException('Parent destination not found')
        }
      }

      const updatedDestination = await this.destinationRepository.update(id, updateDestinationDto)
      return DestinationMapper.toResponse(updatedDestination)
    } catch (error) {
      if (error instanceof (ResourceNotFoundException || ResourceConflictException)) throw error
      this.logger.error(`Failed to update destination ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async deleteDestination(id: string): Promise<void> {
    try {
      const existing = await this.destinationRepository.findById(id)
      if (!existing || existing.deletedAt) {
        throw new ResourceNotFoundException('Destination not found')
      }

      // Check if destination has children - cannot delete if it has children
      const children = await this.destinationRepository.findChildren(id)
      if (children.length > 0) {
        throw new AppBadRequestException('Cannot delete destination with children')
      }

      await this.destinationRepository.delete(id)
    } catch (error) {
      if (error instanceof (ResourceNotFoundException || AppBadRequestException)) throw error
      this.logger.error(`Failed to delete destination ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }
}
