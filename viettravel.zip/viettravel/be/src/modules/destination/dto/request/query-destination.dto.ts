import { PaginationQuerySchema } from '@/common/dtos/pagination.query'
import { createZodDto } from 'nestjs-zod'

export const QueryDestinationSchema = PaginationQuerySchema.meta({ id: 'QueryDestination' })

export class QueryDestinationDto extends createZodDto(QueryDestinationSchema) {}
