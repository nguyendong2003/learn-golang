import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const CreateDestinationSchema = z
  .strictObject({
    parentId: z.string().uuid().optional().nullable(),
    level: z.enum(['PROVINCE', 'WARD', 'PLACE']),
    name: z.string().trim().min(1, 'Name is required').max(255, 'Name must be at most 255 characters'),
    administrativeCode: z
      .string()
      .trim()
      .max(20, 'Administrative code must be at most 20 characters')
      .optional()
      .nullable(),
    description: z.string().trim().optional().nullable(),
    imageUrl: z.string().url('Invalid image URL').optional().nullable(),
    lat: z.number().min(-90).max(90).optional().nullable(),
    lng: z.number().min(-180).max(180).optional().nullable(),
    slug: z.string().trim().min(1, 'Slug is required').max(255, 'Slug must be at most 255 characters'),
    isFeatured: z.boolean().optional().default(false),
  })
  .meta({ id: 'CreateDestination' })

export class CreateDestinationDto extends createZodDto(CreateDestinationSchema) {}
