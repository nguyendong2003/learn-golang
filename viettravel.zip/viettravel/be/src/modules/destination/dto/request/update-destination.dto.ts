import { createZodDto } from 'nestjs-zod'
import { CreateDestinationSchema } from '@/modules/destination/dto/request/create-destination.dto'

export const UpdateDestinationSchema = CreateDestinationSchema.partial().meta({
  id: 'UpdateDestination',
})

export class UpdateDestinationDto extends createZodDto(UpdateDestinationSchema) {}
