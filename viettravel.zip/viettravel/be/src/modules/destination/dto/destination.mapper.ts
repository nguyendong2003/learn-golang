import { Destination, DestinationLevelEnum } from '@/generated/prisma/client'
import { DestinationResponseDto } from '@/modules/destination/dto/response/destination-response.dto'

export class DestinationMapper {
  static toResponse(destination: Destination): DestinationResponseDto {
    return {
      id: destination.id,
      parentId: destination.parentId,
      level: destination.level as DestinationLevelEnum,
      name: destination.name,
      administrativeCode: destination.administrativeCode,
      description: destination.description,
      imageUrl: destination.imageUrl,
      lat: destination.lat ? Number(destination.lat) : null,
      lng: destination.lng ? Number(destination.lng) : null,
      slug: destination.slug,
      isFeatured: destination.isFeatured,
      createdAt: destination.createdAt.toISOString(),
      updatedAt: destination.updatedAt.toISOString(),
    }
  }

  static toResponseList(destinations: Destination[]): DestinationResponseDto[] {
    return destinations.map(this.toResponse)
  }
}
