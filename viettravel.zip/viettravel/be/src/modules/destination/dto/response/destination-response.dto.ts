import { DestinationLevelEnum } from '@/generated/prisma/enums'
import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const DestinationResponseSchema = z
  .object({
    id: z.string().uuid(),
    parentId: z.string().uuid().nullable(),
    level: z.enum(DestinationLevelEnum),
    name: z.string(),
    administrativeCode: z.string().nullable(),
    description: z.string().nullable(),
    imageUrl: z.string().nullable(),
    lat: z.number().nullable(),
    lng: z.number().nullable(),
    slug: z.string(),
    isFeatured: z.boolean(),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .meta({ id: 'DestinationResponse' })

export class DestinationResponseDto extends createZodDto(DestinationResponseSchema) {}
