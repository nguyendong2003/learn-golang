import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Post, Put, Query } from '@nestjs/common'
import { DestinationsService } from '@/modules/destination/destination.service'
import { PaginatedResult } from '@/common/dtos/pagination'
import { UpdateDestinationDto } from '@/modules/destination/dto/request/update-destination.dto'
import { DestinationResponseDto } from '@/modules/destination/dto/response/destination-response.dto'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { CreateDestinationDto } from '@/modules/destination/dto/request/create-destination.dto'
import { QueryDestinationDto } from '@/modules/destination/dto/request/query-destination.dto'
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger/dist/decorators'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { ApiErrorResponse } from '@/common/decorators/api-error-responses.decorator'
import { ApiCreatedSuccessResponse } from '@/common/decorators/api-created-success-response.decorator'
import { Public } from '@/common/decorators/public.decorator'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'

@ApiBearerAuth()
@ApiTags('destinations')
@Controller('destinations')
export class DestinationsController {
  constructor(private destinationsService: DestinationsService) {}

  @Get()
  @Public()
  @SuccessMessage('Destinations retrieved successfully')
  @ApiSuccessResponse({ type: DestinationResponseDto, isArray: true, hasMeta: true })
  @ApiErrorResponse('Invalid destination list query')
  async getDestinations(@Query() query: QueryDestinationDto): Promise<PaginatedResult<DestinationResponseDto>> {
    return await this.destinationsService.getDestinations(query)
  }

  @Get('featured')
  @Public()
  @SuccessMessage('Featured destinations retrieved successfully')
  @ApiSuccessResponse({ type: DestinationResponseDto, isArray: true })
  @ApiErrorResponse('Failed to retrieve featured destinations')
  async getFeaturedDestinations(): Promise<DestinationResponseDto[]> {
    return await this.destinationsService.getFeaturedDestinations()
  }

  @Get('slug/:slug')
  @Public()
  @SuccessMessage('Destination retrieved successfully')
  @ApiParam({ name: 'slug', type: String, description: 'Destination slug' })
  @ApiSuccessResponse({ type: DestinationResponseDto, description: 'Destination retrieved successfully' })
  @ApiErrorResponse('Invalid slug or destination not found')
  async getDestinationBySlug(@Param('slug') slug: string): Promise<DestinationResponseDto> {
    return await this.destinationsService.getDestinationBySlug(slug)
  }

  @Get(':id')
  @Public()
  @SuccessMessage('Destination retrieved successfully')
  @ApiParam({ name: 'id', type: String, description: 'Destination ID (UUID)' })
  @ApiSuccessResponse({ type: DestinationResponseDto, description: 'Destination retrieved successfully' })
  @ApiErrorResponse('Invalid destination id or destination not found')
  async getDestinationById(@Param('id', new ParseUUIDPipe()) id: string): Promise<DestinationResponseDto> {
    return await this.destinationsService.getDestinationById(id)
  }

  @Get(':id/children')
  @Public()
  @SuccessMessage('Destination children retrieved successfully')
  @ApiParam({ name: 'id', type: String, description: 'Parent Destination ID (UUID)' })
  @ApiSuccessResponse({ type: DestinationResponseDto, isArray: true })
  @ApiErrorResponse('Invalid destination id')
  async getDestinationChildren(@Param('id', new ParseUUIDPipe()) id: string): Promise<DestinationResponseDto[]> {
    return await this.destinationsService.getDestinationChildren(id)
  }

  @Post()
  @Permission(PermissionCode.DESTINATION_CREATE)
  @SuccessMessage('Destination created successfully')
  @ApiCreatedSuccessResponse({ type: DestinationResponseDto, description: 'Destination created successfully' })
  @ApiErrorResponse('Invalid destination payload')
  async createDestination(@Body() createDestinationDto: CreateDestinationDto): Promise<DestinationResponseDto> {
    return await this.destinationsService.createDestination(createDestinationDto)
  }

  @Put(':id')
  @Permission(PermissionCode.DESTINATION_UPDATE)
  @SuccessMessage('Destination updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'Destination ID (UUID)' })
  @ApiSuccessResponse({ type: DestinationResponseDto, description: 'Destination updated successfully' })
  @ApiErrorResponse('Invalid destination id or payload')
  async updateDestination(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateDestinationDto: UpdateDestinationDto,
  ): Promise<DestinationResponseDto> {
    return await this.destinationsService.updateDestination(id, updateDestinationDto)
  }

  @Permission(PermissionCode.DESTINATION_DELETE)
  @Delete(':id')
  @SuccessMessage('Destination deleted successfully')
  @ApiParam({ name: 'id', type: String, description: 'Destination ID (UUID)' })
  @ApiSuccessResponse({ type: DestinationResponseDto, hasData: false, description: 'Destination deleted successfully' })
  @ApiErrorResponse('Invalid destination id or destination not found')
  async deleteDestination(@Param('id', new ParseUUIDPipe()) id: string): Promise<void> {
    return await this.destinationsService.deleteDestination(id)
  }
}
