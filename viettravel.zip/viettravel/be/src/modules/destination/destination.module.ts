import { Module } from '@nestjs/common'
import { DestinationsService } from '@/modules/destination/destination.service'
import { DestinationsController } from '@/modules/destination/destination.controller'
import { DestinationRepository } from '@/modules/destination/destination.repository'

@Module({
  imports: [],
  providers: [DestinationsService, DestinationRepository],
  controllers: [DestinationsController],
})
export class DestinationsModule {}
