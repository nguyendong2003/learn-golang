import { Injectable, Logger } from '@nestjs/common'
import { TourCategoryResponseDto } from '@/modules/tour-category/dto/response/tour-category-response.dto'
import { TourCategoryMapper } from '@/modules/tour-category/dto/tour-category.mapper'
import { UpdateTourCategoryDto } from '@/modules/tour-category/dto/request/update-tour-category.dto'
import { CreateTourCategoryDto } from '@/modules/tour-category/dto/request/create-tour-category.dto'
import { QueryTourCategoryDto } from '@/modules/tour-category/dto/request/query-tour-category.dto'
import { UpdateTourCategorySortOrderDto } from '@/modules/tour-category/dto/request/update-tour-category-sort-order.dto'
import { TourCategoryRepository } from '@/modules/tour-category/tour-category.repository'
import {
  AppBadRequestException,
  ResourceConflictException,
  ResourceNotFoundException,
} from '@/common/errors/business.exception'
import { PaginatedResult, PaginationHelper } from '@/common/dtos/pagination'

@Injectable()
export class TourCategoryService {
  private readonly logger = new Logger(TourCategoryService.name)

  constructor(private tourCategoryRepository: TourCategoryRepository) {}

  async getTourCategories(query: QueryTourCategoryDto): Promise<PaginatedResult<TourCategoryResponseDto>> {
    try {
      const { page, limit } = query
      const { skip, take } = PaginationHelper.getSkipTake(page, limit)
      const [tourCategories, total] = await Promise.all([
        this.tourCategoryRepository.findMany(skip, take),
        this.tourCategoryRepository.count(),
      ])

      const data = TourCategoryMapper.toResponseList(tourCategories)
      const meta = PaginationHelper.getMeta(page, limit, total)

      return new PaginatedResult(data, meta)
    } catch (error) {
      this.logger.error(`Failed to get tour categories: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async getTourCategoryById(id: string): Promise<TourCategoryResponseDto> {
    try {
      const tourCategory = await this.tourCategoryRepository.findById(id)
      if (!tourCategory || tourCategory.deletedAt) {
        throw new ResourceNotFoundException('Tour category not found')
      }
      return TourCategoryMapper.toResponse(tourCategory)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(`Failed to get tour category ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async getTourCategoryBySlug(slug: string): Promise<TourCategoryResponseDto> {
    try {
      const tourCategory = await this.tourCategoryRepository.findBySlug(slug)
      if (!tourCategory || tourCategory.deletedAt) {
        throw new ResourceNotFoundException('Tour category not found')
      }
      return TourCategoryMapper.toResponse(tourCategory)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to get tour category by slug ${slug}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async createTourCategory(createTourCategoryDto: CreateTourCategoryDto): Promise<TourCategoryResponseDto> {
    try {
      const existingName = await this.tourCategoryRepository.findByName(createTourCategoryDto.name)
      if (existingName) {
        throw new ResourceConflictException('Tour category with this name already exists')
      }

      const existingSlug = await this.tourCategoryRepository.findBySlug(createTourCategoryDto.slug)
      if (existingSlug) {
        throw new ResourceConflictException('Tour category with this slug already exists')
      }

      const tourCategory = await this.tourCategoryRepository.create(createTourCategoryDto)
      return TourCategoryMapper.toResponse(tourCategory)
    } catch (error) {
      if (error instanceof ResourceConflictException) throw error
      this.logger.error(`Failed to create tour category: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async updateTourCategory(id: string, updateTourCategoryDto: UpdateTourCategoryDto): Promise<TourCategoryResponseDto> {
    try {
      const existing = await this.tourCategoryRepository.findById(id)
      if (!existing || existing.deletedAt) {
        throw new ResourceNotFoundException('Tour category not found')
      }

      if (updateTourCategoryDto.slug && updateTourCategoryDto.slug !== existing.slug) {
        const slugConflict = await this.tourCategoryRepository.findBySlug(updateTourCategoryDto.slug)
        if (slugConflict && slugConflict.id !== id) {
          throw new ResourceConflictException('Tour category with this slug already exists')
        }
      }

      const updated = await this.tourCategoryRepository.update(id, updateTourCategoryDto)
      return TourCategoryMapper.toResponse(updated)
    } catch (error) {
      if (error instanceof (ResourceNotFoundException || ResourceConflictException)) throw error
      this.logger.error(
        `Failed to update tour category ${id}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async updateSortOrder(updateSortOrderDto: UpdateTourCategorySortOrderDto): Promise<TourCategoryResponseDto[]> {
    try {
      const ids = updateSortOrderDto.items.map((item) => item.id)
      const uniqueIds = new Set(ids)

      if (uniqueIds.size !== ids.length) {
        throw new AppBadRequestException('Duplicate tour category ids in sort order payload')
      }

      const existing = await this.tourCategoryRepository.findManyByIds(ids)
      if (existing.length !== ids.length) {
        throw new ResourceNotFoundException('One or more tour categories not found')
      }

      await this.tourCategoryRepository.updateSortOrders(updateSortOrderDto.items)
      const updated = await this.tourCategoryRepository.findManyByIds(ids)
      return TourCategoryMapper.toResponseList(updated)
    } catch (error) {
      if (error instanceof AppBadRequestException || error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to update tour category sort order: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async deleteTourCategory(id: string): Promise<void> {
    try {
      const existing = await this.tourCategoryRepository.findById(id)
      if (!existing || existing.deletedAt) {
        throw new ResourceNotFoundException('Tour category not found')
      }

      const relationCount = await this.tourCategoryRepository.countRelations(id)
      if (relationCount > 0) {
        throw new AppBadRequestException('Cannot delete tour category with related tours')
      }

      await this.tourCategoryRepository.delete(id)
    } catch (error) {
      if (error instanceof (ResourceNotFoundException || AppBadRequestException)) throw error
      this.logger.error(
        `Failed to delete tour category ${id}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }
}
