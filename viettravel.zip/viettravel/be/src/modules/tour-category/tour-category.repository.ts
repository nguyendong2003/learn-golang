import { Injectable } from '@nestjs/common'
import { PrismaService } from '@/prisma/prisma.service'
import { UpdateTourCategoryDto } from '@/modules/tour-category/dto/request/update-tour-category.dto'
import { CreateTourCategoryDto } from '@/modules/tour-category/dto/request/create-tour-category.dto'

@Injectable()
export class TourCategoryRepository {
  constructor(private prisma: PrismaService) {}

  async findMany(skip?: number, take?: number) {
    return this.prisma.tourCategory.findMany({
      where: { deletedAt: null },
      skip: skip || 0,
      take: take || 100,
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
    })
  }

  async count(where: Record<string, any> = {}) {
    return this.prisma.tourCategory.count({ where: { deletedAt: null, ...where } })
  }

  async findById(id: string) {
    return this.prisma.tourCategory.findFirst({
      where: { id, deletedAt: null },
    })
  }

  async findBySlug(slug: string) {
    return this.prisma.tourCategory.findFirst({
      where: { slug, deletedAt: null },
    })
  }

  async findByName(name: string) {
    return this.prisma.tourCategory.findFirst({
      where: { name, deletedAt: null },
    })
  }

  async create(createTourCategoryDto: CreateTourCategoryDto) {
    return this.prisma.tourCategory.create({
      data: {
        ...createTourCategoryDto,
      },
    })
  }

  async update(id: string, updateTourCategoryDto: UpdateTourCategoryDto) {
    return this.prisma.tourCategory.update({
      where: { id },
      data: updateTourCategoryDto,
    })
  }

  async delete(id: string) {
    return this.prisma.tourCategory.update({
      where: { id },
      data: { deletedAt: new Date() },
    })
  }

  async countRelations(tourCategoryId: string) {
    return this.prisma.tourCategoryRelation.count({
      where: { tourCategoryId },
    })
  }

  async findManyByIds(ids: string[]) {
    return this.prisma.tourCategory.findMany({
      where: { id: { in: ids }, deletedAt: null },
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
    })
  }

  async updateSortOrders(items: Array<{ id: string; sortOrder: number }>) {
    const updates = items.map((item) =>
      this.prisma.tourCategory.update({
        where: { id: item.id },
        data: { sortOrder: item.sortOrder },
      }),
    )

    return this.prisma.$transaction(updates)
  }
}
