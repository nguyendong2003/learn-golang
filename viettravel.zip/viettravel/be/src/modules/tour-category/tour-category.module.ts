import { Module } from '@nestjs/common'
import { TourCategoryService } from '@/modules/tour-category/tour-category.service'
import { TourCategoryController } from '@/modules/tour-category/tour-category.controller'
import { TourCategoryRepository } from '@/modules/tour-category/tour-category.repository'

@Module({
  imports: [],
  providers: [TourCategoryService, TourCategoryRepository],
  controllers: [TourCategoryController],
})
export class TourCategoryModule {}
