import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Post, Put, Query } from '@nestjs/common'
import { TourCategoryService } from '@/modules/tour-category/tour-category.service'
import { PaginatedResult } from '@/common/dtos/pagination'
import { UpdateTourCategoryDto } from '@/modules/tour-category/dto/request/update-tour-category.dto'
import { TourCategoryResponseDto } from '@/modules/tour-category/dto/response/tour-category-response.dto'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { CreateTourCategoryDto } from '@/modules/tour-category/dto/request/create-tour-category.dto'
import { QueryTourCategoryDto } from '@/modules/tour-category/dto/request/query-tour-category.dto'
import { UpdateTourCategorySortOrderDto } from '@/modules/tour-category/dto/request/update-tour-category-sort-order.dto'
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger/dist/decorators'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { ApiErrorResponse } from '@/common/decorators/api-error-responses.decorator'
import { ApiCreatedSuccessResponse } from '@/common/decorators/api-created-success-response.decorator'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'
import { Public } from '@/common/decorators/public.decorator'

@ApiBearerAuth()
@ApiTags('tour-categories')
@Controller('tour-categories')
export class TourCategoryController {
  constructor(private tourCategoryService: TourCategoryService) {}

  @Get()
  @Public()
  @SuccessMessage('Tour categories retrieved successfully')
  @ApiSuccessResponse({ type: TourCategoryResponseDto, isArray: true, hasMeta: true })
  @ApiErrorResponse('Invalid tour category list query')
  async getTourCategories(@Query() query: QueryTourCategoryDto): Promise<PaginatedResult<TourCategoryResponseDto>> {
    return await this.tourCategoryService.getTourCategories(query)
  }

  @Get('slug/:slug')
  @Public()
  @SuccessMessage('Tour category retrieved successfully')
  @ApiParam({ name: 'slug', type: String, description: 'Tour category slug' })
  @ApiSuccessResponse({ type: TourCategoryResponseDto, description: 'Tour category retrieved successfully' })
  @ApiErrorResponse('Invalid slug or tour category not found')
  async getTourCategoryBySlug(@Param('slug') slug: string): Promise<TourCategoryResponseDto> {
    return await this.tourCategoryService.getTourCategoryBySlug(slug)
  }

  @Get(':id')
  @Public()
  @SuccessMessage('Tour category retrieved successfully')
  @ApiParam({ name: 'id', type: String, description: 'Tour category ID (UUID)' })
  @ApiSuccessResponse({ type: TourCategoryResponseDto, description: 'Tour category retrieved successfully' })
  @ApiErrorResponse('Invalid tour category id or tour category not found')
  async getTourCategoryById(@Param('id', new ParseUUIDPipe()) id: string): Promise<TourCategoryResponseDto> {
    return await this.tourCategoryService.getTourCategoryById(id)
  }

  @Post()
  @Permission(PermissionCode.TOUR_CATEGORY_CREATE)
  @SuccessMessage('Tour category created successfully')
  @ApiCreatedSuccessResponse({ type: TourCategoryResponseDto, description: 'Tour category created successfully' })
  @ApiErrorResponse('Invalid tour category payload')
  async createTourCategory(@Body() createTourCategoryDto: CreateTourCategoryDto): Promise<TourCategoryResponseDto> {
    return await this.tourCategoryService.createTourCategory(createTourCategoryDto)
  }

  @Put('sort-order')
  @Permission(PermissionCode.TOUR_CATEGORY_UPDATE)
  @SuccessMessage('Tour category sort order updated successfully')
  @ApiSuccessResponse({ type: TourCategoryResponseDto, isArray: true, description: 'Sort order updated successfully' })
  @ApiErrorResponse('Invalid sort order payload')
  async updateSortOrder(
    @Body() updateSortOrderDto: UpdateTourCategorySortOrderDto,
  ): Promise<TourCategoryResponseDto[]> {
    return await this.tourCategoryService.updateSortOrder(updateSortOrderDto)
  }

  @Put(':id')
  @Permission(PermissionCode.TOUR_CATEGORY_UPDATE)
  @SuccessMessage('Tour category updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'Tour category ID (UUID)' })
  @ApiSuccessResponse({ type: TourCategoryResponseDto, description: 'Tour category updated successfully' })
  @ApiErrorResponse('Invalid tour category id or payload')
  async updateTourCategory(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateTourCategoryDto: UpdateTourCategoryDto,
  ): Promise<TourCategoryResponseDto> {
    return await this.tourCategoryService.updateTourCategory(id, updateTourCategoryDto)
  }

  @Delete(':id')
  @Permission(PermissionCode.TOUR_CATEGORY_DELETE)
  @SuccessMessage('Tour category deleted successfully')
  @ApiParam({ name: 'id', type: String, description: 'Tour category ID (UUID)' })
  @ApiSuccessResponse({
    type: TourCategoryResponseDto,
    hasData: false,
    description: 'Tour category deleted successfully',
  })
  @ApiErrorResponse('Invalid tour category id or tour category not found')
  async deleteTourCategory(@Param('id', new ParseUUIDPipe()) id: string): Promise<void> {
    return await this.tourCategoryService.deleteTourCategory(id)
  }
}
