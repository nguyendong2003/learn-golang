import { createZodDto } from 'nestjs-zod'
import { CreateTourCategorySchema } from '@/modules/tour-category/dto/request/create-tour-category.dto'

export const UpdateTourCategorySchema = CreateTourCategorySchema.partial().meta({
  id: 'UpdateTourCategory',
})

export class UpdateTourCategoryDto extends createZodDto(UpdateTourCategorySchema) {}
