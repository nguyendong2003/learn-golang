import { PaginationQuerySchema } from '@/common/dtos/pagination.query'
import { createZodDto } from 'nestjs-zod'

export const QueryTourCategorySchema = PaginationQuerySchema.meta({ id: 'QueryTourCategory' })

export class QueryTourCategoryDto extends createZodDto(QueryTourCategorySchema) {}
