import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const UpdateTourCategorySortOrderSchema = z
  .strictObject({
    items: z
      .array(
        z.strictObject({
          id: z.string().uuid(),
          sortOrder: z.number().int().min(1, 'Sort order must be at least 1'),
        }),
      )
      .min(1, 'At least one item is required'),
  })
  .meta({ id: 'UpdateTourCategorySortOrder' })

export class UpdateTourCategorySortOrderDto extends createZodDto(UpdateTourCategorySortOrderSchema) {}
