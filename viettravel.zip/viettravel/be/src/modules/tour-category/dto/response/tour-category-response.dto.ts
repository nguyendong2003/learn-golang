import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const TourCategoryResponseSchema = z
  .object({
    id: z.string().uuid(),
    name: z.string(),
    slug: z.string(),
    description: z.string().nullable(),
    iconUrl: z.string().nullable(),
    sortOrder: z.number(),
    isActive: z.boolean(),
    createdAt: z.string().datetime(),
    updatedAt: z.string().datetime(),
  })
  .meta({ id: 'TourCategoryResponse' })

export class TourCategoryResponseDto extends createZodDto(TourCategoryResponseSchema) {}
