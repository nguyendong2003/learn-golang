import { TourCategory } from '@/generated/prisma/client'
import { TourCategoryResponseDto } from '@/modules/tour-category/dto/response/tour-category-response.dto'

export class TourCategoryMapper {
  static toResponse(tourCategory: TourCategory): TourCategoryResponseDto {
    return {
      id: tourCategory.id,
      name: tourCategory.name,
      slug: tourCategory.slug,
      description: tourCategory.description,
      iconUrl: tourCategory.iconUrl,
      sortOrder: tourCategory.sortOrder,
      isActive: tourCategory.isActive,
      createdAt: tourCategory.createdAt.toISOString(),
      updatedAt: tourCategory.updatedAt.toISOString(),
    }
  }

  static toResponseList(tourCategories: TourCategory[]): TourCategoryResponseDto[] {
    return tourCategories.map(this.toResponse)
  }
}
