import { Module, Global } from '@nestjs/common'
import { AuditService } from './audit.service'
import { PrismaModule } from '@/prisma/prisma.module'

@Global()
@Module({
  imports: [],
  providers: [AuditService],
  exports: [AuditService],
})
export class AuditModule {}
