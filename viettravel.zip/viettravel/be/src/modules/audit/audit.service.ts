import { Injectable, Logger } from '@nestjs/common'
import { PrismaService } from '@/prisma/prisma.service'

@Injectable()
export class AuditService {
  private readonly logger = new Logger(AuditService.name)

  constructor(private readonly prisma: PrismaService) {}

  async logStaffAction(userId: string, action: string, ipAddress?: string, userAgent?: string) {
    try {
      await this.prisma.staffAuditLog.create({
        data: {
          userId,
          action,
          ipAddress,
          userAgent,
        },
      })
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : String(error)
      this.logger.error(`Failed to log staff action: ${errorMessage}`)
    }
  }
}
