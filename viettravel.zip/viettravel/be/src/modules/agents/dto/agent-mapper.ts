import { Agent } from '@/generated/prisma/client'

import { AgentResponseDto } from './response/agent-response.dto'

export class AgentsMapper {
  static toResponse(this: void, agent: Agent): InstanceType<typeof AgentResponseDto> {
    return {
      id: agent.id,
      userId: agent.userId,
      agentCode: agent.agentCode,
      businessName: agent.businessName,
      taxCode: agent.taxCode,
      licenseUrl: agent.licenseUrl,
      representativeName: agent.representativeName,
      representativeIdNumber: agent.representativeIdNumber,
      logoUrl: agent.logoUrl,
      coverUrl: agent.coverUrl,
      description: agent.description,
      establishedYear: agent.establishedYear,
      companySize: agent.companySize,
      workingHours: agent.workingHours,
      websiteUrl: agent.websiteUrl,
      facebookUrl: agent.facebookUrl,
      zaloUrl: agent.zaloUrl,
      instagramUrl: agent.instagramUrl,
      businessAddress: agent.businessAddress,
      businessPhone: agent.businessPhone,
      supportEmail: agent.supportEmail,
      status: agent.status ?? 'PENDING',
      statusNote: agent.statusNote,
      createdAt: agent.createdAt?.toISOString() ?? new Date(0).toISOString(),
      updatedAt: agent.updatedAt?.toISOString() ?? new Date(0).toISOString(),
    }
  }

  static toResponseList(agents: Agent[]): Array<InstanceType<typeof AgentResponseDto>> {
    return agents.map(AgentsMapper.toResponse)
  }
}
