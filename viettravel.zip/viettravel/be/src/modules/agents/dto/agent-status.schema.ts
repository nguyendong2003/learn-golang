import { z } from 'zod'
import { AgentStatusEnum } from '@/generated/prisma/enums'

export const AgentStatusEnumSchema = z.enum(AgentStatusEnum)
