import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

import { AgentStatusEnum } from '@/generated/prisma/enums'

export const AgentResponseSchema = z
  .object({
    id: z.uuid(),
    userId: z.uuid(),

    agentCode: z.string(),

    businessName: z.string().nullable(),
    taxCode: z.string(),

    licenseUrl: z.url().nullable(),

    representativeName: z.string().nullable(),
    representativeIdNumber: z.string().nullable(),

    logoUrl: z.url().nullable(),
    coverUrl: z.url().nullable(),

    description: z.string().nullable(),

    establishedYear: z.number().int().nullable(),

    companySize: z.string().nullable(),
    workingHours: z.string().nullable(),

    websiteUrl: z.url().nullable(),
    facebookUrl: z.url().nullable(),
    zaloUrl: z.url().nullable(),
    instagramUrl: z.url().nullable(),

    businessAddress: z.string().nullable(),
    businessPhone: z.string().nullable(),
    supportEmail: z.email().nullable(),

    status: z.enum(AgentStatusEnum),
    statusNote: z.string().nullable(),

    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
  })
  .meta({ id: 'AgentResponse' })

export class AgentResponseDto extends createZodDto(AgentResponseSchema) {}
