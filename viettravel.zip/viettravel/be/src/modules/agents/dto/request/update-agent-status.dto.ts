import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const UpdateAgentStatusSchema = z
  .strictObject({
    statusNote: z.string().trim().optional(),
  })
  .meta({ id: 'UpdateAgentStatus' })

export class UpdateAgentStatusDto extends createZodDto(UpdateAgentStatusSchema) {}
