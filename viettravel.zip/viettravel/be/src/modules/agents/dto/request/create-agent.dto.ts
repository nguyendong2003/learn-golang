import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const CreateAgentSchema = z
  .strictObject({
    businessName: z.string().trim().max(255).optional(),
    taxCode: z.string().trim().min(1).max(50),
    licenseUrl: z.url().optional(),
    representativeName: z.string().trim().max(255).optional(),
    representativeIdNumber: z.string().trim().max(20).optional(),
    logoUrl: z.url().optional(),
    coverUrl: z.url().optional(),
    description: z.string().optional(),
    establishedYear: z.number().int().optional(),
    companySize: z.string().trim().max(50).optional(),
    workingHours: z.string().trim().max(255).optional(),
    websiteUrl: z.url().optional(),
    facebookUrl: z.url().optional(),
    zaloUrl: z.url().optional(),
    instagramUrl: z.url().optional(),
    businessAddress: z.string().optional(),
    businessPhone: z.string().trim().max(20).optional(),
    supportEmail: z.email().optional(),
  })
  .meta({ id: 'CreateAgent' })

export class CreateAgentDto extends createZodDto(CreateAgentSchema) {}
