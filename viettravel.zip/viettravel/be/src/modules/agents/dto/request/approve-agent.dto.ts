import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const ApproveAgentSchema = z
  .strictObject({
    statusNote: z.string().optional(),
  })
  .meta({ id: 'ApproveAgent' })

export class ApproveAgentDto extends createZodDto(ApproveAgentSchema) {}
