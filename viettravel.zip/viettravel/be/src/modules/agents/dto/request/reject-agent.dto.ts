import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const RejectAgentSchema = z
  .strictObject({
    statusNote: z.string().min(1),
  })
  .meta({ id: 'RejectAgent' })

export class RejectAgentDto extends createZodDto(RejectAgentSchema) {}
