import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'
import { AgentStatusEnumSchema } from '@/modules/agents/dto/agent-status.schema'

export const QueryAgentSchema = z
  .strictObject({
    search: z.string().optional(),
    status: AgentStatusEnumSchema.optional(),
    page: z.coerce.number().min(1).default(1),
    limit: z.coerce.number().min(1).max(100).default(10),
  })
  .meta({ id: 'QueryAgent' })

export class QueryAgentDto extends createZodDto(QueryAgentSchema) {}
