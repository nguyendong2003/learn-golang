import { createZodDto } from 'nestjs-zod'
import { CreateAgentSchema } from './create-agent.dto'

export const UpdateAgentSchema = CreateAgentSchema.partial()

export class UpdateAgentDto extends createZodDto(UpdateAgentSchema) {}
