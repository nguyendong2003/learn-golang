import { Module } from '@nestjs/common'

import { AgentsController } from '@/modules/agents/agent.controller'
import { AgentsService } from '@/modules/agents/agent.service'
import { AgentRepository } from '@/modules/agents/agent.repository'

@Module({
  imports: [],
  providers: [AgentsService, AgentRepository],
  controllers: [AgentsController],
  exports: [AgentsService],
})
export class AgentsModule {}
