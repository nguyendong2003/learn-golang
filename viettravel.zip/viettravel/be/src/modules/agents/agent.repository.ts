import { Injectable } from '@nestjs/common'
import { AgentStatusEnum } from '@/generated/prisma/enums'
import { Prisma } from '@/generated/prisma/client'

import { PrismaService } from '@/prisma/prisma.service'

import { CreateAgentDto } from './dto/request/create-agent.dto'
import { UpdateAgentDto } from './dto/request/update-agent.dto'
import { QueryAgentDto } from './dto/request/query-agent.dto'
// import { paginateEntities } from '@/utils/paginate'
// import { PaginationQuery } from '@/shared/dto/pagination.query'

@Injectable()
export class AgentRepository {
  constructor(private prisma: PrismaService) {}

  private findManyAgents(query: QueryAgentDto): Prisma.AgentWhereInput {
    // const { page, limit, search, status } = query

    const where: Prisma.AgentWhereInput = {
      deletedAt: null,
    }
    if (query.status) {
      where.status = query.status
    }

    if (query.search) {
      where.OR = [
        { businessName: { contains: query.search, mode: 'insensitive' } },
        { taxCode: { contains: query.search, mode: 'insensitive' } },
        { agentCode: { contains: query.search, mode: 'insensitive' } },
      ]
    }
    return where
  }

  async findPaginatedAgents(query: QueryAgentDto) {
    const skip = (query.page - 1) * query.limit
    const where = this.findManyAgents(query)
    return this.prisma.agent.findMany({
      where,
      skip,
      take: query.limit,
      orderBy: { createdAt: 'desc' },
    })
  }

  async countAgents(query: QueryAgentDto) {
    const where = this.findManyAgents(query)
    return this.prisma.agent.count({ where })
  }

  async findAgentById(id: string) {
    return this.prisma.agent.findUnique({
      where: {
        id,
        deletedAt: null,
      },
    })
  }

  async findAgentByUserId(userId: string) {
    return this.prisma.agent.findUnique({
      where: {
        userId,
        deletedAt: null,
      },
    })
  }

  async findAgentByTaxCode(taxCode: string, excludeId?: string) {
    return this.prisma.agent.findFirst({
      where: {
        taxCode,
        deletedAt: null,
        ...(excludeId && { id: { not: excludeId } }),
      },
    })
  }

  async createAgent(userId: string, agentCode: string, dto: CreateAgentDto) {
    return this.prisma.agent.create({
      data: {
        userId,
        agentCode,
        status: AgentStatusEnum.PENDING,
        ...dto,
      },
    })
  }

  async updateAgent(id: string, dto: UpdateAgentDto) {
    return this.prisma.agent.update({
      where: { id, deletedAt: null },
      data: dto,
    })
  }

  async updateStatus(id: string, status: AgentStatusEnum, statusNote?: string | null) {
    return this.prisma.agent.update({
      where: { id, deletedAt: null },
      data: {
        status,
        statusNote: statusNote ?? null,
      },
    })
  }

  async softDeleteAgent(id: string) {
    return this.prisma.agent.update({
      where: { id, deletedAt: null },
      data: {
        deletedAt: new Date(),
      },
    })
  }
}
