import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Put, Query } from '@nestjs/common'
import { ApiParam, ApiTags } from '@nestjs/swagger'

import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'

import { AgentsService } from '@/modules/agents/agent.service'
import { AgentResponseDto } from '@/modules/agents/dto/response/agent-response.dto'
import { CreateAgentDto } from '@/modules/agents/dto/request/create-agent.dto'
import { UpdateAgentDto } from '@/modules/agents/dto/request/update-agent.dto'
import { QueryAgentDto } from '@/modules/agents/dto/request/query-agent.dto'
import { ApproveAgentDto } from '@/modules/agents/dto/request/approve-agent.dto'
import { RejectAgentDto } from '@/modules/agents/dto/request/reject-agent.dto'
import { UpdateAgentStatusDto } from '@/modules/agents/dto/request/update-agent-status.dto'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'
import { ApiBearerAuth } from '@nestjs/swagger'
import { PaginatedResult } from '@/common/dtos/pagination'
import { ApiErrorResponse } from '@/common/decorators/api-error-responses.decorator'
import { ApiCreatedSuccessResponse } from '@/common/decorators/api-created-success-response.decorator'

@ApiTags('agents')
@Controller('agents')
@ApiBearerAuth()
export class AgentsController {
  constructor(private agentsService: AgentsService) {}

  @Get()
  @Permission(PermissionCode.AGENT_READ)
  @SuccessMessage('Agents retrieved successfully')
  @ApiSuccessResponse({
    type: AgentResponseDto,
    isArray: true,
    hasMeta: true,
    description: 'Agents retrieved successfully',
  })
  @ApiErrorResponse('Invalid agent list query')
  async getAgents(@Query() query: QueryAgentDto): Promise<PaginatedResult<AgentResponseDto>> {
    return await this.agentsService.agents(query)
  }

  @Get('user/:userId')
  @Permission(PermissionCode.AGENT_READ, PermissionCode.USER_SELF_READ)
  @SuccessMessage('Agent retrieved successfully')
  @ApiParam({ name: 'userId', type: String, description: 'User ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent retrieved successfully' })
  @ApiErrorResponse('Invalid user ID or user not found')
  async getAgentByUserId(@Param('userId', new ParseUUIDPipe()) userId: string): Promise<AgentResponseDto> {
    return await this.agentsService.getAgentByUserId(userId)
  }

  @Get(':id')
  @Permission(PermissionCode.AGENT_READ, PermissionCode.USER_SELF_READ)
  @SuccessMessage('Agent retrieved successfully')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent retrieved successfully' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async getAgentById(@Param('id', new ParseUUIDPipe()) id: string): Promise<AgentResponseDto> {
    return await this.agentsService.getAgentById(id)
  }

  @Post('user/:userId')
  @Permission(PermissionCode.USER_CREATE, PermissionCode.AGENT_REGISTER)
  @SuccessMessage('Agent created successfully')
  @ApiParam({ name: 'userId', type: String, description: 'User ID (UUID)' })
  @ApiCreatedSuccessResponse({ type: AgentResponseDto, description: 'Agent created successfully' })
  @ApiErrorResponse('Invalid user ID or user not found')
  async createAgent(
    @Param('userId', new ParseUUIDPipe()) userId: string,
    @Body() createAgentDto: CreateAgentDto,
  ): Promise<AgentResponseDto> {
    return await this.agentsService.create(userId, createAgentDto)
  }

  @Put(':id')
  @Permission(PermissionCode.AGENT_UPDATE)
  @SuccessMessage('Agent updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent updated successfully' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async updateAgent(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateAgentDto: UpdateAgentDto,
  ): Promise<AgentResponseDto> {
    return await this.agentsService.update(id, updateAgentDto)
  }

  @Delete(':id')
  @SuccessMessage('Agent deleted successfully')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent deleted successfully' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async deleteAgent(@Param('id', new ParseUUIDPipe()) id: string): Promise<AgentResponseDto> {
    return await this.agentsService.remove(id)
  }

  @Patch(':id/approve')
  @SuccessMessage('Agent approved successfully')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent approved successfully' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async approveAgent(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() dto: ApproveAgentDto,
  ): Promise<AgentResponseDto> {
    return await this.agentsService.approve(id, dto.statusNote)
  }

  @Patch(':id/reject')
  @SuccessMessage('Agent profile sent for revision')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent profile sent for revision' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async rejectAgent(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() dto: RejectAgentDto,
  ): Promise<AgentResponseDto> {
    return await this.agentsService.reject(id, dto.statusNote)
  }

  @Patch(':id/suspend')
  @SuccessMessage('Agent suspended successfully')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent suspended successfully' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async suspendAgent(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() dto: UpdateAgentStatusDto,
  ): Promise<AgentResponseDto> {
    return await this.agentsService.suspend(id, dto.statusNote)
  }

  @Patch(':id/ban')
  @SuccessMessage('Agent banned successfully')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent banned successfully' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async banAgent(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() dto: UpdateAgentStatusDto,
  ): Promise<AgentResponseDto> {
    return await this.agentsService.ban(id, dto.statusNote)
  }

  @Patch(':id/reactivate')
  @SuccessMessage('Agent reactivated successfully')
  @ApiParam({ name: 'id', type: String, description: 'Agent ID (UUID)' })
  @ApiSuccessResponse({ type: AgentResponseDto, description: 'Agent reactivated successfully' })
  @ApiErrorResponse('Invalid agent ID or agent not found')
  async reactivateAgent(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() dto: UpdateAgentStatusDto,
  ): Promise<AgentResponseDto> {
    return await this.agentsService.reactivate(id, dto.statusNote)
  }
}
