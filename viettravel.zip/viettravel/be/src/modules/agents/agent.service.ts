import { Injectable } from '@nestjs/common'

import { AgentStatusEnum } from '@/generated/prisma/enums'
import { AgentResponseDto } from './dto/response/agent-response.dto'
import { AgentsMapper } from '@/modules/agents/dto/agent-mapper'
import { CreateAgentDto } from './dto/request/create-agent.dto'
import { UpdateAgentDto } from './dto/request/update-agent.dto'
import { QueryAgentDto } from './dto/request/query-agent.dto'
import { AgentRepository } from '@/modules/agents/agent.repository'
import {
  AppBadRequestException,
  ResourceConflictException,
  ResourceNotFoundException,
} from '@/common/errors/business.exception'
import { PaginatedResult, PaginationHelper } from '@/common/dtos/pagination'
import { Logger } from '@nestjs/common'
@Injectable()
export class AgentsService {
  private readonly logger = new Logger(AgentsService.name)

  constructor(private agentRepository: AgentRepository) {}

  async agents(query: QueryAgentDto): Promise<PaginatedResult<AgentResponseDto>> {
    try {
      const [agents, total] = await Promise.all([
        this.agentRepository.findPaginatedAgents(query),
        this.agentRepository.countAgents(query),
      ])
      const meta = PaginationHelper.getMeta(query.page, query.limit, total)
      const data = AgentsMapper.toResponseList(agents)
      return new PaginatedResult(data, meta)
    } catch (error) {
      this.logger.error(`Failed to get agents: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async getAgentById(id: string): Promise<InstanceType<typeof AgentResponseDto>> {
    try {
      const agent = await this.agentRepository.findAgentById(id)
      if (!agent) {
        throw new ResourceNotFoundException('Agent not found')
      }
      return AgentsMapper.toResponse(agent)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(`Failed to get agent ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async getAgentByUserId(userId: string): Promise<InstanceType<typeof AgentResponseDto>> {
    try {
      const agent = await this.agentRepository.findAgentByUserId(userId)
      if (!agent) {
        throw new ResourceNotFoundException('Agent not found')
      }
      return AgentsMapper.toResponse(agent)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to get agent for user ${userId}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async create(userId: string, dto: CreateAgentDto): Promise<InstanceType<typeof AgentResponseDto>> {
    try {
      const existingAgent = await this.agentRepository.findAgentByUserId(userId)
      if (existingAgent) {
        throw new ResourceConflictException('Agent already exists for this user')
      }

      const existingTaxCode = await this.agentRepository.findAgentByTaxCode(dto.taxCode)
      if (existingTaxCode) {
        throw new ResourceConflictException('Tax code already exists')
      }

      const agentCode = `AG-${Date.now()}`
      const agent = await this.agentRepository.createAgent(userId, agentCode, dto)
      return AgentsMapper.toResponse(agent)
    } catch (error) {
      if (error instanceof ResourceConflictException) throw error
      this.logger.error(
        `Failed to create agent for user ${userId}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async update(id: string, dto: UpdateAgentDto): Promise<InstanceType<typeof AgentResponseDto>> {
    try {
      const agent = await this.agentRepository.findAgentById(id)
      if (!agent) {
        throw new ResourceNotFoundException('Agent not found')
      }

      if (dto.taxCode && dto.taxCode !== agent.taxCode) {
        const existingTaxCode = await this.agentRepository.findAgentByTaxCode(dto.taxCode, id)
        if (existingTaxCode) {
          throw new ResourceConflictException('Tax code already exists')
        }
      }

      const updatedAgent = await this.agentRepository.updateAgent(id, dto)
      return AgentsMapper.toResponse(updatedAgent)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(`Failed to update agent ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  async approve(id: string, statusNote?: string): Promise<InstanceType<typeof AgentResponseDto>> {
    return this.transitionStatus(
      id,
      [AgentStatusEnum.PENDING, AgentStatusEnum.REVISION_REQUEST],
      AgentStatusEnum.ACTIVE,
      statusNote,
    )
  }

  async reject(id: string, statusNote: string): Promise<InstanceType<typeof AgentResponseDto>> {
    return this.transitionStatus(id, [AgentStatusEnum.PENDING], AgentStatusEnum.REVISION_REQUEST, statusNote)
  }

  async suspend(id: string, statusNote?: string): Promise<InstanceType<typeof AgentResponseDto>> {
    return this.transitionStatus(id, [AgentStatusEnum.ACTIVE], AgentStatusEnum.SUSPENDED, statusNote)
  }

  async ban(id: string, statusNote?: string): Promise<InstanceType<typeof AgentResponseDto>> {
    const agent = await this.requireAgent(id)
    if (agent.status === AgentStatusEnum.BANNED) {
      throw new AppBadRequestException('Agent is already banned')
    }
    return this.transitionStatus(id, Object.values(AgentStatusEnum), AgentStatusEnum.BANNED, statusNote)
  }

  async reactivate(id: string, statusNote?: string): Promise<InstanceType<typeof AgentResponseDto>> {
    return this.transitionStatus(id, [AgentStatusEnum.SUSPENDED], AgentStatusEnum.ACTIVE, statusNote)
  }

  async remove(id: string): Promise<InstanceType<typeof AgentResponseDto>> {
    try {
      const agent = await this.agentRepository.softDeleteAgent(id)
      return AgentsMapper.toResponse(agent)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(`Failed to delete agent ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  private async requireAgent(id: string) {
    try {
      const agent = await this.agentRepository.findAgentById(id)
      if (!agent) {
        throw new ResourceNotFoundException('Agent not found')
      }
      return agent
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(`Failed to get agent ${id}: ${error instanceof Error ? error.message : String(error)}`)
      throw error
    }
  }

  private async transitionStatus(
    id: string,
    allowedFrom: AgentStatusEnum[],
    targetStatus: AgentStatusEnum,
    statusNote?: string,
  ): Promise<InstanceType<typeof AgentResponseDto>> {
    const agent = await this.requireAgent(id)

    if (!agent.status || !allowedFrom.includes(agent.status)) {
      throw new AppBadRequestException(
        `Cannot change agent status from ${agent.status ?? 'unknown'} to ${targetStatus}`,
      )
    }

    try {
      const updatedAgent = await this.agentRepository.updateStatus(id, targetStatus, statusNote)
      return AgentsMapper.toResponse(updatedAgent)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to update agent status ${id}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }
}
