import { TransportationCategory } from '@/generated/prisma/client'
import { TransportationCategoryResponseDto } from '@/modules/transportation-category/dto/response/transportation-category-response.dto'

export class TransportationCategoryMapper {
  static toResponse(item: TransportationCategory): TransportationCategoryResponseDto {
    return {
      id: item.id,
      name: item.name,
      slug: item.slug,
      description: item.description,
      iconUrl: item.iconUrl,
      sortOrder: item.sortOrder,
      isActive: item.isActive,
      createdAt: item.createdAt.toISOString(),
      updatedAt: item.updatedAt.toISOString(),
    }
  }

  static toResponseList(items: TransportationCategory[]): TransportationCategoryResponseDto[] {
    return items.map(this.toResponse)
  }
}
