import { PaginationQuerySchema } from '@/common/dtos/pagination.query'
import { createZodDto } from 'nestjs-zod'

export const QueryTransportationCategorySchema = PaginationQuerySchema.meta({ id: 'QueryTransportationCategory' })

export class QueryTransportationCategoryDto extends createZodDto(QueryTransportationCategorySchema) {}
