import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const UpdateTransportationCategorySortOrderSchema = z
  .strictObject({
    items: z
      .array(
        z.strictObject({
          id: z.string().uuid(),
          sortOrder: z.number().int().min(1, 'Sort order must be at least 1'),
        }),
      )
      .min(1, 'At least one item is required'),
  })
  .meta({ id: 'UpdateTransportationCategorySortOrder' })

export class UpdateTransportationCategorySortOrderDto extends createZodDto(
  UpdateTransportationCategorySortOrderSchema,
) {}
