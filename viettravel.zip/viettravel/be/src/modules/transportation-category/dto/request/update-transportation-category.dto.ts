import { createZodDto } from 'nestjs-zod'
import { CreateTransportationCategorySchema } from '@/modules/transportation-category/dto/request/create-transportation-category.dto'

export const UpdateTransportationCategorySchema = CreateTransportationCategorySchema.partial().meta({
  id: 'UpdateTransportationCategory',
})

export class UpdateTransportationCategoryDto extends createZodDto(UpdateTransportationCategorySchema) {}
