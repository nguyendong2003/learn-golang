import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const CreateTransportationCategorySchema = z
  .strictObject({
    name: z.string().trim().min(1, 'Name is required').max(255, 'Name must be at most 255 characters'),
    slug: z.string().trim().min(1, 'Slug is required').max(255, 'Slug must be at most 255 characters'),
    description: z.string().trim().optional().nullable(),
    iconUrl: z.string().url('Invalid icon URL').optional().nullable(),
    sortOrder: z.number().int().min(1, 'Sort order must be at least 1').optional().default(1),
    isActive: z.boolean().optional().default(true),
  })
  .meta({ id: 'CreateTransportationCategory' })

export class CreateTransportationCategoryDto extends createZodDto(CreateTransportationCategorySchema) {}
