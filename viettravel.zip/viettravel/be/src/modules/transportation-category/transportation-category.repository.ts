import { Injectable } from '@nestjs/common'
import { PrismaService } from '@/prisma/prisma.service'
import { UpdateTransportationCategoryDto } from '@/modules/transportation-category/dto/request/update-transportation-category.dto'
import { CreateTransportationCategoryDto } from '@/modules/transportation-category/dto/request/create-transportation-category.dto'

@Injectable()
export class TransportationCategoryRepository {
  constructor(private prisma: PrismaService) {}

  async findMany(skip?: number, take?: number) {
    return this.prisma.transportationCategory.findMany({
      where: { deletedAt: null },
      skip: skip || 0,
      take: take || 100,
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
    })
  }

  async count(where: Record<string, any> = {}) {
    return this.prisma.transportationCategory.count({ where: { deletedAt: null, ...where } })
  }

  async findById(id: string) {
    return this.prisma.transportationCategory.findFirst({
      where: { id, deletedAt: null },
    })
  }

  async findBySlug(slug: string) {
    return this.prisma.transportationCategory.findFirst({
      where: { slug, deletedAt: null },
    })
  }

  async findByName(name: string) {
    return this.prisma.transportationCategory.findFirst({
      where: { name, deletedAt: null },
    })
  }

  async create(createDto: CreateTransportationCategoryDto) {
    return this.prisma.transportationCategory.create({
      data: {
        ...createDto,
      },
    })
  }

  async update(id: string, updateDto: UpdateTransportationCategoryDto) {
    return this.prisma.transportationCategory.update({
      where: { id },
      data: updateDto,
    })
  }

  async delete(id: string) {
    return this.prisma.transportationCategory.update({
      where: { id },
      data: { deletedAt: new Date() },
    })
  }

  async countRelations(transportationCategoryId: string) {
    return this.prisma.tourTransportation.count({
      where: { transportationCategoryId },
    })
  }

  async findManyByIds(ids: string[]) {
    return this.prisma.transportationCategory.findMany({
      where: { id: { in: ids }, deletedAt: null },
      orderBy: [{ sortOrder: 'asc' }, { createdAt: 'desc' }],
    })
  }

  async updateSortOrders(items: Array<{ id: string; sortOrder: number }>) {
    const updates = items.map((item) =>
      this.prisma.transportationCategory.update({
        where: { id: item.id },
        data: { sortOrder: item.sortOrder },
      }),
    )

    return this.prisma.$transaction(updates)
  }
}
