import { Injectable, Logger } from '@nestjs/common'
import { TransportationCategoryResponseDto } from '@/modules/transportation-category/dto/response/transportation-category-response.dto'
import { TransportationCategoryMapper } from '@/modules/transportation-category/dto/transportation-category.mapper'
import { UpdateTransportationCategoryDto } from '@/modules/transportation-category/dto/request/update-transportation-category.dto'
import { CreateTransportationCategoryDto } from '@/modules/transportation-category/dto/request/create-transportation-category.dto'
import { QueryTransportationCategoryDto } from '@/modules/transportation-category/dto/request/query-transportation-category.dto'
import { UpdateTransportationCategorySortOrderDto } from '@/modules/transportation-category/dto/request/update-transportation-category-sort-order.dto'
import { TransportationCategoryRepository } from '@/modules/transportation-category/transportation-category.repository'
import {
  AppBadRequestException,
  ResourceConflictException,
  ResourceNotFoundException,
} from '@/common/errors/business.exception'
import { PaginatedResult, PaginationHelper } from '@/common/dtos/pagination'

@Injectable()
export class TransportationCategoryService {
  private readonly logger = new Logger(TransportationCategoryService.name)

  constructor(private transportationCategoryRepository: TransportationCategoryRepository) {}

  async getTransportationCategories(
    query: QueryTransportationCategoryDto,
  ): Promise<PaginatedResult<TransportationCategoryResponseDto>> {
    try {
      const { page, limit } = query
      const { skip, take } = PaginationHelper.getSkipTake(page, limit)
      const [items, total] = await Promise.all([
        this.transportationCategoryRepository.findMany(skip, take),
        this.transportationCategoryRepository.count(),
      ])

      const data = TransportationCategoryMapper.toResponseList(items)
      const meta = PaginationHelper.getMeta(page, limit, total)

      return new PaginatedResult(data, meta)
    } catch (error) {
      this.logger.error(
        `Failed to get transportation categories: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async getTransportationCategoryById(id: string): Promise<TransportationCategoryResponseDto> {
    try {
      const item = await this.transportationCategoryRepository.findById(id)
      if (!item || item.deletedAt) {
        throw new ResourceNotFoundException('Transportation category not found')
      }
      return TransportationCategoryMapper.toResponse(item)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to get transportation category ${id}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async getTransportationCategoryBySlug(slug: string): Promise<TransportationCategoryResponseDto> {
    try {
      const item = await this.transportationCategoryRepository.findBySlug(slug)
      if (!item || item.deletedAt) {
        throw new ResourceNotFoundException('Transportation category not found')
      }
      return TransportationCategoryMapper.toResponse(item)
    } catch (error) {
      if (error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to get transportation category by slug ${slug}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async createTransportationCategory(
    createDto: CreateTransportationCategoryDto,
  ): Promise<TransportationCategoryResponseDto> {
    try {
      const existingName = await this.transportationCategoryRepository.findByName(createDto.name)
      if (existingName) {
        throw new ResourceConflictException('Transportation category with this name already exists')
      }

      const existingSlug = await this.transportationCategoryRepository.findBySlug(createDto.slug)
      if (existingSlug) {
        throw new ResourceConflictException('Transportation category with this slug already exists')
      }

      const created = await this.transportationCategoryRepository.create(createDto)
      return TransportationCategoryMapper.toResponse(created)
    } catch (error) {
      if (error instanceof ResourceConflictException) throw error
      this.logger.error(
        `Failed to create transportation category: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async updateTransportationCategory(
    id: string,
    updateDto: UpdateTransportationCategoryDto,
  ): Promise<TransportationCategoryResponseDto> {
    try {
      const existing = await this.transportationCategoryRepository.findById(id)
      if (!existing || existing.deletedAt) {
        throw new ResourceNotFoundException('Transportation category not found')
      }

      if (updateDto.slug && updateDto.slug !== existing.slug) {
        const slugConflict = await this.transportationCategoryRepository.findBySlug(updateDto.slug)
        if (slugConflict && slugConflict.id !== id) {
          throw new ResourceConflictException('Transportation category with this slug already exists')
        }
      }

      const updated = await this.transportationCategoryRepository.update(id, updateDto)
      return TransportationCategoryMapper.toResponse(updated)
    } catch (error) {
      if (error instanceof (ResourceNotFoundException || ResourceConflictException)) throw error
      this.logger.error(
        `Failed to update transportation category ${id}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async updateSortOrder(
    updateSortOrderDto: UpdateTransportationCategorySortOrderDto,
  ): Promise<TransportationCategoryResponseDto[]> {
    try {
      const ids = updateSortOrderDto.items.map((item) => item.id)
      const uniqueIds = new Set(ids)

      if (uniqueIds.size !== ids.length) {
        throw new AppBadRequestException('Duplicate transportation category ids in sort order payload')
      }

      const existing = await this.transportationCategoryRepository.findManyByIds(ids)
      if (existing.length !== ids.length) {
        throw new ResourceNotFoundException('One or more transportation categories not found')
      }

      await this.transportationCategoryRepository.updateSortOrders(updateSortOrderDto.items)
      const updated = await this.transportationCategoryRepository.findManyByIds(ids)
      return TransportationCategoryMapper.toResponseList(updated)
    } catch (error) {
      if (error instanceof AppBadRequestException || error instanceof ResourceNotFoundException) throw error
      this.logger.error(
        `Failed to update transportation category sort order: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }

  async deleteTransportationCategory(id: string): Promise<void> {
    try {
      const existing = await this.transportationCategoryRepository.findById(id)
      if (!existing || existing.deletedAt) {
        throw new ResourceNotFoundException('Transportation category not found')
      }

      const relationCount = await this.transportationCategoryRepository.countRelations(id)
      if (relationCount > 0) {
        throw new AppBadRequestException('Cannot delete transportation category with related transportations')
      }

      await this.transportationCategoryRepository.delete(id)
    } catch (error) {
      if (error instanceof (ResourceNotFoundException || AppBadRequestException)) throw error
      this.logger.error(
        `Failed to delete transportation category ${id}: ${error instanceof Error ? error.message : String(error)}`,
      )
      throw error
    }
  }
}
