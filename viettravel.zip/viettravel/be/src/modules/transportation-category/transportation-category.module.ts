import { Module } from '@nestjs/common'
import { TransportationCategoryService } from '@/modules/transportation-category/transportation-category.service'
import { TransportationCategoryController } from '@/modules/transportation-category/transportation-category.controller'
import { TransportationCategoryRepository } from '@/modules/transportation-category/transportation-category.repository'

@Module({
  imports: [],
  providers: [TransportationCategoryService, TransportationCategoryRepository],
  controllers: [TransportationCategoryController],
})
export class TransportationCategoryModule {}
