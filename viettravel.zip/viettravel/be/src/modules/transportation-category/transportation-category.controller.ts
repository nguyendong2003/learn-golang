import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Post, Put, Query } from '@nestjs/common'
import { TransportationCategoryService } from '@/modules/transportation-category/transportation-category.service'
import { PaginatedResult } from '@/common/dtos/pagination'
import { UpdateTransportationCategoryDto } from '@/modules/transportation-category/dto/request/update-transportation-category.dto'
import { TransportationCategoryResponseDto } from '@/modules/transportation-category/dto/response/transportation-category-response.dto'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { CreateTransportationCategoryDto } from '@/modules/transportation-category/dto/request/create-transportation-category.dto'
import { QueryTransportationCategoryDto } from '@/modules/transportation-category/dto/request/query-transportation-category.dto'
import { UpdateTransportationCategorySortOrderDto } from '@/modules/transportation-category/dto/request/update-transportation-category-sort-order.dto'
import { ApiBearerAuth, ApiParam, ApiTags } from '@nestjs/swagger/dist/decorators'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { ApiErrorResponse } from '@/common/decorators/api-error-responses.decorator'
import { ApiCreatedSuccessResponse } from '@/common/decorators/api-created-success-response.decorator'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'
import { Public } from '@/common/decorators/public.decorator'

@ApiBearerAuth()
@ApiTags('transportation-categories')
@Controller('transportation-categories')
export class TransportationCategoryController {
  constructor(private transportationCategoryService: TransportationCategoryService) {}

  @Get()
  @Public()
  @SuccessMessage('Transportation categories retrieved successfully')
  @ApiSuccessResponse({ type: TransportationCategoryResponseDto, isArray: true, hasMeta: true })
  @ApiErrorResponse('Invalid transportation category list query')
  async getTransportationCategories(
    @Query() query: QueryTransportationCategoryDto,
  ): Promise<PaginatedResult<TransportationCategoryResponseDto>> {
    return await this.transportationCategoryService.getTransportationCategories(query)
  }

  @Get('slug/:slug')
  @Public()
  @SuccessMessage('Transportation category retrieved successfully')
  @ApiParam({ name: 'slug', type: String, description: 'Transportation category slug' })
  @ApiSuccessResponse({
    type: TransportationCategoryResponseDto,
    description: 'Transportation category retrieved successfully',
  })
  @ApiErrorResponse('Invalid slug or transportation category not found')
  async getTransportationCategoryBySlug(@Param('slug') slug: string): Promise<TransportationCategoryResponseDto> {
    return await this.transportationCategoryService.getTransportationCategoryBySlug(slug)
  }

  @Get(':id')
  @Public()
  @SuccessMessage('Transportation category retrieved successfully')
  @ApiParam({ name: 'id', type: String, description: 'Transportation category ID (UUID)' })
  @ApiSuccessResponse({
    type: TransportationCategoryResponseDto,
    description: 'Transportation category retrieved successfully',
  })
  @ApiErrorResponse('Invalid transportation category id or transportation category not found')
  async getTransportationCategoryById(
    @Param('id', new ParseUUIDPipe()) id: string,
  ): Promise<TransportationCategoryResponseDto> {
    return await this.transportationCategoryService.getTransportationCategoryById(id)
  }

  @Post()
  @Permission(PermissionCode.TRANSPORTATION_CATEGORY_CREATE)
  @SuccessMessage('Transportation category created successfully')
  @ApiCreatedSuccessResponse({
    type: TransportationCategoryResponseDto,
    description: 'Transportation category created successfully',
  })
  @ApiErrorResponse('Invalid transportation category payload')
  async createTransportationCategory(
    @Body() createDto: CreateTransportationCategoryDto,
  ): Promise<TransportationCategoryResponseDto> {
    return await this.transportationCategoryService.createTransportationCategory(createDto)
  }

  @Put('sort-order')
  @Permission(PermissionCode.TRANSPORTATION_CATEGORY_UPDATE)
  @SuccessMessage('Transportation category sort order updated successfully')
  @ApiSuccessResponse({
    type: TransportationCategoryResponseDto,
    isArray: true,
    description: 'Sort order updated successfully',
  })
  @ApiErrorResponse('Invalid sort order payload')
  async updateSortOrder(
    @Body() updateSortOrderDto: UpdateTransportationCategorySortOrderDto,
  ): Promise<TransportationCategoryResponseDto[]> {
    return await this.transportationCategoryService.updateSortOrder(updateSortOrderDto)
  }

  @Put(':id')
  @Permission(PermissionCode.TRANSPORTATION_CATEGORY_UPDATE)
  @SuccessMessage('Transportation category updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'Transportation category ID (UUID)' })
  @ApiSuccessResponse({
    type: TransportationCategoryResponseDto,
    description: 'Transportation category updated successfully',
  })
  @ApiErrorResponse('Invalid transportation category id or payload')
  async updateTransportationCategory(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateDto: UpdateTransportationCategoryDto,
  ): Promise<TransportationCategoryResponseDto> {
    return await this.transportationCategoryService.updateTransportationCategory(id, updateDto)
  }

  @Delete(':id')
  @Permission(PermissionCode.TRANSPORTATION_CATEGORY_DELETE)
  @SuccessMessage('Transportation category deleted successfully')
  @ApiParam({ name: 'id', type: String, description: 'Transportation category ID (UUID)' })
  @ApiSuccessResponse({
    type: TransportationCategoryResponseDto,
    hasData: false,
    description: 'Transportation category deleted successfully',
  })
  @ApiErrorResponse('Invalid transportation category id or transportation category not found')
  async deleteTransportationCategory(@Param('id', new ParseUUIDPipe()) id: string): Promise<void> {
    return await this.transportationCategoryService.deleteTransportationCategory(id)
  }
}
