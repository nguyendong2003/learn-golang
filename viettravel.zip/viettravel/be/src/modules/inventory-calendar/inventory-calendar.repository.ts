import { Injectable } from '@nestjs/common'
import { Prisma } from '@/generated/prisma/client'
import { PrismaService } from '@/prisma/prisma.service'
import { AppBadRequestException, ResourceNotFoundException } from '@/common/errors/business.exception'

@Injectable()
export class InventoryCalendarRepository {
  constructor(private prisma: PrismaService) {}

  async findRoomType(roomTypeId: string) {
    return this.prisma.roomType.findFirst({ where: { id: roomTypeId, deletedAt: null } })
  }

  async findInventory(roomTypeId: string, inventoryDate: Date) {
    return this.prisma.roomTypeInventory.findUnique({
      where: { roomTypeId_inventoryDate: { roomTypeId, inventoryDate } },
    })
  }

  async adjustInventoryForDates(
    operation: 'reserve' | 'release',
    roomTypeId: string,
    dates: Date[],
    roomCount: number,
  ) {
    const roomType = await this.findRoomType(roomTypeId)
    if (!roomType) throw new ResourceNotFoundException('Room type not found')

    const totalRoom = roomType.totalRoom

    // Validate availability for reserve
    if (operation === 'reserve') {
      for (const date of dates) {
        const inv = await this.findInventory(roomTypeId, date)
        const available = inv ? inv.availableRoom : totalRoom
        const isClosed = inv ? inv.isClosed : false
        if (isClosed) throw new AppBadRequestException(`Room is closed for sale on ${date.toISOString().slice(0, 10)}`)
        if (available < roomCount)
          throw new AppBadRequestException(`Not enough rooms on ${date.toISOString().slice(0, 10)}`)
      }
    }

    const ops: Prisma.PrismaPromise<unknown>[] = []
    for (const date of dates) {
      const inventoryDate = date
      if (operation === 'reserve') {
        // upsert then increment bookedRoom / decrement availableRoom
        ops.push(
          this.prisma.roomTypeInventory.upsert({
            where: { roomTypeId_inventoryDate: { roomTypeId, inventoryDate } },
            create: {
              roomTypeId,
              inventoryDate,
              totalRoom,
              bookedRoom: roomCount,
              availableRoom: Math.max(0, totalRoom - roomCount),
              isClosed: totalRoom - roomCount <= 0,
            },
            update: {
              bookedRoom: { increment: roomCount },
              availableRoom: { decrement: roomCount },
            },
          }),
        )
      } else {
        // release
        // ensure we don't drop below zero
        const existing = await this.findInventory(roomTypeId, inventoryDate)
        if (!existing) {
          // nothing to release
          continue
        }
        const newBooked = Math.max(0, existing.bookedRoom - roomCount)
        const newAvailable = Math.min(existing.totalRoom, existing.availableRoom + roomCount)
        ops.push(
          this.prisma.roomTypeInventory.update({
            where: { roomTypeId_inventoryDate: { roomTypeId, inventoryDate } },
            data: {
              bookedRoom: newBooked,
              availableRoom: newAvailable,
              isClosed: newAvailable <= 0,
            },
          }),
        )
      }
    }

    if (ops.length === 0) return []
    const res = await this.prisma.$transaction(ops)

    // Ensure isClosed reflects availableRoom after changes
    const inventoryDates = dates
    await this.prisma.roomTypeInventory.updateMany({
      where: { roomTypeId, inventoryDate: { in: inventoryDates }, availableRoom: { lte: 0 } },
      data: { isClosed: true },
    })
    await this.prisma.roomTypeInventory.updateMany({
      where: { roomTypeId, inventoryDate: { in: inventoryDates }, availableRoom: { gt: 0 } },
      data: { isClosed: false },
    })

    return res
  }

  async setStopSaleForDates(roomTypeId: string, dates: Date[], stop: boolean) {
    const roomType = await this.findRoomType(roomTypeId)
    if (!roomType) throw new ResourceNotFoundException('Room type not found')

    const ops: Prisma.PrismaPromise<unknown>[] = []
    for (const date of dates) {
      const inv = await this.findInventory(roomTypeId, date)
      if (!inv) {
        // create inventory row with default values and closed flag
        ops.push(
          this.prisma.roomTypeInventory.create({
            data: {
              roomTypeId,
              inventoryDate: date,
              totalRoom: roomType.totalRoom,
              bookedRoom: 0,
              availableRoom: stop ? 0 : roomType.totalRoom,
              isClosed: stop,
            },
          }),
        )
      } else {
        ops.push(
          this.prisma.roomTypeInventory.update({
            where: { roomTypeId_inventoryDate: { roomTypeId, inventoryDate: date } },
            data: { isClosed: stop, availableRoom: stop ? 0 : inv.totalRoom - inv.bookedRoom },
          }),
        )
      }
    }

    if (ops.length === 0) return []

    await this.prisma.$transaction(ops)

    return this.prisma.roomTypeInventory.findMany({
      where: { roomTypeId, inventoryDate: { in: dates } },
      orderBy: { inventoryDate: 'asc' },
    })
  }

  async setAvailableRoomForDates(roomTypeId: string, dates: Date[], availableRoom: number) {
    const roomType = await this.findRoomType(roomTypeId)
    if (!roomType) throw new ResourceNotFoundException('Room type not found')

    if (availableRoom < 0) throw new AppBadRequestException('availableRoom must be non-negative')
    if (availableRoom > roomType.totalRoom)
      throw new AppBadRequestException(`availableRoom cannot exceed totalRoom (${roomType.totalRoom})`)

    const ops: Prisma.PrismaPromise<unknown>[] = []
    for (const date of dates) {
      const existing = await this.findInventory(roomTypeId, date)
      if (!existing) {
        ops.push(
          this.prisma.roomTypeInventory.create({
            data: {
              roomTypeId,
              inventoryDate: date,
              totalRoom: roomType.totalRoom,
              bookedRoom: 0,
              availableRoom,
              isClosed: availableRoom <= 0,
            },
          }),
        )
        continue
      }

      ops.push(
        this.prisma.roomTypeInventory.update({
          where: { roomTypeId_inventoryDate: { roomTypeId, inventoryDate: date } },
          data: {
            availableRoom,
            isClosed: availableRoom <= 0,
          },
        }),
      )
    }

    if (ops.length === 0) return []

    await this.prisma.$transaction(ops)

    return this.prisma.roomTypeInventory.findMany({
      where: { roomTypeId, inventoryDate: { in: dates } },
      orderBy: { inventoryDate: 'asc' },
    })
  }
}
