import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const StopSaleSchema = z
  .strictObject({
    roomTypeId: z.string().uuid(),
    fromDate: z.string().refine((s) => !Number.isNaN(Date.parse(s)), { message: 'Invalid date' }),
    toDate: z.string().refine((s) => !Number.isNaN(Date.parse(s)), { message: 'Invalid date' }),
    stop: z.boolean(),
  })
  .meta({ id: 'StopSale' })

export class StopSaleDto extends createZodDto(StopSaleSchema) {}
