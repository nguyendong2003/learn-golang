import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

const InventoryDateSchema = z.string().refine((value) => !Number.isNaN(Date.parse(value)), {
  message: 'Invalid date',
})

export const BulkUpdateInventorySchema = z
  .strictObject({
    roomTypeId: z.string().uuid(),
    action: z.enum(['set_available', 'stop_sale', 'open_sale']),
    availableRoom: z.number().int().min(0).optional(),
    fromDate: InventoryDateSchema,
    toDate: InventoryDateSchema,
  })
  .superRefine((value, ctx) => {
    if (Date.parse(value.fromDate) > Date.parse(value.toDate)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['toDate'],
        message: 'toDate must be same or after fromDate',
      })
    }

    if (value.action === 'set_available' && value.availableRoom === undefined) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['availableRoom'],
        message: 'availableRoom is required when action is set_available',
      })
    }
  })
  .meta({ id: 'BulkUpdateInventory' })

export class BulkUpdateInventoryDto extends createZodDto(BulkUpdateInventorySchema) {}
