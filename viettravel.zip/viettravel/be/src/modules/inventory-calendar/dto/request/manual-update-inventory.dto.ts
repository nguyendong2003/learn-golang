import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

const InventoryDateSchema = z.string().refine((value) => !Number.isNaN(Date.parse(value)), {
  message: 'Invalid date',
})

export const ManualUpdateInventorySchema = z
  .strictObject({
    roomTypeId: z.string().uuid(),
    availableRoom: z.number().int().min(0),
    inventoryDate: InventoryDateSchema.optional(),
    fromDate: InventoryDateSchema.optional(),
    toDate: InventoryDateSchema.optional(),
  })
  .superRefine((value, ctx) => {
    const hasSingleDate = Boolean(value.inventoryDate)
    const hasRange = Boolean(value.fromDate) || Boolean(value.toDate)

    if (hasSingleDate && hasRange) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        path: ['inventoryDate'],
        message: 'Use either inventoryDate or fromDate/toDate, not both',
      })
      return
    }

    if (!hasSingleDate) {
      if (!value.fromDate || !value.toDate) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['fromDate'],
          message: 'fromDate and toDate are required when inventoryDate is not provided',
        })
        return
      }

      if (Date.parse(value.fromDate) > Date.parse(value.toDate)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ['toDate'],
          message: 'toDate must be same or after fromDate',
        })
      }
    }
  })
  .meta({ id: 'ManualUpdateInventory' })

export class ManualUpdateInventoryDto extends createZodDto(ManualUpdateInventorySchema) {}
