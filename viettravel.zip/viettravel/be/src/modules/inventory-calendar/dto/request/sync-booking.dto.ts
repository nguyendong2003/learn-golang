import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const SyncBookingSchema = z
  .strictObject({
    operation: z.enum(['reserve', 'release']),
    roomTypeId: z.string().uuid(),
    checkInDate: z.string().refine((s) => !Number.isNaN(Date.parse(s)), { message: 'Invalid date' }),
    checkOutDate: z.string().refine((s) => !Number.isNaN(Date.parse(s)), { message: 'Invalid date' }),
    roomCount: z.number().int().positive(),
  })
  .meta({ id: 'SyncBooking' })

export class SyncBookingDto extends createZodDto(SyncBookingSchema) {}
