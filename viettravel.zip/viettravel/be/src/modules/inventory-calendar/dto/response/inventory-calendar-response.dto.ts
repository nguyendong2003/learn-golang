import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const InventoryCalendarResponseSchema = z
  .object({
    id: z.uuid(),
    roomTypeId: z.uuid(),

    inventoryDate: z.iso.datetime(),

    totalRoom: z.number().int(),
    bookedRoom: z.number().int(),
    availableRoom: z.number().int(),
    isClosed: z.boolean(),

    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
  })
  .meta({ id: 'InventoryCalendarResponse' })

export class InventoryCalendarResponseDto extends createZodDto(InventoryCalendarResponseSchema) {}
