import { RoomTypeInventory } from '@/generated/prisma/client'

import { InventoryCalendarResponseDto } from '@/modules/inventory-calendar/dto/response/inventory-calendar-response.dto'

export class InventoryCalendarMapper {
  static toResponse(this: void, inv: RoomTypeInventory): InstanceType<typeof InventoryCalendarResponseDto> {
    return {
      id: inv.id,
      roomTypeId: inv.roomTypeId,
      inventoryDate: inv.inventoryDate?.toISOString() ?? new Date(0).toISOString(),
      totalRoom: inv.totalRoom,
      bookedRoom: inv.bookedRoom,
      availableRoom: inv.availableRoom,
      isClosed: inv.isClosed,
      createdAt: inv.createdAt?.toISOString() ?? new Date(0).toISOString(),
      updatedAt: inv.updatedAt?.toISOString() ?? new Date(0).toISOString(),
    }
  }

  static toResponseList(invs: RoomTypeInventory[]): Array<InstanceType<typeof InventoryCalendarResponseDto>> {
    return invs.map(InventoryCalendarMapper.toResponse)
  }
}
