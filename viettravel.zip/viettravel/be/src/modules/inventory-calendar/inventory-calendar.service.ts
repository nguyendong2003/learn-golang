import { Injectable } from '@nestjs/common'
import { InventoryCalendarRepository } from './inventory-calendar.repository'
import { AppBadRequestException } from '@/common/errors/business.exception'
import { InventoryCalendarMapper } from './dto/inventory-calendar-mapper'
import { InventoryCalendarResponseDto } from './dto/response/inventory-calendar-response.dto'

type BulkUpdateInventoryPayload = {
  roomTypeId: string
  action: 'set_available' | 'stop_sale' | 'open_sale'
  availableRoom?: number
  fromDate: string
  toDate: string
}

function toDateOnly(d: string | Date) {
  const date = new Date(d)
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()))
}

function buildDatesRange(start: Date, endExclusive: Date) {
  const dates: Date[] = []
  for (let d = new Date(start); d < endExclusive; d.setUTCDate(d.getUTCDate() + 1)) {
    dates.push(new Date(d))
  }
  return dates
}

function buildInclusiveDatesRange(start: Date, endInclusive: Date) {
  const dates: Date[] = []
  for (let d = new Date(start); d <= endInclusive; d.setUTCDate(d.getUTCDate() + 1)) {
    dates.push(new Date(d))
  }
  return dates
}

@Injectable()
export class InventoryCalendarService {
  constructor(private readonly repo: InventoryCalendarRepository) {}

  async syncBooking(payload: {
    operation: 'reserve' | 'release'
    roomTypeId: string
    checkInDate: string
    checkOutDate: string
    roomCount: number
  }) {
    const { operation, roomTypeId, checkInDate, checkOutDate, roomCount } = payload
    if (!roomTypeId) throw new AppBadRequestException('roomTypeId is required')
    if (!checkInDate || !checkOutDate) throw new AppBadRequestException('checkInDate/checkOutDate required')
    const start = toDateOnly(checkInDate)
    const end = toDateOnly(checkOutDate)
    if (start >= end) throw new AppBadRequestException('checkOutDate must be after checkInDate')
    if (roomCount <= 0) throw new AppBadRequestException('roomCount must be positive')

    const dates = buildDatesRange(start, end)
    return this.repo.adjustInventoryForDates(operation, roomTypeId, dates, roomCount)
  }

  async setStopSale(payload: { roomTypeId: string; fromDate: string; toDate: string; stop: boolean }) {
    const { roomTypeId, fromDate, toDate, stop } = payload
    if (!roomTypeId) throw new AppBadRequestException('roomTypeId is required')
    const start = toDateOnly(fromDate)
    // inclusive end
    const endInclusive = toDateOnly(toDate)
    if (start > endInclusive) throw new AppBadRequestException('toDate must be same or after fromDate')

    const dates = buildInclusiveDatesRange(start, endInclusive)

    return this.repo.setStopSaleForDates(roomTypeId, dates, stop)
  }

  async manualUpdateInventory(payload: {
    roomTypeId: string
    availableRoom: number
    inventoryDate?: string
    fromDate?: string
    toDate?: string
  }): Promise<Array<InstanceType<typeof InventoryCalendarResponseDto>>> {
    const { roomTypeId, availableRoom, inventoryDate, fromDate, toDate } = payload
    if (!roomTypeId) throw new AppBadRequestException('roomTypeId is required')
    if (availableRoom < 0) throw new AppBadRequestException('availableRoom must be non-negative')

    let dates: Date[] = []
    if (inventoryDate) {
      dates = [toDateOnly(inventoryDate)]
    } else {
      if (!fromDate || !toDate) throw new AppBadRequestException('fromDate and toDate are required')
      const start = toDateOnly(fromDate)
      const endInclusive = toDateOnly(toDate)
      if (start > endInclusive) throw new AppBadRequestException('toDate must be same or after fromDate')
      dates = buildInclusiveDatesRange(start, endInclusive)
    }

    const inventories = await this.repo.setAvailableRoomForDates(roomTypeId, dates, availableRoom)
    return InventoryCalendarMapper.toResponseList(inventories)
  }

  async bulkUpdateInventory(
    payload: BulkUpdateInventoryPayload,
  ): Promise<Array<InstanceType<typeof InventoryCalendarResponseDto>>> {
    const { roomTypeId, action, availableRoom, fromDate, toDate } = payload
    if (!roomTypeId) throw new AppBadRequestException('roomTypeId is required')

    const start = toDateOnly(fromDate)
    const endInclusive = toDateOnly(toDate)
    const dates = buildInclusiveDatesRange(start, endInclusive)

    if (action === 'set_available') {
      const inventories = await this.repo.setAvailableRoomForDates(roomTypeId, dates, availableRoom ?? 0)
      return InventoryCalendarMapper.toResponseList(inventories)
    }

    const inventories = await this.repo.setStopSaleForDates(roomTypeId, dates, action === 'stop_sale')
    return InventoryCalendarMapper.toResponseList(inventories)
  }
}
