import { Module } from '@nestjs/common'
import { InventoryCalendarController } from './inventory-calendar.controller'
import { InventoryCalendarService } from './inventory-calendar.service'
import { InventoryCalendarRepository } from './inventory-calendar.repository'
import { PrismaModule } from '@/prisma/prisma.module'

@Module({
  imports: [PrismaModule],
  controllers: [InventoryCalendarController],
  providers: [InventoryCalendarService, InventoryCalendarRepository],
})
export class InventoryCalendarModule {}
