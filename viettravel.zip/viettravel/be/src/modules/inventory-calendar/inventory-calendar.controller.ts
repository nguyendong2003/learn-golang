import { Body, Controller, Patch, Post } from '@nestjs/common'
import { ApiBearerAuth, ApiTags, ApiOkResponse, ApiCreatedResponse } from '@nestjs/swagger'
import { InventoryCalendarService } from './inventory-calendar.service'
import { SyncBookingDto } from './dto/request/sync-booking.dto'
import { StopSaleDto } from './dto/request/stop-sale.dto'
import { ManualUpdateInventoryDto } from './dto/request/manual-update-inventory.dto'
import { BulkUpdateInventoryDto } from './dto/request/bulk-update-inventory.dto'
import { InventoryCalendarResponseDto } from './dto/response/inventory-calendar-response.dto'
// import { Public } from '@/common/decorators/public.decorator'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'

@Controller('inventory-calendar')
@ApiBearerAuth()
@ApiTags('inventory-calendar')
export class InventoryCalendarController {
  constructor(private readonly service: InventoryCalendarService) {}

  @Post('sync-booking')
  // @Public()
  @Permission(PermissionCode.HOTEL_UPDATE, PermissionCode.TOUR_UPDATE)
  @SuccessMessage('Inventory synced')
  @ApiCreatedResponse({ description: 'Inventory synced' })
  async syncBooking(@Body() dto: SyncBookingDto) {
    return await this.service.syncBooking(dto)
  }

  @Post('stop-sale')
  // @Public()
  @Permission(PermissionCode.HOTEL_UPDATE, PermissionCode.TOUR_UPDATE)
  @SuccessMessage('Stop sale updated')
  @ApiOkResponse({ description: 'Stop sale updated' })
  async setStopSale(@Body() dto: StopSaleDto) {
    return await this.service.setStopSale(dto)
  }

  @Patch('manual-update')
  @Roles('ADMIN')
  @Permission(PermissionCode.HOTEL_UPDATE, PermissionCode.TOUR_UPDATE)
  @SuccessMessage('Inventory updated')
  @ApiSuccessResponse({ type: InventoryCalendarResponseDto, isArray: true, description: 'Inventory updated' })
  async manualUpdateInventory(
    @Body() dto: ManualUpdateInventoryDto,
  ): Promise<Array<InstanceType<typeof InventoryCalendarResponseDto>>> {
    return await this.service.manualUpdateInventory(dto)
  }

  @Patch('bulk-update')
  @Roles('ADMIN')
  @Permission(PermissionCode.HOTEL_UPDATE, PermissionCode.TOUR_UPDATE)
  @SuccessMessage('Bulk inventory updated')
  @ApiSuccessResponse({ type: InventoryCalendarResponseDto, isArray: true, description: 'Bulk inventory updated' })
  async bulkUpdateInventory(
    @Body() dto: BulkUpdateInventoryDto,
  ): Promise<Array<InstanceType<typeof InventoryCalendarResponseDto>>> {
    return await this.service.bulkUpdateInventory(dto)
  }
}
