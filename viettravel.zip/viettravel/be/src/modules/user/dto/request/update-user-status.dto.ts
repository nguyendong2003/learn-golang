import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'
import { UserStatusEnum } from '@/generated/prisma/enums'

export const UpdateUserStatusSchema = z.object({
  status: z.enum([UserStatusEnum.ACTIVE, UserStatusEnum.LOCKED]),
  reason: z.string().min(1, 'Vui lòng nhập lý do (reason) cho hành động này'),
})

export class UpdateUserStatusDto extends createZodDto(UpdateUserStatusSchema) {}
