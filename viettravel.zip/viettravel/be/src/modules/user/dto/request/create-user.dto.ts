import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'
import { RoleCode } from '@/common/enums/role.enum'

export const CreateUserSchema = z
  .strictObject({
    email: z.email('Invalid email address'),
    username: z.string().trim().min(1, 'Username is required').max(50, 'Username must be at most 50 characters'),
    password: z
      .string()
      .trim()
      .min(6, 'Password must be at least 6 characters')
      .max(36, 'Password must be at most 36 characters'),
    name: z.string(),
    phone: z.string().regex(/^(03|05|07|08|09)[0-9]{8}$/, 'Invalid phone number'),
    roleCode: z.enum(RoleCode, { message: 'Invalid role code' }).default(RoleCode.USER),
  })
  .meta({ id: 'CreateUser' })

export class CreateUserDto extends createZodDto(CreateUserSchema) {}
