import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'
import { UserStatusEnum, MembershipTierEnum } from '@/generated/prisma/enums'
import { PaginationQuerySchema } from '@/common/dtos/pagination.query'

export const QueryUserSchema = PaginationQuerySchema.extend({
  search: z.string().optional(),
  status: z.enum(UserStatusEnum).optional(),
  loyaltyTier: z.enum(MembershipTierEnum).optional(),
  isAffiliate: z
    .preprocess((val) => {
      if (val === 'true') return true
      if (val === 'false') return false
      return val
    }, z.boolean())
    .optional(),
})

export class QueryUserDto extends createZodDto(QueryUserSchema) {}
