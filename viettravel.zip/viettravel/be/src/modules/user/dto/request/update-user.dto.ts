import { createZodDto } from 'nestjs-zod'
import { CreateUserSchema } from '@/modules/user/dto/request/create-user.dto'

export const UpdateUserSchema = CreateUserSchema.omit({ password: true }).meta({
  id: 'UpdateUser',
})

export class UpdateUserDto extends createZodDto(UpdateUserSchema) {}
