import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'
import { MembershipTierEnum } from '@/generated/prisma/enums'

export const UpdateUserRankSchema = z.object({
  tier: z.enum(MembershipTierEnum),
  reason: z.string().min(1, 'Vui lòng nhập lý do thay đổi hạng thành viên').optional(),
})

export class UpdateUserRankDto extends createZodDto(UpdateUserRankSchema) {}
