import { UserStatusEnum } from '@/generated/prisma/browser'
import { createZodDto } from 'nestjs-zod'
import { z } from 'zod'

export const UserResponseSchema = z
  .object({
    id: z.uuid(),
    email: z.email(),
    username: z.string(),
    name: z.string().nullable(),
    phone: z.string().nullable(),
    avatar: z.url().nullable(),
    status: z.enum(UserStatusEnum),
    isAffiliate: z.boolean(),
    createdAt: z.iso.datetime(),
    updatedAt: z.iso.datetime(),
  })
  .meta({ id: 'UserResponse' })

export class UserResponseDto extends createZodDto(UserResponseSchema) {}
