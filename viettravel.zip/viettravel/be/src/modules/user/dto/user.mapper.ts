import { User } from '@/generated/prisma/client'
import { UserResponseDto } from '@/modules/user/dto/response/user-response.dto'

export class UsersMapper {
  static toResponse(user: User): UserResponseDto {
    return {
      id: user.id,
      username: user.username,
      email: user.email,
      name: user.name,
      phone: user.phone,
      avatar: user.avatarUrl,
      status: user.status,
      isAffiliate: user.isAffiliate,
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    } as UserResponseDto
  }

  static toResponseList(users: User[]): UserResponseDto[] {
    return users.map((user) => this.toResponse(user))
  }
}
