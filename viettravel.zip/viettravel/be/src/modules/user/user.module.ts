import { Module } from '@nestjs/common'
import { UsersService } from '@/modules/user/user.service'
import { UsersController } from '@/modules/user/user.controller'
import { UserRepository } from '@/modules/user/user.repository'
import { AuditModule } from '../audit/audit.module'

@Module({
  imports: [],
  providers: [UsersService, UserRepository],
  controllers: [UsersController],
  exports: [UsersService],
})
export class UsersModule {}
