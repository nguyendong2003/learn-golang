import { Injectable } from '@nestjs/common'
import { UserResponseDto } from '@/modules/user/dto/response/user-response.dto'
import { PaginatedResult, PaginationHelper } from '@/common/dtos/pagination'
import { UsersMapper } from '@/modules/user/dto/user.mapper'
import { UpdateUserDto } from '@/modules/user/dto/request/update-user.dto'
import { CreateUserDto } from './dto/request/create-user.dto'
import { QueryUserDto } from './dto/request/query-user.dto'
import { UpdateUserStatusDto } from './dto/request/update-user-status.dto'
import { UpdateUserRankDto } from './dto/request/update-user-rank.dto'
import { UserRepository } from '@/modules/user/user.repository'
import { ResourceConflictException, ResourceNotFoundException } from '@/common/errors/business.exception'
import { AuditService } from '@/modules/audit/audit.service'
import { RoleCode } from '@/common/enums/role.enum'
import { PrismaService } from '@/prisma/prisma.service'
import { Transactional } from '@/common/decorators/transactional.decorator'
import { Logger } from '@nestjs/common'

@Injectable()
export class UsersService {
  private readonly logger = new Logger(UsersService.name)
  constructor(
    public readonly prisma: PrismaService,
    private userRepository: UserRepository,
    private auditService: AuditService,
  ) {}

  async getPaginatedUsers(query: QueryUserDto): Promise<PaginatedResult<UserResponseDto>> {
    const [users, total] = await Promise.all([
      this.userRepository.findPaginatedUsers(query),
      this.userRepository.countUsers(query),
    ])
    const meta = PaginationHelper.getMeta(query.page, query.limit, total)
    const data = UsersMapper.toResponseList(users)
    return new PaginatedResult(data, meta)
  }

  async getById(id: string): Promise<UserResponseDto> {
    const user = await this.userRepository.findUserById(id)
    if (!user) {
      throw new ResourceNotFoundException('User not found')
    }
    return UsersMapper.toResponse(user)
  }

  @Transactional()
  async create(createUserDto: CreateUserDto): Promise<UserResponseDto> {
    const existingUser = await this.userRepository.findUserByEmail(createUserDto.email)
    if (existingUser) {
      throw new ResourceConflictException('User already exists')
    }
    try {
      const role = await this.userRepository.findRoleByCode(createUserDto.roleCode || RoleCode.USER)
      if (!role) throw new ResourceNotFoundException('Default user role not found')
      const start = Date.now()
      const user = await this.userRepository.createUser(createUserDto, role.id)
      return UsersMapper.toResponse(user)
    } catch (error: any) {
      if (error.code === 'P2002') {
        throw new ResourceConflictException('User already exists')
      }
      throw error
    }
  }

  async update(id: string, updateUserDto: UpdateUserDto): Promise<UserResponseDto> {
    try {
      const updatedUser = await this.userRepository.updateUser(id, updateUserDto)
      return UsersMapper.toResponse(updatedUser)
    } catch (error: any) {
      if (error.code === 'P2025') {
        throw new ResourceNotFoundException('User not found')
      }
      throw error
    }
  }

  @Transactional()
  async changeUserStatus(adminId: string, id: string, dto: UpdateUserStatusDto) {
    const user = await this.userRepository.findUserById(id)
    if (!user) throw new ResourceNotFoundException('User not found')
    const updated = await this.userRepository.updateUserStatus(id, dto.status)
    await this.auditService.logStaffAction(adminId, `Changed user ${id} status to ${dto.status}. Reason: ${dto.reason}`)
    return UsersMapper.toResponse(updated)
  }

  @Transactional()
  async updateMemberRank(adminId: string, id: string, dto: UpdateUserRankDto) {
    const user = await this.userRepository.findUserById(id)
    if (!user) throw new ResourceNotFoundException('User not found')
    await this.userRepository.upsertLoyaltyProfile(id, dto.tier)
    await this.auditService.logStaffAction(
      adminId,
      `Updated user ${id} membership rank to ${dto.tier}.${dto.reason ? ` Reason: ${dto.reason}` : ''}`,
    )
    return UsersMapper.toResponse(user)
  }

  @Transactional()
  async softDelete(adminId: string, id: string) {
    const user = await this.userRepository.findUserById(id)
    if (!user) throw new ResourceNotFoundException('User not found')
    await this.userRepository.softDeleteUser(id)
    await this.auditService.logStaffAction(adminId, `Soft deleted user ${id}`)
    return { success: true }
  }
}
