import { Body, Controller, Delete, Get, Param, ParseUUIDPipe, Patch, Post, Put, Query } from '@nestjs/common'
import { UsersService } from '@/modules/user/user.service'
import { PaginatedResult } from '@/common/dtos/pagination'
import { UpdateUserDto } from '@/modules/user/dto/request/update-user.dto'
import { UserResponseDto } from '@/modules/user/dto/response/user-response.dto'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { CreateUserDto } from './dto/request/create-user.dto'
import { QueryUserDto } from './dto/request/query-user.dto'
import { UpdateUserStatusDto } from './dto/request/update-user-status.dto'
import { UpdateUserRankDto } from './dto/request/update-user-rank.dto'
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger'
import { ApiParam } from '@nestjs/swagger/dist/decorators'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { ApiErrorResponse } from '@/common/decorators/api-error-responses.decorator'
import { ApiCreatedSuccessResponse } from '@/common/decorators/api-created-success-response.decorator'
import { CurrentUser } from '@/common/decorators/current-user.decorator'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'

@ApiTags('users')
@ApiBearerAuth()
@Controller('users')
export class UsersController {
  constructor(private usersService: UsersService) {}

  @Get('me')
  @Permission(PermissionCode.USER_SELF_READ)
  @SuccessMessage('Current user retrieved successfully')
  @ApiSuccessResponse({ type: UserResponseDto, description: 'Current user retrieved successfully' })
  @ApiErrorResponse('Current user not found')
  async getCurrentUser(@CurrentUser('id') userId: string): Promise<UserResponseDto> {
    return await this.usersService.getById(userId)
  }

  @Put('me')
  @Permission(PermissionCode.USER_SELF_UPDATE)
  @SuccessMessage('Current user updated successfully')
  @ApiSuccessResponse({ type: UserResponseDto, description: 'Current user updated successfully' })
  @ApiErrorResponse('Invalid current user payload')
  async updateCurrentUser(
    @CurrentUser('id') userId: string,
    @Body() updateUserDto: UpdateUserDto,
  ): Promise<UserResponseDto> {
    return await this.usersService.update(userId, updateUserDto)
  }

  @Get()
  @Permission(PermissionCode.USER_READ)
  @SuccessMessage('Users retrieved successfully')
  @ApiSuccessResponse({ type: UserResponseDto, isArray: true, hasMeta: true })
  @ApiErrorResponse('Invalid user list query')
  async getUsers(@Query() query: QueryUserDto): Promise<PaginatedResult<UserResponseDto>> {
    return await this.usersService.getPaginatedUsers(query)
  }

  @Get(':id')
  @Permission(PermissionCode.USER_READ)
  @SuccessMessage('User retrieved successfully')
  @ApiParam({ name: 'id', type: String, description: 'User ID (UUID)' })
  @ApiSuccessResponse({ type: UserResponseDto, description: 'User retrieved successfully' })
  @ApiErrorResponse('Invalid user id or user not found')
  async getUserById(@Param('id', new ParseUUIDPipe()) id: string): Promise<UserResponseDto> {
    return await this.usersService.getById(id)
  }

  @Post()
  @Permission(PermissionCode.USER_CREATE)
  @SuccessMessage('User created successfully')
  @ApiCreatedSuccessResponse({ type: UserResponseDto, description: 'User created successfully' })
  @ApiErrorResponse('Invalid user payload')
  async createUser(@Body() createUserDto: CreateUserDto): Promise<UserResponseDto> {
    return await this.usersService.create(createUserDto)
  }

  @Put(':id')
  @Permission(PermissionCode.USER_UPDATE)
  @SuccessMessage('User updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'User ID (UUID)' })
  @ApiSuccessResponse({ type: UserResponseDto, description: 'User updated successfully' })
  @ApiErrorResponse('Invalid user id or payload')
  async updateUser(
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateUserDto: UpdateUserDto,
  ): Promise<UserResponseDto> {
    return await this.usersService.update(id, updateUserDto)
  }

  @Patch(':id/status')
  @Permission(PermissionCode.USER_UPDATE)
  @SuccessMessage('User status updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'User ID (UUID)' })
  @ApiSuccessResponse({ type: UserResponseDto, description: 'User status updated' })
  @ApiErrorResponse('Invalid user id or status payload')
  async changeStatus(
    @CurrentUser('id') adminId: string,
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() dto: UpdateUserStatusDto,
  ): Promise<UserResponseDto> {
    return await this.usersService.changeUserStatus(adminId, id, dto)
  }

  @Patch(':id/rank')
  @Permission(PermissionCode.USER_UPDATE)
  @SuccessMessage('User rank updated successfully')
  @ApiParam({ name: 'id', type: String, description: 'User ID (UUID)' })
  @ApiSuccessResponse({ type: UserResponseDto, description: 'User rank updated' })
  @ApiErrorResponse('Invalid user id or rank payload')
  async updateRank(
    @CurrentUser('id') adminId: string,
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() dto: UpdateUserRankDto,
  ): Promise<UserResponseDto> {
    return await this.usersService.updateMemberRank(adminId, id, dto)
  }

  @Delete(':id')
  @Permission(PermissionCode.USER_DELETE)
  @SuccessMessage('User deleted successfully')
  @ApiParam({ name: 'id', type: String, description: 'User ID (UUID)' })
  @ApiSuccessResponse({ type: UserResponseDto, description: 'User soft deleted', hasData: false })
  @ApiErrorResponse('Invalid user id or user not found')
  async deleteUser(
    @CurrentUser('id') adminId: string,
    @Param('id', new ParseUUIDPipe()) id: string,
  ): Promise<{ success: boolean }> {
    return await this.usersService.softDelete(adminId, id)
  }
}
