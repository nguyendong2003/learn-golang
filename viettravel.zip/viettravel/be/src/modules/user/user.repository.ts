import { Injectable } from '@nestjs/common'
import { PrismaService } from '@/prisma/prisma.service'
import { Logger } from '@nestjs/common'
import { UpdateUserDto } from '@/modules/user/dto/request/update-user.dto'
import { CreateUserDto } from '@/modules/user/dto/request/create-user.dto'
import { UserStatusEnum, MembershipTierEnum } from '@/generated/prisma/enums'
import { QueryUserDto } from './dto/request/query-user.dto'
import { Prisma } from '@/generated/prisma/client'
import { RoleCode } from '@/common/enums/role.enum'
@Injectable()
export class UserRepository {
  constructor(private prisma: PrismaService) {}
  async findManyUsers() {
    return this.prisma.user.findMany({ where: { deletedAt: null } })
  }
  private buildFindUsersWhere(query: QueryUserDto): Prisma.UserWhereInput {
    const where: Prisma.UserWhereInput = { deletedAt: null }
    if (query.search) {
      where.OR = [
        { email: { contains: query.search, mode: 'insensitive' } },
        { name: { contains: query.search, mode: 'insensitive' } },
        { phone: { contains: query.search, mode: 'insensitive' } },
      ]
    }
    if (query.status) {
      where.status = query.status
    }
    if (query.isAffiliate !== undefined) {
      where.isAffiliate = query.isAffiliate
    }
    if (query.loyaltyTier) {
      where.loyaltyProfile = { currentTier: query.loyaltyTier }
    }
    return where
  }
  async findPaginatedUsers(query: QueryUserDto) {
    const skip = (query.page - 1) * query.limit
    const where = this.buildFindUsersWhere(query)
    return this.prisma.user.findMany({
      where,
      skip,
      take: query.limit,
      orderBy: { createdAt: 'desc' },
    })
  }
  async countUsers(query: QueryUserDto) {
    const where = this.buildFindUsersWhere(query)
    return this.prisma.user.count({ where })
  }
  async findUserById(id: string) {
    return this.prisma.user.findFirst({
      where: { id, deletedAt: null },
    })
  }
  async findUserByEmail(email: string) {
    return this.prisma.user.findFirst({
      where: { email, deletedAt: null },
    })
  }
  async findRoleByCode(code: RoleCode) {
    return this.prisma.role.findUnique({
      where: { code },
    })
  }
  async createUser(createUserDto: CreateUserDto, roleId: string) {
    const res = await this.prisma.user.create({
      data: {
        email: createUserDto.email,
        username: createUserDto.username,
        password: createUserDto.password,
        status: UserStatusEnum.ACTIVE,
        name: createUserDto.name,
        userRoles: {
          create: {
            roleId: roleId,
          },
        },
      },
    })
    return res
  }
  async updateUser(id: string, updateUserDto: UpdateUserDto) {
    return this.prisma.user.update({
      where: { id },
      data: updateUserDto,
    })
  }
  async updateUserStatus(id: string, status: UserStatusEnum) {
    return this.prisma.user.update({
      where: { id },
      data: { status },
    })
  }
  async upsertLoyaltyProfile(userId: string, tier: MembershipTierEnum) {
    return this.prisma.userLoyaltyProfile.upsert({
      where: { userId },
      update: { currentTier: tier, updatedAt: new Date() },
      create: { userId, currentTier: tier },
    })
  }
  async softDeleteUser(id: string) {
    return this.prisma.user.update({
      where: { id },
      data: {
        deletedAt: new Date(),
        status: UserStatusEnum.DELETED,
      },
    })
  }
}
