import { Injectable, Logger } from '@nestjs/common'
import { PrismaService } from '@/prisma/prisma.service'
import { CategoryRepository } from './category.repository'
import { CategoryType, CategoryTypeSchema } from './dto/schemas/category.schema'
import { CreateCategoryDto } from './dto/request/create-category.dto'
import { UpdateCategoryDto } from './dto/request/update-category.dto'
import {
  AppBadRequestException,
  ResourceConflictException,
  ResourceNotFoundException,
} from '@/common/errors/business.exception'

@Injectable()
export class CategoryService {
  private readonly logger = new Logger(CategoryService.name)

  constructor(private readonly categoryRepository: CategoryRepository) {}

  private parseCategoryType(type: string): CategoryType {
    const result = CategoryTypeSchema.safeParse(type)
    if (!result.success) {
      throw new AppBadRequestException(`Invalid category type '${type}'`)
    }
    return result.data
  }

  private buildCategoryData(type: CategoryType, dto: CreateCategoryDto | UpdateCategoryDto, isCreate: boolean) {
    if (type !== 'bed' && dto.capacity !== undefined) {
      throw new AppBadRequestException('capacity is only allowed for bed category')
    }
    if (type !== 'bed' && dto.code !== undefined) {
      throw new AppBadRequestException('code is only allowed for bed category')
    }
    if (type !== 'star-rating' && dto.starNumber !== undefined) {
      throw new AppBadRequestException('starNumber is only allowed for star-rating category')
    }

    const payload: Record<string, unknown> = {}
    const baseFields = ['name', 'slug', 'description', 'iconUrl', 'sortOrder', 'isActive'] as const

    for (const field of baseFields) {
      if (field in dto && dto[field] !== undefined) {
        payload[field] = dto[field]
      }
    }

    if (type === 'bed') {
      payload.code = dto.code ?? (isCreate ? dto.slug : undefined)
      payload.capacity = dto.capacity ?? (isCreate ? 2 : undefined)
    }

    if (type === 'star-rating') {
      if (dto.starNumber !== undefined) {
        payload.starNumber = dto.starNumber
      } else if (isCreate) {
        throw new AppBadRequestException('starNumber is required for star-rating')
      }
    }

    return payload
  }

  private appendCategoryType<T extends Record<string, unknown>>(
    type: CategoryType,
    category: T,
  ): T & { type: CategoryType } {
    return { ...category, type }
  }

  async listCategories(type: string) {
    const categoryType = this.parseCategoryType(type)
    const categories = await this.categoryRepository.findMany(categoryType)
    return categories.map((c) => this.appendCategoryType(categoryType, c))
  }

  async getCategory(type: string, id: string) {
    const categoryType = this.parseCategoryType(type)
    const category = await this.categoryRepository.findById(categoryType, id)
    if (!category) {
      throw new ResourceNotFoundException('Category not found')
    }
    return this.appendCategoryType(categoryType, category)
  }

  async createCategory(type: string, dto: CreateCategoryDto) {
    const categoryType = this.parseCategoryType(type)
    const data = this.buildCategoryData(categoryType, dto, true)

    try {
      const category = await this.categoryRepository.create(categoryType, data)
      return this.appendCategoryType(categoryType, category)
    } catch (error: any) {
      if (error?.code === 'P2002') {
        throw new ResourceConflictException('Category already exists')
      }
      this.logger.error('createCategory failed', error)
      throw error
    }
  }

  async updateCategory(type: string, id: string, dto: UpdateCategoryDto) {
    const categoryType = this.parseCategoryType(type)
    const data = this.buildCategoryData(categoryType, dto, false)

    try {
      const category = await this.categoryRepository.update(categoryType, id, data)
      return this.appendCategoryType(categoryType, category)
    } catch (error: any) {
      if (error?.code === 'P2025') {
        throw new ResourceNotFoundException('Category not found')
      }
      if (error?.code === 'P2002') {
        throw new ResourceConflictException('Category already exists')
      }
      this.logger.error('updateCategory failed', error)
      throw error
    }
  }

  async deleteCategory(type: string, id: string) {
    const categoryType = this.parseCategoryType(type)

    try {
      await this.categoryRepository.softDelete(categoryType, id)
    } catch (error: any) {
      if (error?.code === 'P2025') {
        throw new ResourceNotFoundException('Category not found')
      }
      this.logger.error('deleteCategory failed', error)
      throw error
    }
  }
}
