import { Test, TestingModule } from '@nestjs/testing'
import { CategoryService } from './category.service'
import { CategoryRepository } from './category.repository'
import { PrismaService } from '@/prisma/prisma.service'
import { AppBadRequestException } from '@/common/errors/business.exception'

describe('CategoryService', () => {
  let service: CategoryService

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [
        CategoryService,
        {
          provide: CategoryRepository,
          useValue: {
            findMany: jest.fn(),
            findById: jest.fn(),
            create: jest.fn(),
            update: jest.fn(),
            softDelete: jest.fn(),
          },
        },
        {
          provide: PrismaService,
          useValue: {
            $transaction: jest.fn(),
          },
        },
      ],
    }).compile()

    service = module.get<CategoryService>(CategoryService)
  })

  it('should be defined', () => {
    expect(service).toBeDefined()
  })

  it('throws bad request for invalid category type', async () => {
    await expect(service.listCategories('invalid-type')).rejects.toThrow(AppBadRequestException)
  })
})
