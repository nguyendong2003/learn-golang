import { Injectable } from '@nestjs/common'
import { PrismaService } from '@/prisma/prisma.service'
import { CategoryType } from './dto/schemas/category.schema'

const CATEGORY_TYPE_TO_MODEL: Record<CategoryType, string> = {
  'activity-field': 'activityFieldCategory',
  bed: 'bedCategory',
  blog: 'blogCategory',
  tour: 'tourCategory',
  hotel: 'hotelCategory',
  'star-rating': 'starRatingCategory',
  room: 'roomCategory',
  'hotel-facility': 'hotelFacilityCategory',
  'room-facility': 'roomFacilityCategory',
  transportation: 'transportationCategory',
  meal: 'mealCategory',
}

@Injectable()
export class CategoryRepository {
  constructor(private prisma: PrismaService) {}

  private getModel(type: CategoryType): any {
    const modelName = CATEGORY_TYPE_TO_MODEL[type]
    return (this.prisma as any)[modelName]
  }

  findMany(type: CategoryType): any {
    return this.getModel(type).findMany({ where: { deletedAt: null } })
  }

  findById(type: CategoryType, id: string): any {
    return this.getModel(type).findFirst({
      where: {
        id,
        deletedAt: null,
      },
    })
  }

  create(type: CategoryType, data: Record<string, unknown>): any {
    return this.getModel(type).create({ data })
  }

  update(type: CategoryType, id: string, data: Record<string, unknown>): any {
    return this.getModel(type).update({
      where: { id },
      data,
    })
  }

  softDelete(type: CategoryType, id: string): any {
    return this.getModel(type).update({
      where: { id },
      data: { deletedAt: new Date(), isActive: false },
    })
  }
}
