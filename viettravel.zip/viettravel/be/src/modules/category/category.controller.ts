import { Body, Controller, Delete, Get, HttpCode, Param, ParseUUIDPipe, Patch, Post } from '@nestjs/common'
import { ApiBearerAuth, ApiCreatedResponse, ApiOkResponse, ApiParam, ApiTags } from '@nestjs/swagger'
import { CategoryService } from './category.service'
import { CreateCategoryDto } from './dto/request/create-category.dto'
import { UpdateCategoryDto } from './dto/request/update-category.dto'
import { CategoryResponseDto } from './dto/response/category-response.dto'
import { CategoryTypeSchema } from './dto/schemas/category.schema'
import { SuccessMessage } from '@/common/decorators/success-message.decorator'
import { ApiSuccessResponse } from '@/common/decorators/api-success-response.decorator'
import { Roles } from '@/common/decorators/roles.decorator'
import { Permission } from '@/common/decorators/allow-permission.decorator'
import { PermissionCode } from '@/common/enums/permission.enum'

@Controller('categories')
@ApiTags('categories')
@ApiBearerAuth()
export class CategoryController {
  constructor(private readonly categoryService: CategoryService) {}

  @Get(':type')
  @Permission(PermissionCode.CATEGORY_READ)
  @SuccessMessage('Categories retrieved successfully')
  @ApiParam({ name: 'type', description: 'Category type', schema: { enum: CategoryTypeSchema.options } })
  @ApiSuccessResponse({ type: CategoryResponseDto, isArray: true })
  async listCategories(@Param('type') type: string): Promise<unknown[]> {
    return await this.categoryService.listCategories(type)
  }

  @Get(':type/:id')
  @Permission(PermissionCode.CATEGORY_READ)
  @SuccessMessage('Category retrieved successfully')
  @ApiParam({ name: 'type', description: 'Category type', schema: { enum: CategoryTypeSchema.options } })
  @ApiParam({ name: 'id', type: String, description: 'Category ID (UUID)' })
  @ApiOkResponse({ type: CategoryResponseDto })
  async getCategory(@Param('type') type: string, @Param('id', new ParseUUIDPipe()) id: string): Promise<unknown> {
    return await this.categoryService.getCategory(type, id)
  }

  @Post(':type')
  @Permission(PermissionCode.CATEGORY_CREATE)
  @SuccessMessage('Category created successfully')
  @ApiParam({ name: 'type', description: 'Category type', schema: { enum: CategoryTypeSchema.options } })
  @ApiCreatedResponse({ type: CategoryResponseDto })
  async createCategory(@Param('type') type: string, @Body() createCategoryDto: CreateCategoryDto): Promise<unknown> {
    return await this.categoryService.createCategory(type, createCategoryDto)
  }

  @Patch(':type/:id')
  @Permission(PermissionCode.CATEGORY_UPDATE)
  @SuccessMessage('Category updated successfully')
  @ApiParam({ name: 'type', description: 'Category type', schema: { enum: CategoryTypeSchema.options } })
  @ApiParam({ name: 'id', type: String, description: 'Category ID (UUID)' })
  @ApiOkResponse({ type: CategoryResponseDto })
  async updateCategory(
    @Param('type') type: string,
    @Param('id', new ParseUUIDPipe()) id: string,
    @Body() updateCategoryDto: UpdateCategoryDto,
  ): Promise<unknown> {
    return await this.categoryService.updateCategory(type, id, updateCategoryDto)
  }

  @Delete(':type/:id')
  @HttpCode(204)
  @Permission(PermissionCode.CATEGORY_DELETE)
  @SuccessMessage('Category deleted successfully')
  @ApiParam({ name: 'type', description: 'Category type', schema: { enum: CategoryTypeSchema.options } })
  @ApiParam({ name: 'id', type: String, description: 'Category ID (UUID)' })
  async deleteCategory(@Param('type') type: string, @Param('id', new ParseUUIDPipe()) id: string): Promise<void> {
    return await this.categoryService.deleteCategory(type, id)
  }
}
