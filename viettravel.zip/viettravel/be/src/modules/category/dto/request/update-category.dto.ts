import { createZodDto } from 'nestjs-zod'
import { UpdateCategorySchema } from '../schemas/category.schema'

export class UpdateCategoryDto extends createZodDto(UpdateCategorySchema) {}
