import { createZodDto } from 'nestjs-zod'
import { CreateCategorySchema } from '../schemas/category.schema'

export class CreateCategoryDto extends createZodDto(CreateCategorySchema) {}
