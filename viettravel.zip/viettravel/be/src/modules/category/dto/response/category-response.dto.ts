import { createZodDto } from 'nestjs-zod'
import { CategoryResponseSchema } from '../schemas/category.schema'

export class CategoryResponseDto extends createZodDto(CategoryResponseSchema) {}
