import { z } from 'zod'

export const CategoryTypeSchema = z.enum([
  'activity-field',
  'bed',
  'blog',
  'tour',
  'hotel',
  'star-rating',
  'room',
  'hotel-facility',
  'room-facility',
  'transportation',
  'meal',
])

export type CategoryType = z.infer<typeof CategoryTypeSchema>

const BaseCategorySchema = z.object({
  name: z.string().min(1).max(255),
  slug: z.string().min(1).max(255),
  description: z.string().optional(),
  iconUrl: z.string().optional(),
  sortOrder: z.number().int().positive().optional(),
  isActive: z.boolean().optional(),
})

export const CreateCategorySchema = BaseCategorySchema.extend({
  code: z.string().max(50).optional(),
  capacity: z.number().int().positive().min(1).max(2).optional(),
  starNumber: z.number().int().positive().max(5).optional(),
})

export const UpdateCategorySchema = CreateCategorySchema.partial()

export const CategoryResponseSchema = z.object({
  id: z.string().uuid(),
  type: CategoryTypeSchema,
  name: z.string(),
  slug: z.string(),
  description: z.string().nullable().optional(),
  iconUrl: z.string().nullable().optional(),
  sortOrder: z.number().nullable().optional(),
  isActive: z.boolean().nullable().optional(),
  code: z.string().nullable().optional(),
  capacity: z.number().nullable().optional(),
  starNumber: z.number().nullable().optional(),
  createdAt: z.string(),
  updatedAt: z.string(),
  deletedAt: z.string().nullable().optional(),
})

export const CategoryListResponseSchema = z.array(CategoryResponseSchema)
