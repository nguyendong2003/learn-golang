import { Logger } from '@nestjs/common'
import type { CorsOptions, CustomOrigin } from '@nestjs/common/interfaces/external/cors-options.interface'

import type { Env } from '@/config/env.validation'

export type CorsEnv = Pick<Env, 'NODE_ENV' | 'FE_URL' | 'CORS_ORIGINS'>

const logger = new Logger('Cors')

const LOCALHOST_HOSTNAMES = new Set(['localhost', '127.0.0.1', '::1'])

const COMMON_OPTIONS = {
  credentials: true,
  methods: ['GET', 'HEAD', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Authorization', 'Content-Type', 'X-Request-Id', 'X-Requested-With', 'Accept', 'Accept-Language'],
  exposedHeaders: ['X-Request-Id', 'X-Total-Count', 'Content-Disposition'],
  maxAge: 600, // 10 min cache preflight, enough for reduce OPTIONS spam without causing issues for users with long idle times
} satisfies Partial<CorsOptions>

function parseOrigins(raw: string | undefined, fallback: string): string[] {
  const list = (raw ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
  if (list.length === 0) list.push(fallback)
  return Array.from(new Set(list))
}

function isLocalhostOrigin(origin: string): boolean {
  try {
    const url = new URL(origin)
    return LOCALHOST_HOSTNAMES.has(url.hostname)
  } catch {
    return false
  }
}

/**
 * Build CORS options by environment.
 *
 * - **development**: allow any origin
 * - **production / test**: strict allowlist from `CORS_ORIGINS` (fallback `FE_URL`).
 */
export function buildCorsOptions(env: CorsEnv): CorsOptions {
  const isDev = env.NODE_ENV === 'development'
  const allowlist = parseOrigins(env.CORS_ORIGINS, env.FE_URL)

  const origin: CustomOrigin = (requestOrigin, callback) => {
    if (!requestOrigin) {
      callback(null, true)
      return
    }

    if (allowlist.includes(requestOrigin)) {
      callback(null, true)
      return
    }

    if (isDev && isLocalhostOrigin(requestOrigin)) {
      callback(null, true)
      return
    }

    logger.warn(`Blocked CORS origin: ${requestOrigin}`)
    callback(new Error(`Origin ${requestOrigin} not allowed by CORS`), false)
  }

  logger.log(`CORS allowlist (${env.NODE_ENV}): ${allowlist.join(', ')}${isDev ? ' + any localhost' : ''}`)

  return {
    ...COMMON_OPTIONS,
    origin,
  }
}
