import { z } from 'zod'

export const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  BE_URL: z.url().default('http://localhost:3001'),
  FE_URL: z.url().default('http://localhost:3000'),
  PORT: z.coerce.number().int().positive().default(3001),

  CORS_ORIGINS: z.string().optional().default(''),

  DATABASE_URL: z.url(),
  DATABASE_PORT: z.coerce.number().int().positive().default(5432),
  DATABASE_USER: z.string().min(1),
  DATABASE_PASSWORD: z.string().min(1),
  DATABASE_NAME: z.string().min(1),

  JWT_ACCESS_SECRET: z.string().min(16),
  JWT_REFRESH_SECRET: z.string().min(16),
  JWT_ACCESS_TTL: z.string().default('15m'),
  JWT_REFRESH_TTL: z.string().default('7d'),
  BCRYPT_ROUNDS: z.coerce.number().int().min(10).max(15).default(12),

  MINIO_HOST: z.string().default('localhost'),
  MINIO_PORT: z.coerce.number().int().positive().default(9000),
  MINIO_CONSOLE_PORT: z.coerce.number().int().positive().default(9001),
  MINIO_USE_SSL: z
    .string()
    .transform((value) => value === 'true')
    .default(false),
  MINIO_REGION: z.string().default('ap-southeast-1'),
  MINIO_BUCKET: z.string().default('travel-dev'),
  MINIO_ACCESS_KEY: z.string().min(1),
  MINIO_SECRET_KEY: z.string().min(1),
  MINIO_PUBLIC_ENDPOINT: z.url().default('http://localhost:9000'),

  REDIS_HOST: z.string().default('localhost'),
  REDIS_PORT: z.coerce.number().int().positive().default(6379),
  REDIS_PASSWORD: z.string().optional().default(''),
})

export type Env = z.infer<typeof EnvSchema>

export function validateEnv(config: Record<string, unknown>): Env {
  const parsed = EnvSchema.safeParse(config)
  if (!parsed.success) {
    const issues = parsed.error.issues.map((issue) => `  - ${issue.path.join('.')}: ${issue.message}`).join('\n')
    throw new Error(`Invalid environment variables:\n${issues}`)
  }
  return parsed.data
}
