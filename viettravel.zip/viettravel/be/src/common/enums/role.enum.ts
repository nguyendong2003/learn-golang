export const RoleCode = {
  ADMIN: 'ADMIN',
  USER: 'USER',
  CONTENT_MODERATOR: 'CONTENT_MODERATOR',
  CUSTOMER_SUPPORT: 'CUSTOMER_SUPPORT',
  FINANCE: 'FINANCE',
  MARKETING: 'MARKETING',
} as const

export type RoleCode = (typeof RoleCode)[keyof typeof RoleCode]
