export const PermissionCode = {
  // User Management
  USER_READ: 'user.read',
  USER_CREATE: 'user.create',
  USER_UPDATE: 'user.update',
  USER_DELETE: 'user.delete',

  // Self Management
  USER_SELF_READ: 'user.read.own',
  USER_SELF_UPDATE: 'user.update.own',

  // Role Management
  ROLE_READ: 'role.read',
  ROLE_CREATE: 'role.create',
  ROLE_UPDATE: 'role.update',
  ROLE_DELETE: 'role.delete',

  // Agent Management
  AGENT_READ: 'agent.read',
  AGENT_CREATE: 'agent.create',
  AGENT_REGISTER: 'agent.register',
  AGENT_UPDATE: 'agent.update',
  AGENT_DELETE: 'agent.delete',

  // Destination Management
  DESTINATION_READ: 'destination.read',
  DESTINATION_CREATE: 'destination.create',
  DESTINATION_UPDATE: 'destination.update',
  DESTINATION_DELETE: 'destination.delete',

  // Tour Management
  TOUR_READ: 'tour.read',
  TOUR_CREATE: 'tour.create',
  TOUR_UPDATE: 'tour.update',
  TOUR_DELETE: 'tour.delete',

  // Hotel Management
  HOTEL_READ: 'hotel.read',
  HOTEL_CREATE: 'hotel.create',
  HOTEL_UPDATE: 'hotel.update',
  HOTEL_DELETE: 'hotel.delete',

  // Booking Management
  BOOKING_READ: 'booking.read',
  BOOKING_CREATE: 'booking.create',
  BOOKING_UPDATE: 'booking.update',
  BOOKING_DELETE: 'booking.delete',

  // Payment Management
  PAYMENT_READ: 'payment.read',
  PAYMENT_UPDATE: 'payment.update',

  // Review Management
  REVIEW_READ: 'review.read',
  REVIEW_UPDATE: 'review.update',
  REVIEW_DELETE: 'review.delete',

  // Promotion Management
  PROMOTION_READ: 'promotion.read',
  PROMOTION_CREATE: 'promotion.create',
  PROMOTION_UPDATE: 'promotion.update',
  PROMOTION_DELETE: 'promotion.delete',

  // Voucher Management
  VOUCHER_READ: 'voucher.read',
  VOUCHER_CREATE: 'voucher.create',
  VOUCHER_UPDATE: 'voucher.update',
  VOUCHER_DELETE: 'voucher.delete',

  // Blog/Content Management
  BLOG_READ: 'blog.read',
  BLOG_CREATE: 'blog.create',
  BLOG_UPDATE: 'blog.update',
  BLOG_DELETE: 'blog.delete',

  // Dispute Management
  DISPUTE_READ: 'dispute.read',
  DISPUTE_UPDATE: 'dispute.update',

  // Affiliate Management
  AFFILIATE_READ: 'affiliate.read',
  AFFILIATE_UPDATE: 'affiliate.update',
  AFFILIATE_DELETE: 'affiliate.delete',

  // Loyalty & Points
  LOYALTY_READ: 'loyalty.read',
  LOYALTY_UPDATE: 'loyalty.update',

  // Category Management
  CATEGORY_READ: 'category.read',
  CATEGORY_CREATE: 'category.create',
  CATEGORY_UPDATE: 'category.update',
  CATEGORY_DELETE: 'category.delete',

  // Tour Category Management
  TOUR_CATEGORY_READ: 'tour-category.read',
  TOUR_CATEGORY_CREATE: 'tour-category.create',
  TOUR_CATEGORY_UPDATE: 'tour-category.update',
  TOUR_CATEGORY_DELETE: 'tour-category.delete',

  // Transportation Category Management
  TRANSPORTATION_CATEGORY_READ: 'transportation-category.read',
  TRANSPORTATION_CATEGORY_CREATE: 'transportation-category.create',
  TRANSPORTATION_CATEGORY_UPDATE: 'transportation-category.update',
  TRANSPORTATION_CATEGORY_DELETE: 'transportation-category.delete',
} as const

export type PermissionCode = (typeof PermissionCode)[keyof typeof PermissionCode]

export const ALL_PERMISSIONS = Object.values(PermissionCode)
