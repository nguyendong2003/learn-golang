import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common'
import { map } from 'rxjs/internal/operators/map'
import { ApiResponse } from '@/common/dtos/api-response.dto'
import { Observable } from 'rxjs/internal/Observable'
import { SUCCESS_MESSAGE_METADATA_KEY } from '@/common/decorators/success-message.decorator'
import { Reflector } from '@nestjs/core'
import { PaginatedResult } from '@/common/dtos/pagination'

@Injectable()
export class GlobalResponseInterceptor implements NestInterceptor<any, ApiResponse<any>> {
  constructor(private readonly reflector: Reflector) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<ApiResponse<any>> {
    const message = this.reflector.get<string>(SUCCESS_MESSAGE_METADATA_KEY, context.getHandler()) || 'Success'

    return next.handle().pipe(
      map((result) => {
        const requestPath = context.switchToHttp().getRequest<Request>().url

        // If handler returned PaginatedResult, flatten meta to top-level
        if (result instanceof PaginatedResult) {
          return {
            success: true,
            message,
            data: result.data,
            meta: result.meta,
            path: requestPath,
            timestamp: new Date().toISOString(),
          }
        }

        // default behavior
        return {
          success: true,
          message,
          data: result,
          path: requestPath,
          timestamp: new Date().toISOString(),
        }
      }),
    )
  }
}
