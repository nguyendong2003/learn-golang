import { Injectable, CanActivate, ExecutionContext, ForbiddenException } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { PERMISSION_KEY } from '@/common/decorators/allow-permission.decorator'
import { PrismaService } from '@/prisma/prisma.service'
import { AppForbiddenException } from '../errors/business.exception'

@Injectable()
export class PermissionGuard implements CanActivate {
  constructor(
    private reflector: Reflector,
    private prisma: PrismaService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const requiredPermissions = this.reflector.getAllAndOverride<string[]>(PERMISSION_KEY, [
      context.getHandler(),
      context.getClass(),
    ])

    if (!requiredPermissions || requiredPermissions.length === 0) {
      return true
    }

    const request = context.switchToHttp().getRequest()
    const user = request.user

    if (!user) {
      throw new AppForbiddenException('User not authenticated')
    }

    // TODO: optimize this using Redis caching roles and its permissions
    const userWithRole = await this.prisma.user.findUnique({
      where: { id: user.id },
      include: {
        userRoles: {
          include: {
            role: {
              include: {
                rolePermissions: {
                  include: {
                    permission: true,
                  },
                },
              },
            },
          },
        },
      },
    })

    if (!userWithRole || !userWithRole.userRoles.length) {
      throw new AppForbiddenException('User does not have a valid role')
    }

    const userPermissions = userWithRole.userRoles
      .flatMap((ur) => ur.role.rolePermissions)
      .map((rp) => rp.permission.code)

    const hasPermission = requiredPermissions.some((reqPerm) => userPermissions.includes(reqPerm))

    if (!hasPermission) {
      throw new AppForbiddenException('You do not have permission to access this resource')
    }

    return true
  }
}
