import { Injectable } from '@nestjs/common'
import { AuthGuard } from '@nestjs/passport'

// Used for login with email and password
@Injectable()
export class LocalAuthGuard extends AuthGuard('local') {}
