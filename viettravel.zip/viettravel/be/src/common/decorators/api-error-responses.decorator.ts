import { applyDecorators } from '@nestjs/common'
import { ApiBadRequestResponse, ApiExtraModels, ApiInternalServerErrorResponse, getSchemaPath } from '@nestjs/swagger'
import { ApiErrorResponseSchema } from '@/common/dtos/api-response.dto'

export function ApiErrorResponse(description = 'Error') {
  return applyDecorators(
    ApiExtraModels(ApiErrorResponseSchema),
    ApiBadRequestResponse({
      description,
      schema: {
        allOf: [
          {
            $ref: getSchemaPath(ApiErrorResponseSchema),
          },
        ],
      },
    }),
    ApiInternalServerErrorResponse({
      description: 'Internal server error',
      schema: {
        allOf: [
          {
            $ref: getSchemaPath(ApiErrorResponseSchema),
          },
        ],
      },
    }),
  )
}
