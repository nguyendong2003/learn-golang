import { SetMetadata } from '@nestjs/common'

export const SUCCESS_MESSAGE_METADATA_KEY = 'success_message'

/**
 * Decorator that attaches a success message to a route handler.
 *
 * The message is stored as metadata and can be retrieved by an interceptor
 * (such as a global response interceptor) to automatically include
 * a standardized success message in the API response.
 *
 * @param message - Success message to include in the API response
 * @returns Method decorator that sets success message metadata
 *
 * @example
 * ```typescript
 * @Post("users")
 * @SuccessMessage("User created successfully")
 * async createUser(@Body() dto: CreateUserDto) {
 *   return { id: 1, name: "John" };
 * }
 * ```
 */
export const SuccessMessage = (message: string): MethodDecorator => SetMetadata(SUCCESS_MESSAGE_METADATA_KEY, message)
