import { prismaTransactionContext } from '@/prisma/prisma.context'
import { AppInternalServerException } from '@/common/errors/business.exception'
import { PrismaService } from '@/prisma/prisma.service'
import { Logger } from '@nestjs/common'

export type TransactionalOptions = {
  maxWait?: number
  timeout?: number
}

/**
 * Wraps the execution of a class method within a Prisma $transaction.
 * The class MUST have a valid instance property called "prisma".
 */
export function Transactional(options?: TransactionalOptions) {
  return function (target: any, _propertyKey: string, descriptor: PropertyDescriptor) {
    const originalMethod = descriptor.value
    const logger = new Logger('Transactional')

    descriptor.value = async function (...args: any[]) {
      const prisma = (this as { prisma?: PrismaService }).prisma

      if (!prisma || typeof prisma.$transaction !== 'function') {
        throw new AppInternalServerException(
          `@Transactional(): Class ${target.constructor.name} requires a property named "prisma"`,
        )
      }

      // If already inside a transaction, continue using it without creating an inner transaction
      // (Prisma does not support nested transactions natively via interactive transactions by default)
      if (prismaTransactionContext.getStore()) {
        return originalMethod.apply(this, args)
      }

      // Start a new Prisma transaction with safe defaults
      const txOptions: TransactionalOptions = { maxWait: 2000, timeout: 5000, ...(options || {}) }
      logger.debug(`${target.constructor.name}.${_propertyKey || 'method'} - starting transaction`)
      try {
        return await prisma.$transaction(async (tx) => {
          // Provide the transaction instance in the async local storage context
          return await prismaTransactionContext.run({ tx }, async () => {
            try {
              const result = await originalMethod.apply(this, args)
              return result
            } finally {
              logger.debug(`${target.constructor.name}.${_propertyKey || 'method'} - transaction block completed`)
            }
          })
        }, txOptions)
      } catch (err: any) {
        logger.error(
          `${target.constructor.name}.${_propertyKey || 'method'} - transaction failed: ${err?.message || err}`,
        )
        throw err
      } finally {
        logger.debug(`${target.constructor.name}.${_propertyKey || 'method'} - transaction finished`)
      }
    }

    return descriptor
  }
}

export const Transaction = Transactional
