import { createParamDecorator, ExecutionContext } from '@nestjs/common'

export const CurrentUser = createParamDecorator((data: string, ctx: ExecutionContext) => {
  const request = ctx.switchToHttp().getRequest()
  // Dummy implementation until AuthModule is connected
  const user = request.user || { id: '00000000-0000-0000-0000-000000000000', role: 'ADMIN' }
  return data ? user?.[data] : user
})
