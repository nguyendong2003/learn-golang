import { applyDecorators, Type } from '@nestjs/common'
import { ApiCreatedResponse, ApiExtraModels, getSchemaPath } from '@nestjs/swagger'
import { ReferenceObject, SchemaObject } from '@nestjs/swagger/dist/interfaces/open-api-spec.interface'
import { ApiSuccessResponseSchema, PaginationMetaSchema } from '@/common/dtos/api-response.dto'

interface ApiCreatedSuccessResponseOptions<TModel extends Type<any>> {
  type: TModel
  isArray?: boolean
  hasData?: boolean
  hasMeta?: boolean
  description?: string
}

export function ApiCreatedSuccessResponse<TModel extends Type<any>>(options: ApiCreatedSuccessResponseOptions<TModel>) {
  const { type, isArray = false, hasData = true, hasMeta = false, description = 'Created' } = options

  const properties: Record<string, SchemaObject | ReferenceObject> = {}

  if (hasData) {
    properties.data = isArray
      ? {
          type: 'array',
          items: {
            $ref: getSchemaPath(type),
          },
        }
      : {
          $ref: getSchemaPath(type),
        }
  }

  if (hasMeta) {
    properties.meta = {
      $ref: getSchemaPath(PaginationMetaSchema),
    }
  }

  return applyDecorators(
    ApiExtraModels(ApiSuccessResponseSchema, PaginationMetaSchema, type),
    ApiCreatedResponse({
      description,
      schema: {
        allOf: [
          {
            $ref: getSchemaPath(ApiSuccessResponseSchema),
          },
          {
            properties,
          },
        ],
      },
    }),
  )
}
