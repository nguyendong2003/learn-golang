import { applyDecorators, Type } from '@nestjs/common'
import { ApiExtraModels, ApiOkResponse, getSchemaPath } from '@nestjs/swagger'
import { ReferenceObject, SchemaObject } from '@nestjs/swagger/dist/interfaces/open-api-spec.interface'
import { ApiSuccessResponseSchema, PaginationMetaSchema } from '@/common/dtos/api-response.dto'

interface ApiSuccessResponseOptions<TModel extends Type<any>> {
  type: TModel
  isArray?: boolean
  hasData?: boolean
  hasMeta?: boolean
  description?: string
}

export function ApiSuccessResponse<TModel extends Type<any>>(options: ApiSuccessResponseOptions<TModel>) {
  const { type, isArray = false, hasData = true, hasMeta = false, description = 'Success' } = options

  const properties: Record<string, SchemaObject | ReferenceObject> = {}

  if (hasData) {
    properties.data = isArray
      ? {
          type: 'array',
          items: {
            $ref: getSchemaPath(type),
          },
        }
      : {
          $ref: getSchemaPath(type),
        }
  }

  if (hasMeta) {
    properties.meta = {
      $ref: getSchemaPath(PaginationMetaSchema),
    }
  }

  return applyDecorators(
    ApiExtraModels(ApiSuccessResponseSchema, PaginationMetaSchema, type),
    ApiOkResponse({
      description,
      schema: {
        allOf: [
          {
            $ref: getSchemaPath(ApiSuccessResponseSchema),
          },
          {
            properties,
          },
        ],
      },
    }),
  )
}
