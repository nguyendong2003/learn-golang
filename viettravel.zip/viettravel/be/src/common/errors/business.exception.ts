import { HttpException, HttpStatus } from '@nestjs/common'
import { ErrorCode } from './errors-code'

export abstract class BusinessException extends HttpException {
  constructor(message: string, errorCode: ErrorCode, statusCode: number, errors?: Record<string, string[]>) {
    super(
      {
        statusCode,
        errorCode,
        message,
        errors,
      },
      statusCode,
    )
  }
}

export class ResourceNotFoundException extends BusinessException {
  constructor(message: string) {
    super(message, ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND)
  }
}

export class ResourceConflictException extends BusinessException {
  constructor(message: string) {
    super(message, ErrorCode.DUPLICATE, HttpStatus.CONFLICT)
  }
}

export class AppInternalServerException extends BusinessException {
  constructor(message: string) {
    super(message, ErrorCode.INTERNAL_SERVER_ERROR, HttpStatus.INTERNAL_SERVER_ERROR)
  }
}

export class AppBadRequestException extends BusinessException {
  constructor(message: string, errors?: Record<string, string[]>) {
    super(message, ErrorCode.BAD_REQUEST, HttpStatus.BAD_REQUEST, errors)
  }
}

export class AppUnauthorizedException extends BusinessException {
  constructor(message: string) {
    super(message, ErrorCode.UNAUTHORIZED, HttpStatus.UNAUTHORIZED)
  }
}

export class AppForbiddenException extends BusinessException {
  constructor(message: string) {
    super(message, ErrorCode.FORBIDDEN, HttpStatus.FORBIDDEN)
  }
}

export class ValidationFailedException extends BusinessException {
  constructor(message: string, errors?: Record<string, string[]>) {
    super(message, ErrorCode.VALIDATION_ERROR, HttpStatus.UNPROCESSABLE_ENTITY, errors)
  }
}
