import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus } from '@nestjs/common'
import { ConfigService } from '@nestjs/config'
import { Request, Response } from 'express'

import { Env } from '@/config/env.validation'
import { ApiResponse } from '@/common/dtos/api-response.dto'
import { ErrorCode } from '../errors/errors-code'
import { BusinessException } from '../errors/business.exception'

@Catch()
export class GlobalExceptionFilter implements ExceptionFilter {
  constructor(private readonly configService: ConfigService<Env, true>) {}

  catch(exception: unknown, host: ArgumentsHost): void {
    const ctx = host.switchToHttp()
    const response = ctx.getResponse<Response>()
    const request = ctx.getRequest<Request>()

    let statusCode = HttpStatus.INTERNAL_SERVER_ERROR
    let message = 'Internal server error'
    let errorCode: ErrorCode = ErrorCode.INTERNAL_SERVER_ERROR
    let errors: Record<string, string[]> | undefined

    if (exception instanceof BusinessException) {
      const exceptionResponse = exception.getResponse() as Record<string, any>

      statusCode = exception.getStatus()
      message = exceptionResponse.message || message
      errorCode = exceptionResponse.errorCode || ErrorCode.INTERNAL_SERVER_ERROR

      if (exceptionResponse.errors && typeof exceptionResponse.errors === 'object') {
        errors = exceptionResponse.errors as Record<string, string[]>
      }
    } else if (exception instanceof HttpException) {
      statusCode = exception.getStatus()
      const exceptionResponse = exception.getResponse()

      if (typeof exceptionResponse === 'string') {
        message = exceptionResponse
      } else if (typeof exceptionResponse === 'object' && exceptionResponse !== null) {
        const responseData = exceptionResponse as Record<string, any>

        if (Array.isArray(responseData.errors)) {
          message = 'Validation failed'
          errors = responseData.errors.reduce((acc: Record<string, string[]>, error: any) => {
            const field = error.path?.join('.') || 'unknown'

            if (!acc[field]) {
              acc[field] = []
            }

            acc[field].push(error.message)

            return acc
          }, {})

          errorCode = ErrorCode.VALIDATION_ERROR
        } else {
          message = responseData.message || message
          errorCode = ErrorCode.BAD_REQUEST
        }
      }
    } else if (exception instanceof Error) {
      if (this.configService.getOrThrow('NODE_ENV') === 'development') {
        message = exception.message || message
      }
    }

    const errorResponse: ApiResponse<null> = {
      success: false,
      path: request.originalUrl,
      message,
      timestamp: new Date().toISOString(),
      errorCode,
      errors,
    }

    response.status(statusCode).json(errorResponse)
  }
}
