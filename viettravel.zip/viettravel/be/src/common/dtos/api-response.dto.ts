import { ApiProperty } from '@nestjs/swagger/dist/decorators/api-property.decorator'
import { ErrorCode } from '../errors/errors-code'

export interface ApiResponse<T> {
  success: boolean
  path: string
  message: string
  timestamp: string

  // For success response
  data?: T
  meta?: PaginationMeta

  // For errors response
  errorCode?: ErrorCode
  errors?: Record<string, string[]>
}

export interface PaginationMeta {
  page: number
  limit: number
  total: number
  totalPages: number
}

export class PaginationMetaSchema {
  @ApiProperty()
  page?: number

  @ApiProperty()
  limit?: number

  @ApiProperty()
  total?: number

  @ApiProperty()
  totalPages?: number
}

// This class is used for Swagger documentation and response contract in GlobalResponseInterceptor
export class ApiResponseSchema<T> {
  @ApiProperty()
  success?: boolean

  @ApiProperty()
  path?: string

  @ApiProperty()
  message?: string

  @ApiProperty()
  timestamp?: string

  @ApiProperty({ required: false, description: 'Response payload' })
  data?: T

  @ApiProperty({ required: false, type: PaginationMetaSchema })
  meta?: PaginationMeta

  @ApiProperty({ required: false, description: 'Application error code for failed responses' })
  errorCode?: ErrorCode

  @ApiProperty({ required: false, type: Object, description: 'Validation or business errors keyed by field name' })
  errors?: Record<string, string[]>
}

export class ApiSuccessResponseSchema<T> {
  @ApiProperty()
  success!: boolean

  @ApiProperty()
  path!: string

  @ApiProperty()
  message!: string

  @ApiProperty()
  timestamp!: string
}

export class ApiErrorResponseSchema {
  @ApiProperty()
  success!: boolean

  @ApiProperty()
  path!: string

  @ApiProperty()
  message!: string

  @ApiProperty()
  timestamp!: string

  @ApiProperty({ required: false, description: 'Application error code for failed responses' })
  errorCode!: ErrorCode

  @ApiProperty({ required: false, type: Object, description: 'Validation or business errors keyed by field name' })
  errors!: Record<string, string[]>
}
