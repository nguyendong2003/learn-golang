import { PaginationMeta } from './api-response.dto'

export class PaginatedResult<T> {
  constructor(
    public data: T[],
    public meta: PaginationMeta,
  ) {}
}

export class PaginationHelper {
  static getSkipTake(page: number, limit: number) {
    const pageNumber = Math.max(1, page)
    const limitNumber = Math.max(1, limit)
    const skip = (pageNumber - 1) * limitNumber
    const take = limitNumber
    return { skip, take }
  }

  static getMeta(page: number, limit: number, total: number): PaginationMeta {
    const pageNumber = Math.max(1, page)
    const limitNumber = Math.max(1, limit)

    const totalPages = Math.max(1, Math.ceil(total / limitNumber))
    return { page: pageNumber, limit: limitNumber, total, totalPages }
  }
}
