import { NestFactory, Reflector } from '@nestjs/core'
import { AppModule } from '@/app.module'
import { ConfigService } from '@nestjs/config'
import { GlobalExceptionFilter } from '@/common/filters/exception.filter'
import { buildCorsOptions } from '@/config/cors.config'
import { ZodSerializerInterceptor, ZodValidationPipe, cleanupOpenApiDoc } from 'nestjs-zod'
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger'
import { Env } from '@/config/env.validation'
import { GlobalResponseInterceptor } from '@/common/interceptors/response.interceptor'

async function bootstrap() {
  const app = await NestFactory.create(AppModule)
  const configService = app.get(ConfigService<Env, true>)
  const environment = configService.getOrThrow('NODE_ENV')

  app.setGlobalPrefix('api/v1')

  app.enableCors(
    buildCorsOptions({
      NODE_ENV: configService.getOrThrow('NODE_ENV'),
      FE_URL: configService.getOrThrow('FE_URL'),
      CORS_ORIGINS: configService.getOrThrow('CORS_ORIGINS'),
    }),
  )

  app.useGlobalPipes(new ZodValidationPipe())

  app.useGlobalFilters(new GlobalExceptionFilter(configService))

  app.useGlobalInterceptors(
    new GlobalResponseInterceptor(app.get(Reflector)),
    new ZodSerializerInterceptor(app.get(Reflector)),
  )

  // Swagger setup
  const swaggerConfig = new DocumentBuilder()
    .setTitle('VietTravel API')
    .setDescription('VietTravel marketplace REST API')
    .setVersion('0.0.1')
    .addBearerAuth()
    .build()

  const document = SwaggerModule.createDocument(app, swaggerConfig)

  SwaggerModule.setup('docs', app, cleanupOpenApiDoc(document), {
    swaggerOptions: {
      persistAuthorization: true,
    },
  })

  const port = configService.getOrThrow('PORT')
  await app.listen(port)
  console.log(
    `Server listening on http://localhost:${port}  (Swagger: http://localhost:${port}/docs)  env=${environment}`,
  )
}
bootstrap()
