/* eslint-disable @typescript-eslint/no-unsafe-call, @typescript-eslint/no-unsafe-member-access, @typescript-eslint/no-unsafe-return, @typescript-eslint/no-unsafe-assignment */
import { Injectable } from '@nestjs/common'
import { PrismaClient } from '@/generated/prisma/client'
import { PrismaPg } from '@prisma/adapter-pg'
import { ConfigService } from '@nestjs/config'
import { Env } from '@/config/env.validation'
import { prismaTransactionContext } from './prisma.context'

@Injectable()
export class PrismaService extends PrismaClient {
  constructor(configService: ConfigService<Env, true>) {
    const adapter = new PrismaPg({
      connectionString: configService.getOrThrow('DATABASE_URL'),
    })
    super({ adapter })

    return new Proxy(this, {
      get: (target, property, receiver) => {
        const store = prismaTransactionContext.getStore()
        const activeClient = store?.tx ?? target
        const value = Reflect.get(activeClient, property, receiver)
        return typeof value === 'function' ? value.bind(activeClient) : value
      },
    }) as this
  }
}
