import { AsyncLocalStorage } from 'async_hooks'

export const prismaTransactionContext = new AsyncLocalStorage<any>()
