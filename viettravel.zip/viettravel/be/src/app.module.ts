import { Module } from '@nestjs/common'
import { AppConfigModule } from '@/config/config.module'
import { UsersModule } from '@/modules/user/user.module'
import { PrismaModule } from '@/prisma/prisma.module'
import { CategoryModule } from '@/modules/category/category.module'
import { AgentsModule } from '@/modules/agents/agent.module'
import { AuditModule } from '@/modules/audit/audit.module'
import { AuthModule } from '@/modules/auth/auth.module'
import { APP_GUARD } from '@nestjs/core/constants'
import { JwtAuthGuard } from './common/guards/jwt-auth.guard'
import { PermissionGuard } from './common/guards/permission.guard'
import { InventoryCalendarModule } from './modules/inventory-calendar/inventory-calendar.module'
import { DestinationsModule } from '@/modules/destination/destination.module'
import { TourCategoryModule } from '@/modules/tour-category/tour-category.module'
import { TransportationCategoryModule } from '@/modules/transportation-category/transportation-category.module'
import { TourModule } from '@/modules/tour/tour.module'

@Module({
  imports: [
    AppConfigModule,
    PrismaModule,
    AuthModule,
    UsersModule,
    AgentsModule,
    CategoryModule,
    InventoryCalendarModule,
    AuditModule,
    DestinationsModule,
    TourCategoryModule,
    TransportationCategoryModule,
    TourModule,
  ],
  controllers: [],
  providers: [
    {
      provide: APP_GUARD,
      useClass: JwtAuthGuard,
    },
    {
      provide: APP_GUARD,
      useClass: PermissionGuard,
    },
  ],
})
export class AppModule {}
