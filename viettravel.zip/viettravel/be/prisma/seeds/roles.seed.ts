import { RoleCode } from '@/common/enums/role.enum'
import type { PrismaClient } from '@/generated/prisma/client'

const ROLE_SEEDS = [
  { code: RoleCode.ADMIN, name: 'Administrator', description: 'System administrator' },
  { code: RoleCode.USER, name: 'User', description: 'End user' },
  { code: RoleCode.CONTENT_MODERATOR, name: 'Content Moderator', description: 'Content moderation staff' },
  { code: RoleCode.CUSTOMER_SUPPORT, name: 'Customer Support', description: 'Customer support staff' },
  { code: RoleCode.FINANCE, name: 'Finance', description: 'Finance staff' },
  { code: RoleCode.MARKETING, name: 'Marketing', description: 'Marketing staff' },
]

type RoleSeedClient = Pick<PrismaClient, 'role'>

type SeededRole = {
  id: string
  code: RoleCode
}

export async function seedRoles(prisma: RoleSeedClient): Promise<Array<SeededRole>> {
  const roles: Array<SeededRole> = []

  for (const roleSeed of ROLE_SEEDS) {
    const role = await prisma.role.upsert({
      where: { code: roleSeed.code },
      update: {
        name: roleSeed.name,
        description: roleSeed.description,
      },
      create: {
        name: roleSeed.name,
        code: roleSeed.code,
        description: roleSeed.description,
      },
    })

    roles.push({
      id: role.id,
      code: roleSeed.code,
    })
  }

  return roles
}
