import { PermissionCode } from '@/common/enums/permission.enum'
import { RoleCode } from '@/common/enums/role.enum'
import type { PrismaClient } from '@/generated/prisma/client'

type RolePermissionSeedClient = Pick<PrismaClient, 'rolePermission'>

const ROLE_PERMISSION_SEEDS = [
  // ADMIN: Full access to all resources
  {
    roleCode: RoleCode.ADMIN,
    permissionCodes: Object.values(PermissionCode),
  },

  // USER: Logged-in user with access to browse and book tours/hotels
  {
    roleCode: RoleCode.USER,
    permissionCodes: [
      // Read public resources
      PermissionCode.TOUR_CATEGORY_READ,
      PermissionCode.TOUR_READ,
      PermissionCode.HOTEL_READ,
      PermissionCode.HOTEL_UPDATE,
      PermissionCode.TOUR_UPDATE,
      PermissionCode.BLOG_READ,
      PermissionCode.PROMOTION_READ,
      PermissionCode.VOUCHER_READ,
      PermissionCode.REVIEW_READ,
      // Manage own bookings and payments
      PermissionCode.BOOKING_READ,
      PermissionCode.BOOKING_CREATE,
      PermissionCode.BOOKING_UPDATE,
      PermissionCode.PAYMENT_READ,
      // Manage own profile
      PermissionCode.USER_SELF_READ,
      PermissionCode.USER_SELF_UPDATE,
      PermissionCode.AGENT_REGISTER,
      PermissionCode.AGENT_UPDATE,
      // PermissionCode.AGENT_READ,
      // Write reviews
      PermissionCode.REVIEW_UPDATE,
    ],
  },

  // CONTENT_MODERATOR: Review and moderation permissions
  {
    roleCode: RoleCode.CONTENT_MODERATOR,
    permissionCodes: [
      PermissionCode.USER_READ,
      PermissionCode.REVIEW_READ,
      PermissionCode.REVIEW_UPDATE,
      PermissionCode.REVIEW_DELETE,
      PermissionCode.BLOG_READ,
      PermissionCode.BLOG_UPDATE,
      PermissionCode.BLOG_DELETE,
      PermissionCode.TOUR_READ,
      PermissionCode.HOTEL_READ,
      PermissionCode.PROMOTION_READ,
      PermissionCode.VOUCHER_READ,
      PermissionCode.TOUR_CATEGORY_READ,
      PermissionCode.TOUR_CATEGORY_CREATE,
      PermissionCode.TOUR_CATEGORY_UPDATE,
      PermissionCode.TOUR_CATEGORY_DELETE,
    ],
  },

  // CUSTOMER_SUPPORT: Booking and dispute handling
  {
    roleCode: RoleCode.CUSTOMER_SUPPORT,
    permissionCodes: [
      PermissionCode.USER_READ,
      PermissionCode.USER_UPDATE,
      PermissionCode.BOOKING_READ,
      PermissionCode.BOOKING_UPDATE,
      PermissionCode.PAYMENT_READ,
      PermissionCode.DISPUTE_READ,
      PermissionCode.DISPUTE_UPDATE,
      PermissionCode.TOUR_READ,
      PermissionCode.HOTEL_READ,
      PermissionCode.REVIEW_READ,
    ],
  },

  // FINANCE: Payment and financial operations
  {
    roleCode: RoleCode.FINANCE,
    permissionCodes: [
      PermissionCode.USER_READ,
      PermissionCode.PAYMENT_READ,
      PermissionCode.PAYMENT_UPDATE,
      PermissionCode.BOOKING_READ,
      PermissionCode.AFFILIATE_READ,
      PermissionCode.AFFILIATE_UPDATE,
      PermissionCode.LOYALTY_READ,
      PermissionCode.LOYALTY_UPDATE,
      PermissionCode.DISPUTE_READ,
    ],
  },

  // MARKETING: Promotion and content management
  {
    roleCode: RoleCode.MARKETING,
    permissionCodes: [
      PermissionCode.TOUR_CATEGORY_READ,
      PermissionCode.TOUR_READ,
      PermissionCode.HOTEL_READ,
      PermissionCode.PROMOTION_READ,
      PermissionCode.PROMOTION_CREATE,
      PermissionCode.PROMOTION_UPDATE,
      PermissionCode.PROMOTION_DELETE,
      PermissionCode.VOUCHER_READ,
      PermissionCode.VOUCHER_CREATE,
      PermissionCode.VOUCHER_UPDATE,
      PermissionCode.VOUCHER_DELETE,
      PermissionCode.BLOG_READ,
      PermissionCode.BLOG_CREATE,
      PermissionCode.BLOG_UPDATE,
      PermissionCode.BLOG_DELETE,
      PermissionCode.AGENT_READ,
    ],
  },
]

export async function seedRolePermissions(
  prisma: RolePermissionSeedClient,
  roles: Array<{ id: string; code: RoleCode }>,
  permissions: Array<{ id: string; code: PermissionCode }>,
) {
  await prisma.rolePermission.deleteMany({
    where: {
      roleId: {
        in: roles.map((role) => role.id),
      },
    },
  })

  await prisma.rolePermission.createMany({
    data: ROLE_PERMISSION_SEEDS.flatMap((seed) => {
      const role = roles.find((currentRole) => currentRole.code === seed.roleCode)

      if (!role) {
        return []
      }

      return seed.permissionCodes
        .map((code) => permissions.find((permission) => permission.code === code))
        .filter((permission): permission is (typeof permissions)[number] => Boolean(permission))
        .map((permission) => ({
          roleId: role.id,
          permissionId: permission.id,
        }))
    }),
    skipDuplicates: true,
  })
}
