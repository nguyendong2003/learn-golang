import type { PrismaClient } from '@/generated/prisma/client'
import { AgentStatusEnum } from '@/generated/prisma/enums'

type TourSeedClient = Pick<
  PrismaClient,
  | 'user'
  | 'agent'
  | 'tour'
  | 'destination'
  | 'tourCategory'
  | 'transportationCategory'
  | 'tourCategoryRelation'
  | 'tourTransportation'
  | 'tourDestination'
>

type TourSeed = {
  ownerUsername: string
  agentCode: string
  taxCode: string
  code: string
  name: string
  departureSlug: string
  durationDays: number
  durationNights: number
  minGuests: number
  maxGuests: number
  description: string
  highlights: string[]
  inclusions: string[]
  exclusions: string[]
  importantNote?: string | null
  cancellationPolicy: string
  videoUrl?: string | null
  brochurePdfUrl?: string | null
  status?: 'DRAFT' | 'PENDING_REVIEW' | 'APPROVED' | 'PUBLISHED' | 'REJECTED' | 'PAUSED' | 'ARCHIVED'
  tourCategorySlugs: string[]
  transportationCategorySlugs: string[]
  destinationSlugs: string[]
}

const TOUR_SEEDS: TourSeed[] = [
  {
    ownerUsername: 'user1',
    agentCode: 'AG-202605-00001',
    taxCode: '0100000001',
    code: 'TOUR-HN-01',
    name: 'Hà Nội - Phố cổ - Hồ Gươm 1 ngày',
    departureSlug: 'ha-noi',
    durationDays: 1,
    durationNights: 0,
    minGuests: 2,
    maxGuests: 20,
    description:
      'Tour city tour Hà Nội kết hợp tham quan phố cổ, Hồ Gươm và các điểm biểu tượng trong trung tâm thủ đô.',
    highlights: ['Khám phá phố cổ Hà Nội', 'Check-in Hồ Gươm', 'Ẩm thực đường phố đặc trưng'],
    inclusions: ['Xe đưa đón', 'Hướng dẫn viên', 'Nước uống', 'Vé tham quan theo chương trình'],
    exclusions: ['Chi phí cá nhân', 'VAT', 'Tip cho hướng dẫn viên'],
    importantNote: 'Chương trình có thể thay đổi theo tình hình thời tiết và giao thông thực tế.',
    cancellationPolicy: 'Hủy trước 3 ngày hoàn 80%, hủy trước 1 ngày hoàn 50%, hủy trong ngày không hoàn tiền.',
    videoUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
    brochurePdfUrl: 'https://example.com/brochures/ha-noi-pho-co-ho-guom.pdf',
    status: 'PUBLISHED',
    tourCategorySlugs: ['tour-ngay', 'tour-van-hoa'],
    transportationCategorySlugs: ['xe-khach'],
    destinationSlugs: ['pho-co-ha-noi', 'ho-guom'],
  },
  {
    ownerUsername: 'user1',
    agentCode: 'AG-202605-00001',
    taxCode: '0100000001',
    code: 'TOUR-DN-02',
    name: 'Đà Nẵng - Bà Nà Hills - Biển Mỹ Khê 2 ngày 1 đêm',
    departureSlug: 'da-nang',
    durationDays: 2,
    durationNights: 1,
    minGuests: 2,
    maxGuests: 25,
    description:
      'Tour nghỉ dưỡng ngắn ngày tại Đà Nẵng với Bà Nà Hills, biển Mỹ Khê và lịch trình linh hoạt cho gia đình.',
    highlights: ['Cầu Vàng Bà Nà Hills', 'Biển Mỹ Khê', 'Ẩm thực hải sản Đà Nẵng'],
    inclusions: ['Xe đưa đón', '1 đêm khách sạn', 'Hướng dẫn viên', 'Vé cáp treo'],
    exclusions: ['Chi phí cá nhân', 'VAT', 'Các dịch vụ ngoài chương trình'],
    cancellationPolicy: 'Hủy trước 5 ngày hoàn 90%, hủy trước 2 ngày hoàn 50%, sau đó không hoàn tiền.',
    status: 'APPROVED',
    tourCategorySlugs: ['tour-ngay', 'tour-nghi-duong'],
    transportationCategorySlugs: ['xe-limousine', 'xe-khach'],
    destinationSlugs: ['ba-na-hills', 'bien-my-khe'],
  },
]

async function ensureAgent(prisma: TourSeedClient, seed: TourSeed) {
  const user = await prisma.user.findFirst({
    where: { username: seed.ownerUsername, deletedAt: null },
    select: { id: true },
  })

  if (!user) {
    throw new Error(`Owner user not found for tour seed ${seed.code}`)
  }

  return prisma.agent.upsert({
    where: { userId: user.id },
    update: {
      agentCode: seed.agentCode,
      taxCode: seed.taxCode,
      status: AgentStatusEnum.ACTIVE,
    },
    create: {
      userId: user.id,
      agentCode: seed.agentCode,
      taxCode: seed.taxCode,
      status: AgentStatusEnum.ACTIVE,
    },
  })
}

import { seedTourCategoryRelations } from './tour-category-relations.seed'
import { seedTourTransportations } from './tour-transportations.seed'
import { seedTourDestinations } from './tour-destinations.seed'

export async function seedTours(
  prisma: TourSeedClient,
  tourCategories: Array<Awaited<ReturnType<typeof prisma.tourCategory.upsert>>>,
  transportationCategories: Array<Awaited<ReturnType<typeof prisma.transportationCategory.upsert>>>,
  destinations: Array<Awaited<ReturnType<typeof prisma.destination.upsert>>>,
) {
  const createdTours: Array<Awaited<ReturnType<typeof prisma.tour.upsert>>> = []

  for (const seed of TOUR_SEEDS) {
    const agent = await ensureAgent(prisma, seed)

    const departure = destinations.find((d) => d.slug === seed.departureSlug)
    if (!departure) throw new Error(`Departure destination not found for tour seed ${seed.code}`)

    const tourCategoryIds = tourCategories.filter((c) => seed.tourCategorySlugs.includes(c.slug)).map((c) => c.id)
    const transportationCategoryIds = transportationCategories
      .filter((c) => seed.transportationCategorySlugs.includes(c.slug))
      .map((c) => c.id)
    const destinationIds = destinations.filter((d) => seed.destinationSlugs.includes(d.slug)).map((d) => d.id)

    // Upsert tour by `code` (simpler than separate find/create)
    const tour = await prisma.tour.upsert({
      where: { code: seed.code },
      update: {
        agentId: agent.id,
        name: seed.name,
        departureId: departure.id,
        durationDays: seed.durationDays,
        durationNights: seed.durationNights,
        minGuests: seed.minGuests,
        maxGuests: seed.maxGuests,
        description: seed.description,
        highlights: seed.highlights,
        inclusions: seed.inclusions,
        exclusions: seed.exclusions,
        importantNote: seed.importantNote ?? null,
        cancellationPolicy: seed.cancellationPolicy,
        videoUrl: seed.videoUrl ?? null,
        brochurePdfUrl: seed.brochurePdfUrl ?? null,
        status: seed.status ?? 'DRAFT',
      },
      create: {
        agentId: agent.id,
        code: seed.code,
        name: seed.name,
        departureId: departure.id,
        durationDays: seed.durationDays,
        durationNights: seed.durationNights,
        minGuests: seed.minGuests,
        maxGuests: seed.maxGuests,
        description: seed.description,
        highlights: seed.highlights,
        inclusions: seed.inclusions,
        exclusions: seed.exclusions,
        importantNote: seed.importantNote ?? null,
        cancellationPolicy: seed.cancellationPolicy,
        videoUrl: seed.videoUrl ?? null,
        brochurePdfUrl: seed.brochurePdfUrl ?? null,
        status: seed.status ?? 'DRAFT',
      },
    })

    await seedTourCategoryRelations(prisma, tour.id, tourCategoryIds)
    await seedTourTransportations(prisma, tour.id, transportationCategoryIds)
    await seedTourDestinations(prisma, tour.id, destinationIds)

    createdTours.push(tour)
  }

  return createdTours
}
