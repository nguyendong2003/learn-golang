export async function seedCategories(tx: any) {
  await tx.tourCategory.createMany({
    data: [
      { name: 'Tour ngày', slug: 'tour-ngay', sortOrder: 1 },
      { name: 'Tour dài ngày', slug: 'tour-dai-ngay', sortOrder: 2 },
      { name: 'Tour biển đảo', slug: 'tour-bien-dao', sortOrder: 3 },
      { name: 'Tour mạo hiểm', slug: 'tour-mao-hiem', sortOrder: 4 },
      { name: 'Tour nghỉ dưỡng', slug: 'tour-nghi-duong', sortOrder: 5 },
      { name: 'Tour văn hóa', slug: 'tour-van-hoa', sortOrder: 6 },
      { name: 'Tour ẩm thực', slug: 'tour-am-thuc', sortOrder: 7 },
      { name: 'Tour caravan', slug: 'tour-caravan', sortOrder: 8 },
    ],
    skipDuplicates: true,
  })

  await tx.hotelCategory.createMany({
    data: [
      { name: 'Hotel', slug: 'hotel', sortOrder: 1 },
      { name: 'Resort', slug: 'resort', sortOrder: 2 },
      { name: 'Homestay', slug: 'homestay', sortOrder: 3 },
      { name: 'Villa', slug: 'villa', sortOrder: 4 },
      { name: 'Hostel', slug: 'hostel', sortOrder: 5 },
      { name: 'Căn hộ dịch vụ', slug: 'can-ho-dich-vu', sortOrder: 6 },
      { name: 'Bungalow', slug: 'bungalow', sortOrder: 7 },
    ],
    skipDuplicates: true,
  })

  await tx.starRatingCategory.createMany({
    data: [
      { name: '1 sao', slug: '1-sao', starNumber: 1 },
      { name: '2 sao', slug: '2-sao', starNumber: 2 },
      { name: '3 sao', slug: '3-sao', starNumber: 3 },
      { name: '4 sao', slug: '4-sao', starNumber: 4 },
      { name: '5 sao', slug: '5-sao', starNumber: 5 },
    ],
    skipDuplicates: true,
  })

  await tx.bedCategory.createMany({
    data: [
      { name: 'Giường đơn', code: 'SINGLE', capacity: 1 },
      { name: 'Giường đôi', code: 'DOUBLE', capacity: 2 },
      { name: 'Giường Twin', code: 'TWIN', capacity: 2 },
      { name: 'Giường King', code: 'KING', capacity: 2 },
      { name: 'Giường Queen', code: 'QUEEN', capacity: 2 },
      { name: 'Giường tầng', code: 'BUNK_BED', capacity: 2 },
    ],
    skipDuplicates: true,
  })

  await tx.transportationCategory.createMany({
    data: [
      { name: 'Xe khách', slug: 'xe-khach', sortOrder: 1 },
      { name: 'Xe limousine', slug: 'xe-limousine', sortOrder: 2 },
      { name: 'Tàu hỏa', slug: 'tau-hoa', sortOrder: 3 },
      { name: 'Máy bay', slug: 'may-bay', sortOrder: 4 },
      { name: 'Tàu thủy', slug: 'tau-thuy', sortOrder: 5 },
      { name: 'Xe máy', slug: 'xe-may', sortOrder: 6 },
    ],
    skipDuplicates: true,
  })

  await tx.mealCategory.createMany({
    data: [
      { name: 'Bữa sáng', slug: 'bua-sang', sortOrder: 1 },
      { name: 'Bữa trưa', slug: 'bua-trua', sortOrder: 2 },
      { name: 'Bữa tối', slug: 'bua-toi', sortOrder: 3 },
      { name: 'Buffet', slug: 'buffet', sortOrder: 4 },
      { name: 'Set menu', slug: 'set-menu', sortOrder: 5 },
    ],
    skipDuplicates: true,
  })
}
