import type { PrismaClient } from '@/generated/prisma/client'

type TransportationCategorySeedClient = Pick<PrismaClient, 'transportationCategory'>

const TRANSPORTATION_CATEGORY_SEEDS = [
  { name: 'Xe khách', slug: 'xe-khach', sortOrder: 1 },
  { name: 'Xe riêng', slug: 'xe-rieng', sortOrder: 2 },
  { name: 'Xe limousine', slug: 'xe-limousine', sortOrder: 3 },
  { name: 'Máy bay', slug: 'may-bay', sortOrder: 4 },
  { name: 'Tàu hỏa', slug: 'tau-hoa', sortOrder: 5 },
  { name: 'Tàu biển', slug: 'tau-bien', sortOrder: 6 },
]

export async function seedTransportationCategories(prisma: TransportationCategorySeedClient) {
  const created: Array<Awaited<ReturnType<typeof prisma.transportationCategory.upsert>>> = []

  for (const seed of TRANSPORTATION_CATEGORY_SEEDS) {
    const record = await prisma.transportationCategory.upsert({
      where: { slug: seed.slug },
      update: { name: seed.name, sortOrder: seed.sortOrder },
      create: { name: seed.name, slug: seed.slug, sortOrder: seed.sortOrder },
    })

    created.push(record)
  }

  return created
}
