import type { PrismaClient } from '@/generated/prisma/client'
import * as bcrypt from 'bcrypt'

type UserSeedClient = Pick<PrismaClient, 'user'>

const USER_SEEDS = [
  // Admins
  { email: 'admin1@gmail.com', username: 'admin1', name: 'Admin One' },
  { email: 'admin2@gmail.com', username: 'admin2', name: 'Admin Two' },
  { email: 'admin3@gmail.com', username: 'admin3', name: 'Admin Three' },
  { email: 'admin4@gmail.com', username: 'admin4', name: 'Admin Four' },
  { email: 'admin5@gmail.com', username: 'admin5', name: 'Admin Five' },

  // Users
  { email: 'user1@gmail.com', username: 'user1', name: 'User One' },
  { email: 'user2@gmail.com', username: 'user2', name: 'User Two' },
  { email: 'user3@gmail.com', username: 'user3', name: 'User Three' },
  { email: 'user4@gmail.com', username: 'user4', name: 'User Four' },
  { email: 'user5@gmail.com', username: 'user5', name: 'User Five' },

  // Moderators
  { email: 'moderator1@gmail.com', username: 'moderator1', name: 'Moderator One' },
  { email: 'moderator2@gmail.com', username: 'moderator2', name: 'Moderator Two' },
  { email: 'moderator3@gmail.com', username: 'moderator3', name: 'Moderator Three' },
  { email: 'moderator4@gmail.com', username: 'moderator4', name: 'Moderator Four' },
  { email: 'moderator5@gmail.com', username: 'moderator5', name: 'Moderator Five' },

  // Supports
  { email: 'support1@gmail.com', username: 'support1', name: 'Support One' },
  { email: 'support2@gmail.com', username: 'support2', name: 'Support Two' },
  { email: 'support3@gmail.com', username: 'support3', name: 'Support Three' },
  { email: 'support4@gmail.com', username: 'support4', name: 'Support Four' },
  { email: 'support5@gmail.com', username: 'support5', name: 'Support Five' },

  // Finances
  { email: 'finance1@gmail.com', username: 'finance1', name: 'Finance One' },
  { email: 'finance2@gmail.com', username: 'finance2', name: 'Finance Two' },
  { email: 'finance3@gmail.com', username: 'finance3', name: 'Finance Three' },
  { email: 'finance4@gmail.com', username: 'finance4', name: 'Finance Four' },
  { email: 'finance5@gmail.com', username: 'finance5', name: 'Finance Five' },

  // Marketings
  { email: 'marketing1@gmail.com', username: 'marketing1', name: 'Marketing One' },
  { email: 'marketing2@gmail.com', username: 'marketing2', name: 'Marketing Two' },
  { email: 'marketing3@gmail.com', username: 'marketing3', name: 'Marketing Three' },
  { email: 'marketing4@gmail.com', username: 'marketing4', name: 'Marketing Four' },
  { email: 'marketing5@gmail.com', username: 'marketing5', name: 'Marketing Five' },
]

export async function seedUsers(prisma: UserSeedClient) {
  const users: Array<Awaited<ReturnType<typeof prisma.user.upsert>>> = []

  for (const userSeed of USER_SEEDS) {
    const user = await prisma.user.upsert({
      where: {
        email: userSeed.email,
      },
      update: {
        username: userSeed.username,
        name: userSeed.name,
        password: bcrypt.hashSync('123456', 10),
      },
      create: {
        email: userSeed.email,
        username: userSeed.username,
        password: bcrypt.hashSync('123456', 10),
        name: userSeed.name,
      },
    })

    users.push(user)
  }

  return users
}
