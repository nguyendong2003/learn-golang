import { PermissionCode } from '@/common/enums/permission.enum'
import type { PrismaClient } from '@/generated/prisma/client'

const PERMISSION_SEEDS: Array<{ code: PermissionCode; name: string; description: string }> = [
  // User Management
  { code: PermissionCode.USER_READ, name: 'Read Users', description: 'View user records' },
  { code: PermissionCode.USER_CREATE, name: 'Create Users', description: 'Create new user records' },
  { code: PermissionCode.USER_UPDATE, name: 'Update Users', description: 'Update existing user records' },
  { code: PermissionCode.USER_DELETE, name: 'Delete Users', description: 'Soft delete user records' },
  // Self Management
  { code: PermissionCode.USER_SELF_READ, name: 'Read Own Information', description: 'View own information record' },
  {
    code: PermissionCode.USER_SELF_UPDATE,
    name: 'Update Own Information',
    description: 'Update own information record',
  },

  // Role Management
  { code: PermissionCode.ROLE_READ, name: 'Read Roles', description: 'View role records' },
  { code: PermissionCode.ROLE_CREATE, name: 'Create Roles', description: 'Create new role records' },
  { code: PermissionCode.ROLE_UPDATE, name: 'Update Roles', description: 'Update existing role records' },
  { code: PermissionCode.ROLE_DELETE, name: 'Delete Roles', description: 'Soft delete role records' },

  // Agent Management
  { code: PermissionCode.AGENT_READ, name: 'Read Agents', description: 'View agent records' },
  { code: PermissionCode.AGENT_CREATE, name: 'Create Agents', description: 'Create new agent records' },
  { code: PermissionCode.AGENT_REGISTER, name: 'Register Agents', description: 'Register new agent accounts' },
  { code: PermissionCode.AGENT_UPDATE, name: 'Update Agents', description: 'Update existing agent records' },
  { code: PermissionCode.AGENT_DELETE, name: 'Delete Agents', description: 'Soft delete agent records' },

  // Destination Management
  { code: PermissionCode.DESTINATION_READ, name: 'Read Destinations', description: 'View destination records' },
  {
    code: PermissionCode.DESTINATION_CREATE,
    name: 'Create Destinations',
    description: 'Create new destination records',
  },
  {
    code: PermissionCode.DESTINATION_UPDATE,
    name: 'Update Destinations',
    description: 'Update existing destination records',
  },
  {
    code: PermissionCode.DESTINATION_DELETE,
    name: 'Delete Destinations',
    description: 'Soft delete destination records',
  },

  // Tour Category Management
  {
    code: PermissionCode.TOUR_CATEGORY_READ,
    name: 'Read Tour Categories',
    description: 'View tour category records',
  },
  {
    code: PermissionCode.TOUR_CATEGORY_CREATE,
    name: 'Create Tour Categories',
    description: 'Create new tour category records',
  },
  {
    code: PermissionCode.TOUR_CATEGORY_UPDATE,
    name: 'Update Tour Categories',
    description: 'Update existing tour category records',
  },
  {
    code: PermissionCode.TOUR_CATEGORY_DELETE,
    name: 'Delete Tour Categories',
    description: 'Soft delete tour category records',
  },

  // Transportation Category Management
  {
    code: PermissionCode.TRANSPORTATION_CATEGORY_READ,
    name: 'Read Transportation Categories',
    description: 'View transportation category records',
  },
  {
    code: PermissionCode.TRANSPORTATION_CATEGORY_CREATE,
    name: 'Create Transportation Categories',
    description: 'Create new transportation category records',
  },
  {
    code: PermissionCode.TRANSPORTATION_CATEGORY_UPDATE,
    name: 'Update Transportation Categories',
    description: 'Update existing transportation category records',
  },
  {
    code: PermissionCode.TRANSPORTATION_CATEGORY_DELETE,
    name: 'Delete Transportation Categories',
    description: 'Soft delete transportation category records',
  },

  // Tour Management
  { code: PermissionCode.TOUR_READ, name: 'Read Tours', description: 'View tour records' },
  { code: PermissionCode.TOUR_CREATE, name: 'Create Tours', description: 'Create new tour records' },
  { code: PermissionCode.TOUR_UPDATE, name: 'Update Tours', description: 'Update existing tour records' },
  { code: PermissionCode.TOUR_DELETE, name: 'Delete Tours', description: 'Soft delete tour records' },

  // Hotel Management
  { code: PermissionCode.HOTEL_READ, name: 'Read Hotels', description: 'View hotel records' },
  { code: PermissionCode.HOTEL_CREATE, name: 'Create Hotels', description: 'Create new hotel records' },
  { code: PermissionCode.HOTEL_UPDATE, name: 'Update Hotels', description: 'Update existing hotel records' },
  { code: PermissionCode.HOTEL_DELETE, name: 'Delete Hotels', description: 'Soft delete hotel records' },

  // Booking Management
  { code: PermissionCode.BOOKING_READ, name: 'Read Bookings', description: 'View booking records' },
  { code: PermissionCode.BOOKING_CREATE, name: 'Create Bookings', description: 'Create new booking records' },
  { code: PermissionCode.BOOKING_UPDATE, name: 'Update Bookings', description: 'Update existing booking records' },
  { code: PermissionCode.BOOKING_DELETE, name: 'Delete Bookings', description: 'Soft delete booking records' },

  // Payment Management
  { code: PermissionCode.PAYMENT_READ, name: 'Read Payments', description: 'View payment records' },
  { code: PermissionCode.PAYMENT_UPDATE, name: 'Update Payments', description: 'Update payment status and details' },

  // Review Management
  { code: PermissionCode.REVIEW_READ, name: 'Read Reviews', description: 'View review records' },
  { code: PermissionCode.REVIEW_UPDATE, name: 'Moderate Reviews', description: 'Approve, reject, or flag reviews' },
  { code: PermissionCode.REVIEW_DELETE, name: 'Delete Reviews', description: 'Soft delete review records' },

  // Promotion Management
  { code: PermissionCode.PROMOTION_READ, name: 'Read Promotions', description: 'View promotion records' },
  { code: PermissionCode.PROMOTION_CREATE, name: 'Create Promotions', description: 'Create new promotion records' },
  {
    code: PermissionCode.PROMOTION_UPDATE,
    name: 'Update Promotions',
    description: 'Update existing promotion records',
  },
  { code: PermissionCode.PROMOTION_DELETE, name: 'Delete Promotions', description: 'Soft delete promotion records' },

  // Voucher Management
  { code: PermissionCode.VOUCHER_READ, name: 'Read Vouchers', description: 'View voucher records' },
  { code: PermissionCode.VOUCHER_CREATE, name: 'Create Vouchers', description: 'Create new voucher records' },
  { code: PermissionCode.VOUCHER_UPDATE, name: 'Update Vouchers', description: 'Update existing voucher records' },
  { code: PermissionCode.VOUCHER_DELETE, name: 'Delete Vouchers', description: 'Soft delete voucher records' },

  // Blog/Content Management
  { code: PermissionCode.BLOG_READ, name: 'Read Blogs', description: 'View blog/content records' },
  { code: PermissionCode.BLOG_CREATE, name: 'Create Blogs', description: 'Create new blog/content records' },
  { code: PermissionCode.BLOG_UPDATE, name: 'Update Blogs', description: 'Update existing blog/content records' },
  { code: PermissionCode.BLOG_DELETE, name: 'Delete Blogs', description: 'Soft delete blog/content records' },

  // Dispute Management
  { code: PermissionCode.DISPUTE_READ, name: 'Read Disputes', description: 'View dispute/ticket records' },
  { code: PermissionCode.DISPUTE_UPDATE, name: 'Handle Disputes', description: 'Update dispute status and decisions' },

  // Affiliate Management
  { code: PermissionCode.AFFILIATE_READ, name: 'Read Affiliates', description: 'View affiliate records' },
  { code: PermissionCode.AFFILIATE_UPDATE, name: 'Update Affiliates', description: 'Update affiliate records' },
  { code: PermissionCode.AFFILIATE_DELETE, name: 'Delete Affiliates', description: 'Soft delete affiliate records' },

  // Loyalty & Points
  { code: PermissionCode.LOYALTY_READ, name: 'Read Loyalty', description: 'View loyalty and points records' },
  { code: PermissionCode.LOYALTY_UPDATE, name: 'Update Loyalty', description: 'Update loyalty profiles and points' },
]

type PermissionSeedClient = Pick<PrismaClient, 'permission'>

type SeededPermission = {
  id: string
  code: PermissionCode
}

export async function seedPermissions(prisma: PermissionSeedClient): Promise<Array<SeededPermission>> {
  const permissions: Array<SeededPermission> = []

  for (const permissionSeed of PERMISSION_SEEDS) {
    const permission = await prisma.permission.upsert({
      where: { code: permissionSeed.code },
      update: {
        name: permissionSeed.name,
        description: permissionSeed.description,
      },
      create: permissionSeed,
    })

    permissions.push({
      id: permission.id,
      code: permissionSeed.code,
    })
  }

  return permissions
}
