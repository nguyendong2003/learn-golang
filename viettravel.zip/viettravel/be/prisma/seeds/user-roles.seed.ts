import { RoleCode } from '@/common/enums/role.enum'
import type { PrismaClient } from '@/generated/prisma/client'

type SeedUserRole = {
  roleCode: RoleCode
  userEmails: Array<string>
}

type UserRoleSeedClient = Pick<PrismaClient, 'userRole'>

const USER_ROLE_SEEDS: Array<SeedUserRole> = [
  { roleCode: RoleCode.ADMIN, userEmails: ['admin1@gmail.com', 'admin2@gmail.com', 'admin3@gmail.com'] },
  { roleCode: RoleCode.USER, userEmails: ['user1@gmail.com', 'user2@gmail.com', 'user3@gmail.com'] },
  { roleCode: RoleCode.CONTENT_MODERATOR, userEmails: ['moderator1@gmail.com', 'moderator2@gmail.com'] },
  { roleCode: RoleCode.CUSTOMER_SUPPORT, userEmails: ['support1@gmail.com', 'support2@gmail.com'] },
  { roleCode: RoleCode.FINANCE, userEmails: ['finance1@gmail.com', 'finance2@gmail.com'] },
  { roleCode: RoleCode.MARKETING, userEmails: ['marketing1@gmail.com', 'marketing2@gmail.com'] },
]

export async function seedUserRoles(
  prisma: UserRoleSeedClient,
  roles: Array<{ id: string; code: RoleCode }>,
  users: Array<{ id: string; email: string }>,
) {
  await prisma.userRole.deleteMany({
    where: {
      userId: {
        in: users.map((user) => user.id),
      },
    },
  })

  await prisma.userRole.createMany({
    data: USER_ROLE_SEEDS.flatMap((seed) => {
      const role = roles.find((currentRole) => currentRole.code === seed.roleCode)

      if (!role) {
        return []
      }

      return seed.userEmails
        .map((email) => users.find((currentUser) => currentUser.email === email))
        .filter((user): user is (typeof users)[number] => Boolean(user))
        .map((user) => ({
          userId: user.id,
          roleId: role.id,
        }))
    }),
    skipDuplicates: true,
  })
}
