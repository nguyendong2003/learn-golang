import type { PrismaClient } from '@/generated/prisma/client'

type PivotClient = Pick<PrismaClient, 'tourTransportation'>

export async function seedTourTransportations(
  prisma: PivotClient,
  tourId: string,
  transportationCategoryIds: string[],
) {
  await prisma.tourTransportation.deleteMany({ where: { tourId } })

  if (transportationCategoryIds.length === 0) return

  await prisma.tourTransportation.createMany({
    data: transportationCategoryIds.map((transportationCategoryId) => ({
      tourId,
      transportationCategoryId,
    })),
  })
}
