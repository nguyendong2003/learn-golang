import type { PrismaClient } from '@/generated/prisma/client'

type TourCategorySeedClient = Pick<PrismaClient, 'tourCategory'>

const TOUR_CATEGORY_SEEDS = [
  { name: 'Tour ngày', slug: 'tour-ngay', sortOrder: 1 },
  { name: 'Tour dài ngày', slug: 'tour-dai-ngay', sortOrder: 2 },
  { name: 'Tour biển đảo', slug: 'tour-bien-dao', sortOrder: 3 },
  { name: 'Tour mạo hiểm', slug: 'tour-mao-hiem', sortOrder: 4 },
  { name: 'Tour nghỉ dưỡng', slug: 'tour-nghi-duong', sortOrder: 5 },
  { name: 'Tour văn hóa', slug: 'tour-van-hoa', sortOrder: 6 },
  { name: 'Tour ẩm thực', slug: 'tour-am-thuc', sortOrder: 7 },
  { name: 'Tour caravan', slug: 'tour-caravan', sortOrder: 8 },
]

export async function seedTourCategories(prisma: TourCategorySeedClient) {
  const created: Array<Awaited<ReturnType<typeof prisma.tourCategory.upsert>>> = []

  for (const seed of TOUR_CATEGORY_SEEDS) {
    const record = await prisma.tourCategory.upsert({
      where: { slug: seed.slug },
      update: { name: seed.name, sortOrder: seed.sortOrder },
      create: { name: seed.name, slug: seed.slug, sortOrder: seed.sortOrder },
    })

    created.push(record)
  }

  return created
}
