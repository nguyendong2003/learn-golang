import { DestinationLevelEnum } from '@/generated/prisma/enums'
import type { PrismaClient } from '@/generated/prisma/client'

type DestinationSeedClient = Pick<PrismaClient, 'destination'>

type DestinationSeed = {
  name: string
  level: DestinationLevelEnum
  slug: string
  administrativeCode?: string | null
  description?: string | null
  imageUrl?: string | null
  lat?: number | null
  lng?: number | null
  isFeatured: boolean
  parentSlug?: string | null
}

const DESTINATION_SEEDS: Array<DestinationSeed> = [
  // ==========================================
  // LEVEL 1: PROVINCES (Tỉnh / Thành phố trực thuộc TW)
  // Có mã hành chính 2 chữ số
  // ==========================================
  {
    name: 'Hà Nội',
    level: DestinationLevelEnum.PROVINCE,
    slug: 'ha-noi',
    administrativeCode: '01',
    description: 'Thủ đô của Việt Nam, trung tâm văn hóa và lịch sử lâu đời.',
    imageUrl: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&w=1200&q=80',
    lat: 21.0278,
    lng: 105.8342,
    isFeatured: true,
  },
  {
    name: 'Đà Nẵng',
    level: DestinationLevelEnum.PROVINCE,
    slug: 'da-nang',
    administrativeCode: '48',
    description: 'Thành phố biển hiện đại, cửa ngõ du lịch của miền Trung.',
    imageUrl: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?auto=format&fit=crop&w=1200&q=80',
    lat: 16.0544,
    lng: 108.2022,
    isFeatured: true,
  },
  {
    name: 'Hồ Chí Minh',
    level: DestinationLevelEnum.PROVINCE,
    slug: 'ho-chi-minh',
    administrativeCode: '79',
    description: 'Thành phố lớn nhất Việt Nam, trung tâm kinh tế và du lịch của miền Nam.',
    imageUrl: 'https://images.unsplash.com/photo-1498855926480-d98e83099315?auto=format&fit=crop&w=1200&q=80',
    lat: 10.7769,
    lng: 106.7009,
    isFeatured: true,
  },
  {
    name: 'Kiên Giang',
    level: DestinationLevelEnum.PROVINCE,
    slug: 'kien-giang',
    administrativeCode: '91', // Phú Quốc thuộc tỉnh Kiên Giang
    description: 'Tỉnh ven biển vùng Đồng bằng sông Cửu Long, sở hữu đảo ngọc Phú Quốc.',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    lat: 9.9825,
    lng: 105.1251,
    isFeatured: true,
  },

  // ==========================================
  // LEVEL 2: WARDS / DISTRICTS (Quận / Huyện / Phường)
  // Có mã hành chính cấp quận (3 chữ số) hoặc phường (5 chữ số)
  // ==========================================
  // --- Thuộc Hà Nội ---
  {
    name: 'Quận Hoàn Kiếm',
    level: DestinationLevelEnum.WARD,
    slug: 'quan-hoan-kiem',
    administrativeCode: '001',
    description: 'Quận trung tâm Hà Nội, nơi có Hồ Gươm và khu phố cổ lâu đời.',
    lat: 21.0285,
    lng: 105.8537,
    isFeatured: true,
    parentSlug: 'ha-noi',
  },
  {
    name: 'Quận Tây Hồ',
    level: DestinationLevelEnum.WARD,
    slug: 'quan-tay-ho',
    administrativeCode: '003',
    description: 'Khu vực cảnh quan thoáng đãng nhìn ra Hồ Tây, không gian sống yên bình.',
    lat: 21.0536,
    lng: 105.8315,
    isFeatured: false,
    parentSlug: 'ha-noi',
  },
  // --- Thuộc Đà Nẵng ---
  {
    name: 'Quận Hải Châu',
    level: DestinationLevelEnum.WARD,
    slug: 'quan-hai-chau',
    administrativeCode: '490',
    description: 'Quận trung tâm hành chính, thương mại và dịch vụ sôi động của Đà Nẵng.',
    lat: 16.0619,
    lng: 108.2481,
    isFeatured: true,
    parentSlug: 'da-nang',
  },
  {
    name: 'Huyện Hòa Vang',
    level: DestinationLevelEnum.WARD, // Giả định hệ thống gom Quận/Huyện/Phường chung một cụm hạ tầng du lịch
    slug: 'huyen-hoa-vang',
    administrativeCode: '497',
    description: 'Huyện ngoại thành Đà Nẵng, nơi tập trung nhiều khu du lịch sinh thái và đồi núi.',
    lat: 16.045,
    lng: 107.9962,
    isFeatured: false,
    parentSlug: 'da-nang',
  },
  // --- Thuộc TP. HCM ---
  {
    name: 'Quận 1',
    level: DestinationLevelEnum.WARD,
    slug: 'quan-1',
    administrativeCode: '760',
    description: 'Trung tâm kinh tế sầm uất bậc nhất Sài Gòn, tập trung các công trình kiến trúc Pháp cổ.',
    lat: 10.7769,
    lng: 106.7009,
    isFeatured: true,
    parentSlug: 'ho-chi-minh',
  },
  // --- Thuộc Kiên Giang ---
  {
    name: 'Thành phố Phú Quốc',
    level: DestinationLevelEnum.WARD,
    slug: 'tp-phu-quoc',
    administrativeCode: '618',
    description: 'Thành phố đảo đầu tiên của Việt Nam, thiên đường nghỉ dưỡng nhiệt đới.',
    lat: 10.1946,
    lng: 103.8384,
    isFeatured: true,
    parentSlug: 'kien-giang',
  },

  // ==========================================
  // LEVEL 3: PLACES (Điểm đến du lịch, di tích)
  // KHÔNG CÓ mã hành chính (administrativeCode = null / undefined)
  // ==========================================
  // --- Điểm đến tại Hoàn Kiếm (Hà Nội) ---
  {
    name: 'Phố Cổ Hà Nội',
    level: DestinationLevelEnum.PLACE,
    slug: 'pho-co-ha-noi',
    description: 'Khu phố cổ đặc trưng với cấu trúc 36 phố phường và ẩm thực đường phố.',
    imageUrl: 'https://images.unsplash.com/photo-1524230572899-a752b383584f?auto=format&fit=crop&w=1200&q=80',
    lat: 21.0346,
    lng: 105.8522,
    isFeatured: true,
    parentSlug: 'quan-hoan-kiem',
  },
  {
    name: 'Hồ Gươm',
    level: DestinationLevelEnum.PLACE,
    slug: 'ho-guom',
    description: 'Hồ nước biểu tượng gắn liền với truyền thuyết gươm thần giữa lòng thủ đô.',
    imageUrl: 'https://images.unsplash.com/photo-1533050487297-dae5c6066849?auto=format&fit=crop&w=1200&q=80',
    lat: 21.0285,
    lng: 105.8537,
    isFeatured: true,
    parentSlug: 'quan-hoan-kiem',
  },
  // --- Điểm đến tại Tây Hồ (Hà Nội) ---
  {
    name: 'Hồ Tây',
    level: DestinationLevelEnum.PLACE,
    slug: 'ho-tay',
    description: 'Hồ nước tự nhiên lớn nhất Hà Nội, không gian lãng mạn ngắm hoàng hôn.',
    imageUrl: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?auto=format&fit=crop&w=1200&q=80',
    lat: 21.0563,
    lng: 105.8207,
    isFeatured: true,
    parentSlug: 'quan-tay-ho',
  },
  // --- Điểm đến tại Hòa Vang (Đà Nẵng) ---
  {
    name: 'Bà Nà Hills',
    level: DestinationLevelEnum.PLACE,
    slug: 'ba-na-hills',
    description: 'Khu du lịch trên đỉnh Núi Chúa nổi tiếng với tuyến cáp treo kỷ lục và Cầu Vàng.',
    imageUrl: 'https://images.unsplash.com/photo-1502920917128-1aa500764ce8?auto=format&fit=crop&w=1200&q=80',
    lat: 15.9997,
    lng: 107.9962,
    isFeatured: true,
    parentSlug: 'huyen-hoa-vang',
  },
  // --- Điểm đến tại Hải Châu (Đà Nẵng) ---
  {
    name: 'Biển Mỹ Khê',
    level: DestinationLevelEnum.PLACE,
    slug: 'bien-my-khe',
    description: 'Bãi biển quyến rũ bậc nhất hành tinh với bãi cát mượt mà, sóng ấm quanh năm.',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    lat: 16.0619,
    lng: 108.2481,
    isFeatured: true,
    parentSlug: 'quan-hai-chau',
  },
  // --- Điểm đến tại Quận 1 (TP. HCM) ---
  {
    name: 'Dinh Độc Lập',
    level: DestinationLevelEnum.PLACE,
    slug: 'dinh-doc-lap',
    description: 'Di tích quốc gia đặc biệt, chứng nhân lịch sử ngày giải phóng miền Nam.',
    imageUrl: 'https://images.unsplash.com/photo-1522998066194-20c1d3a81b7d?auto=format&fit=crop&w=1200&q=80',
    lat: 10.7827,
    lng: 106.692,
    isFeatured: true,
    parentSlug: 'quan-1',
  },
  {
    name: 'Chợ Bến Thành',
    level: DestinationLevelEnum.PLACE,
    slug: 'cho-ben-thanh',
    description: 'Ngôi chợ mang tính biểu tượng lâu đời của Sài Gòn, trung tâm giao thương sầm uất.',
    imageUrl: 'https://images.unsplash.com/photo-1519315884de0cc3c9e0e088ca4f76c2?auto=format&fit=crop&w=1200&q=80',
    lat: 10.7725,
    lng: 106.6985,
    isFeatured: true,
    parentSlug: 'quan-1',
  },
  // --- Điểm đến tại TP. Phú Quốc (Kiên Giang) ---
  {
    name: 'Bãi Sao Phú Quốc',
    level: DestinationLevelEnum.PLACE,
    slug: 'bai-sao-phu-quoc',
    description: 'Bãi biển tuyệt đẹp với bờ cát trắng mịn như kem và làn nước trong xanh màu ngọc bích.',
    imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=1200&q=80',
    lat: 10.235,
    lng: 103.995,
    isFeatured: true,
    parentSlug: 'tp-phu-quoc',
  },
]

export async function seedDestinations(prisma: DestinationSeedClient) {
  const destinations: Array<Awaited<ReturnType<typeof prisma.destination.upsert>>> = []
  const destinationMap = new Map<string, string>()

  for (const destinationSeed of DESTINATION_SEEDS) {
    const parentId = destinationSeed.parentSlug ? destinationMap.get(destinationSeed.parentSlug) : null

    const destination = await prisma.destination.upsert({
      where: { slug: destinationSeed.slug },
      update: {
        parentId,
        level: destinationSeed.level,
        name: destinationSeed.name,
        administrativeCode: destinationSeed.administrativeCode ?? null,
        description: destinationSeed.description ?? null,
        imageUrl: destinationSeed.imageUrl ?? null,
        lat: destinationSeed.lat ?? null,
        lng: destinationSeed.lng ?? null,
        isFeatured: destinationSeed.isFeatured,
      },
      create: {
        parentId,
        level: destinationSeed.level,
        name: destinationSeed.name,
        administrativeCode: destinationSeed.administrativeCode ?? null,
        description: destinationSeed.description ?? null,
        imageUrl: destinationSeed.imageUrl ?? null,
        lat: destinationSeed.lat ?? null,
        lng: destinationSeed.lng ?? null,
        slug: destinationSeed.slug,
        isFeatured: destinationSeed.isFeatured,
      },
    })

    destinationMap.set(destinationSeed.slug, destination.id)
    destinations.push(destination)
  }

  return destinations
}
