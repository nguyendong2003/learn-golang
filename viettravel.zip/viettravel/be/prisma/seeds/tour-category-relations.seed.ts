import type { PrismaClient } from '@/generated/prisma/client'

type PivotClient = Pick<PrismaClient, 'tourCategoryRelation'>

export async function seedTourCategoryRelations(prisma: PivotClient, tourId: string, tourCategoryIds: string[]) {
  await prisma.tourCategoryRelation.deleteMany({ where: { tourId } })

  if (tourCategoryIds.length === 0) return

  await prisma.tourCategoryRelation.createMany({
    data: tourCategoryIds.map((tourCategoryId) => ({
      tourId,
      tourCategoryId,
    })),
  })
}
