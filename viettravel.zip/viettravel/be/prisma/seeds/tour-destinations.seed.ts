import type { PrismaClient } from '@/generated/prisma/client'

type PivotClient = Pick<PrismaClient, 'tourDestination'>

export async function seedTourDestinations(prisma: PivotClient, tourId: string, destinationIds: string[]) {
  await prisma.tourDestination.deleteMany({ where: { tourId } })

  if (destinationIds.length === 0) return

  await prisma.tourDestination.createMany({
    data: destinationIds.map((destinationId) => ({
      tourId,
      destinationId,
    })),
  })
}
