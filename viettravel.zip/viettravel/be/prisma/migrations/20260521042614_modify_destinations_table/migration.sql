/*
  Warnings:

  - Made the column `is_featured` on table `destinations` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "destinations_administrative_code_key";

-- AlterTable
ALTER TABLE "destinations" ALTER COLUMN "is_featured" SET NOT NULL;
