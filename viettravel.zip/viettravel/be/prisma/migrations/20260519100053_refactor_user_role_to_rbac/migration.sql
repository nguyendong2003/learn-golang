/*
  Warnings:

  - You are about to drop the column `role_id` on the `users` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[code]` on the table `roles` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `code` to the `roles` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "users" DROP CONSTRAINT "users_role_id_fkey";

-- AlterTable
ALTER TABLE "roles" ADD COLUMN     "code" VARCHAR(100) NOT NULL;

-- AlterTable
ALTER TABLE "users" DROP COLUMN "role_id";

-- CreateIndex
CREATE UNIQUE INDEX "roles_code_key" ON "roles"("code");
