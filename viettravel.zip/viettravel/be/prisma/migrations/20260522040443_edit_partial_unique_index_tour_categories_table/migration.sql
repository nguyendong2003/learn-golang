/*
  Warnings:

  - A unique constraint covering the columns `[name]` on the table `tour_categories` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[slug]` on the table `tour_categories` will be added. If there are existing duplicate values, this will fail.

*/
-- DropIndex
DROP INDEX "tour_categories_name_slug_key";

-- CreateIndex
CREATE UNIQUE INDEX "tour_categories_name_key" ON "tour_categories"("name") WHERE ("deleted_at" IS NULL);

-- CreateIndex
CREATE UNIQUE INDEX "tour_categories_slug_key" ON "tour_categories"("slug") WHERE ("deleted_at" IS NULL);
