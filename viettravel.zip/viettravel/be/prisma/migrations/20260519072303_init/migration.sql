-- CreateEnum
CREATE TYPE "user_status_enum" AS ENUM ('ACTIVE', 'LOCKED', 'DELETED');

-- CreateEnum
CREATE TYPE "agent_status_enum" AS ENUM ('PENDING', 'REVISION_REQUEST', 'ACTIVE', 'SUSPENDED', 'BANNED');

-- CreateEnum
CREATE TYPE "corporate_status_enum" AS ENUM ('PENDING', 'REVISION_REQUEST', 'ACTIVE', 'SUSPENDED', 'BANNED');

-- CreateEnum
CREATE TYPE "destination_level_enum" AS ENUM ('PROVINCE', 'WARD', 'PLACE');

-- CreateEnum
CREATE TYPE "hotel_status_enum" AS ENUM ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'PAUSED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "rate_type_enum" AS ENUM ('SEASONAL', 'WEEKEND', 'HOLIDAY', 'PROMOTIONAL');

-- CreateEnum
CREATE TYPE "tour_status_enum" AS ENUM ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'PAUSED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "departure_status_enum" AS ENUM ('OPEN', 'LOW_AVAILABILITY', 'SOLD_OUT', 'CLOSED');

-- CreateEnum
CREATE TYPE "combo_status_enum" AS ENUM ('DRAFT', 'PENDING_REVIEW', 'APPROVED', 'PUBLISHED', 'REJECTED', 'PAUSED', 'ARCHIVED');

-- CreateEnum
CREATE TYPE "combo_type_enum" AS ENUM ('TOUR_HOTEL', 'HOTEL_FLIGHT', 'TOUR_HOTEL_FLIGHT');

-- CreateEnum
CREATE TYPE "ticket_class_enum" AS ENUM ('ECONOMY', 'BUSINESS');

-- CreateEnum
CREATE TYPE "combo_departure_status_enum" AS ENUM ('OPEN', 'LOW_AVAILABILITY', 'SOLD_OUT', 'CLOSED');

-- CreateEnum
CREATE TYPE "booking_status_enum" AS ENUM ('PENDING_CONFIRMATION', 'CONFIRMED', 'WAITING_PAYMENT', 'PAID', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED_BY_CUSTOMER', 'CANCELLED_BY_AGENT', 'CANCELLED_BY_SYSTEM', 'REFUND_REQUESTED', 'REFUNDED');

-- CreateEnum
CREATE TYPE "product_type_enum" AS ENUM ('HOTEL', 'TOUR', 'COMBO');

-- CreateEnum
CREATE TYPE "passenger_gender_enum" AS ENUM ('MALE', 'FEMALE', 'OTHER');

-- CreateEnum
CREATE TYPE "voucher_discount_type_enum" AS ENUM ('PERCENTAGE', 'FLAT_AMOUNT', 'FREE_SERVICE');

-- CreateEnum
CREATE TYPE "voucher_audience_enum" AS ENUM ('ALL', 'NEW_USER', 'MEMBER_RANK', 'SPECIFIC_ACCOUNTS');

-- CreateEnum
CREATE TYPE "promotion_type_enum" AS ENUM ('PERCENTAGE', 'FLAT_AMOUNT', 'EARLY_BIRD', 'LAST_MINUTE', 'FLASH_SALE', 'MULTI_NIGHT', 'BOGO');

-- CreateEnum
CREATE TYPE "promotion_status_enum" AS ENUM ('DRAFT', 'PENDING_REVIEW', 'ACTIVE', 'REJECTED', 'PAUSED', 'EXPIRED');

-- CreateEnum
CREATE TYPE "moderation_priority_enum" AS ENUM ('LOW', 'MEDIUM', 'HIGH');

-- CreateEnum
CREATE TYPE "moderation_status_enum" AS ENUM ('PENDING', 'UNDER_REVIEW', 'APPROVED', 'REVISION_REQ', 'REJECTED');

-- CreateEnum
CREATE TYPE "review_status_enum" AS ENUM ('PENDING', 'APPROVED', 'REJECTED', 'HIDDEN');

-- CreateEnum
CREATE TYPE "dispute_priority_enum" AS ENUM ('LOW', 'MEDIUM', 'HIGH', 'EMERGENCY');

-- CreateEnum
CREATE TYPE "dispute_status_enum" AS ENUM ('OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED');

-- CreateEnum
CREATE TYPE "dispute_decision_enum" AS ENUM ('REFUND_FULL', 'REFUND_PARTIAL', 'VOUCHER_COMPENSATION', 'REJECTED', 'AGENT_PENALTY');

-- CreateEnum
CREATE TYPE "dispute_sender_type_enum" AS ENUM ('ADMIN', 'CUSTOMER', 'AGENT');

-- CreateEnum
CREATE TYPE "content_status_enum" AS ENUM ('DRAFT', 'SCHEDULED', 'PUBLISHED');

-- CreateEnum
CREATE TYPE "banner_position_enum" AS ENUM ('HOME_HERO_SLIDER', 'SEARCH_SIDEBAR', 'PROMO_POPUP', 'PRODUCT_PAGE', 'FOOTER');

-- CreateEnum
CREATE TYPE "comment_status_enum" AS ENUM ('PENDING', 'APPROVED', 'SPAM');

-- CreateEnum
CREATE TYPE "banner_audience_enum" AS ENUM ('ALL', 'USER', 'MEMBER_RANK');

-- CreateEnum
CREATE TYPE "affiliate_status_enum" AS ENUM ('PENDING', 'ACTIVE', 'REJECTED', 'SUSPENDED');

-- CreateEnum
CREATE TYPE "affiliate_commission_status_enum" AS ENUM ('PENDING', 'HOLDING', 'AVAILABLE', 'WITHDRAWN', 'CANCELLED');

-- CreateEnum
CREATE TYPE "withdrawal_status_enum" AS ENUM ('PENDING', 'APPROVED', 'PAID', 'REJECTED');

-- CreateEnum
CREATE TYPE "membership_tier_enum" AS ENUM ('BRONZE', 'SILVER', 'GOLD', 'PLATINUM');

-- CreateEnum
CREATE TYPE "point_transaction_type_enum" AS ENUM ('EARN', 'REDEEM', 'EXPIRE', 'REFUND');

-- CreateTable
CREATE TABLE "roles" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(100) NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "roles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "permissions" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(100) NOT NULL,
    "code" VARCHAR(100) NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "permissions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "role_id" UUID NOT NULL,
    "email" VARCHAR(255) NOT NULL,
    "username" VARCHAR(255) NOT NULL,
    "password" VARCHAR(255) NOT NULL,
    "name" VARCHAR(255),
    "phone" VARCHAR(20),
    "avatar_url" TEXT,
    "status" "user_status_enum" DEFAULT 'ACTIVE',
    "is_affiliate" BOOLEAN DEFAULT false,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "role_permissions" (
    "role_id" UUID NOT NULL,
    "permission_id" UUID NOT NULL,

    CONSTRAINT "role_permissions_pkey" PRIMARY KEY ("role_id","permission_id")
);

-- CreateTable
CREATE TABLE "user_roles" (
    "user_id" UUID NOT NULL,
    "role_id" UUID NOT NULL,

    CONSTRAINT "user_roles_pkey" PRIMARY KEY ("user_id","role_id")
);

-- CreateTable
CREATE TABLE "agents" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "user_id" UUID NOT NULL,
    "agent_code" VARCHAR(20) NOT NULL,
    "business_name" VARCHAR(255),
    "tax_code" VARCHAR(50) NOT NULL,
    "license_url" TEXT,
    "representative_name" VARCHAR(255),
    "representative_id_number" VARCHAR(20),
    "logo_url" TEXT,
    "cover_url" TEXT,
    "description" TEXT,
    "established_year" INTEGER,
    "company_size" VARCHAR(50),
    "working_hours" VARCHAR(255),
    "website_url" VARCHAR(255),
    "facebook_url" VARCHAR(255),
    "zalo_url" VARCHAR(255),
    "instagram_url" VARCHAR(255),
    "business_address" TEXT,
    "business_phone" VARCHAR(20),
    "support_email" VARCHAR(255),
    "status" "agent_status_enum" DEFAULT 'PENDING',
    "status_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "agents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_activity_fields" (
    "agent_id" UUID NOT NULL,
    "activity_field_id" UUID NOT NULL,

    CONSTRAINT "agent_activity_fields_pkey" PRIMARY KEY ("agent_id","activity_field_id")
);

-- CreateTable
CREATE TABLE "agent_images" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "agent_id" UUID NOT NULL,
    "image_url" TEXT NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "agent_images_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "staff_audit_logs" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "user_id" UUID,
    "action" VARCHAR,
    "ip_address" VARCHAR,
    "user_agent" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "staff_audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "corporates" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "corporate_code" VARCHAR(50) NOT NULL,
    "business_name" VARCHAR(255) NOT NULL,
    "tax_code" VARCHAR(50) NOT NULL,
    "license_url" TEXT,
    "representative_name" VARCHAR(255) NOT NULL,
    "address" TEXT,
    "contact_email" VARCHAR(255) NOT NULL,
    "contact_phone" VARCHAR(20) NOT NULL,
    "status" "corporate_status_enum" DEFAULT 'PENDING',
    "status_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "corporates_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "corporate_employees" (
    "corporate_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "is_approver" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "corporate_employees_pkey" PRIMARY KEY ("corporate_id","user_id")
);

-- CreateTable
CREATE TABLE "corporate_contracts" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "corporate_id" UUID NOT NULL,
    "contract_number" VARCHAR(100) NOT NULL,
    "discount_percent" DECIMAL(5,2) NOT NULL DEFAULT 0,
    "credit_limit" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "used_credit" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "payment_term_days" INTEGER NOT NULL DEFAULT 30,
    "start_date" DATE NOT NULL,
    "end_date" DATE NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "corporate_contracts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "destinations" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "parent_id" UUID,
    "level" "destination_level_enum" NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "administrative_code" VARCHAR(20),
    "description" TEXT,
    "image_url" TEXT,
    "lat" DECIMAL(10,8),
    "lng" DECIMAL(11,8),
    "slug" VARCHAR(255) NOT NULL,
    "is_featured" BOOLEAN DEFAULT false,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "destinations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "activity_field_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "activity_field_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "bed_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(100) NOT NULL,
    "code" VARCHAR(50) NOT NULL,
    "capacity" INTEGER DEFAULT 2,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "bed_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "blog_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "blog_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tour_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "icon_url" TEXT,
    "sort_order" INTEGER DEFAULT 1,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "tour_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "hotel_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "icon_url" TEXT,
    "sort_order" INTEGER DEFAULT 1,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "hotel_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "star_rating_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(50) NOT NULL,
    "star_number" INTEGER NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "star_rating_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "room_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "icon_url" TEXT,
    "sort_order" INTEGER DEFAULT 1,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "room_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "hotel_facility_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "icon_url" TEXT,
    "sort_order" INTEGER DEFAULT 1,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "hotel_facility_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "room_facility_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "icon_url" TEXT,
    "sort_order" INTEGER DEFAULT 1,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "room_facility_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "transportation_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "icon_url" TEXT,
    "sort_order" INTEGER DEFAULT 1,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "transportation_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "meal_categories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "icon_url" TEXT,
    "sort_order" INTEGER DEFAULT 1,
    "is_active" BOOLEAN DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "meal_categories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "hotels" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "agent_id" UUID NOT NULL,
    "destination_id" UUID NOT NULL,
    "hotel_category_id" UUID NOT NULL,
    "star_rating_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "address" TEXT NOT NULL,
    "lat" DECIMAL(10,8) NOT NULL,
    "lng" DECIMAL(11,8) NOT NULL,
    "description" TEXT,
    "video_url" VARCHAR(255),
    "check_in_time" TIME NOT NULL DEFAULT '14:00:00'::time without time zone,
    "check_out_time" TIME NOT NULL DEFAULT '12:00:00'::time without time zone,
    "cancellation_policy" JSONB,
    "child_policy" JSONB,
    "pet_policy" JSONB,
    "languages" JSONB,
    "status" "hotel_status_enum" DEFAULT 'DRAFT',
    "tax_percent" DECIMAL(5,2) NOT NULL DEFAULT 10.00,
    "service_fee_percent" DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "hotels_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "hotel_facilities" (
    "hotel_id" UUID NOT NULL,
    "hotel_facility_category_id" UUID NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "hotel_facilities_pkey" PRIMARY KEY ("hotel_id","hotel_facility_category_id")
);

-- CreateTable
CREATE TABLE "hotel_images" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "hotel_id" UUID,
    "image_url" TEXT NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "hotel_images_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "room_types" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "hotel_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "max_occupancy" INTEGER DEFAULT 2,
    "area" DECIMAL(5,2),
    "total_room" INTEGER NOT NULL,
    "view_room" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "room_types_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "room_facilities" (
    "room_id" UUID NOT NULL,
    "room_facility_category_id" UUID NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "room_facilities_pkey" PRIMARY KEY ("room_id","room_facility_category_id")
);

-- CreateTable
CREATE TABLE "room_type_beds" (
    "room_type_id" UUID NOT NULL,
    "bed_category_id" UUID NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "room_type_beds_pkey" PRIMARY KEY ("room_type_id","bed_category_id")
);

-- CreateTable
CREATE TABLE "room_images" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "room_type_id" UUID,
    "image_url" TEXT NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "room_images_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "room_price_settings" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "room_type_id" UUID NOT NULL,
    "base_price" DECIMAL(15,2) NOT NULL,
    "extra_adult_fee" DECIMAL(15,2) DEFAULT 0,
    "extra_bed_fee" DECIMAL(15,2) DEFAULT 0,
    "breakfast_fee" DECIMAL(15,2) DEFAULT 0,
    "extra_child_fee_percent" DECIMAL(5,2) DEFAULT 0,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "room_price_settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "room_price_rules" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "room_type_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "rate_type" "rate_type_enum" NOT NULL,
    "start_date" DATE,
    "end_date" DATE,
    "days_of_week" INTEGER[],
    "price_value" DECIMAL(15,2) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "room_price_rules_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "room_type_inventories" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "room_type_id" UUID NOT NULL,
    "inventory_date" DATE NOT NULL,
    "total_room" INTEGER NOT NULL,
    "booked_room" INTEGER NOT NULL DEFAULT 0,
    "available_room" INTEGER NOT NULL,
    "is_closed" BOOLEAN NOT NULL DEFAULT false,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "room_type_inventories_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tours" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "agent_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "code" VARCHAR(50) NOT NULL,
    "departure_id" UUID NOT NULL,
    "duration_days" INTEGER NOT NULL,
    "duration_nights" INTEGER NOT NULL,
    "min_guests" INTEGER NOT NULL,
    "max_guests" INTEGER NOT NULL,
    "description" TEXT NOT NULL,
    "highlights" TEXT[],
    "inclusions" TEXT[],
    "exclusions" TEXT[],
    "important_note" TEXT,
    "cancellation_policy" TEXT NOT NULL,
    "video_url" VARCHAR(255),
    "brochure_pdf_url" VARCHAR(255),
    "status" "tour_status_enum" DEFAULT 'DRAFT',
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "tours_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tour_category_relations" (
    "tour_id" UUID NOT NULL,
    "tour_category_id" UUID NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "tour_category_relations_pkey" PRIMARY KEY ("tour_id","tour_category_id")
);

-- CreateTable
CREATE TABLE "tour_destinations" (
    "tour_id" UUID NOT NULL,
    "destination_id" UUID NOT NULL,
    "sort_order" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "tour_destinations_pkey" PRIMARY KEY ("tour_id","destination_id")
);

-- CreateTable
CREATE TABLE "tour_transportations" (
    "tour_id" UUID NOT NULL,
    "transportation_category_id" UUID NOT NULL,
    "sort_order" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "tour_transportations_pkey" PRIMARY KEY ("tour_id","transportation_category_id")
);

-- CreateTable
CREATE TABLE "tour_images" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "tour_id" UUID NOT NULL,
    "image_url" TEXT NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "tour_images_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tour_departures" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "tour_id" UUID NOT NULL,
    "departure_date" DATE NOT NULL,
    "return_date" DATE NOT NULL,
    "total_slots" INTEGER NOT NULL,
    "booked_slots" INTEGER NOT NULL DEFAULT 0,
    "adult_price" DECIMAL(15,2) NOT NULL,
    "child_price_5_10" DECIMAL(15,2) NOT NULL,
    "child_price_2_4" DECIMAL(15,2) NOT NULL,
    "infant_price" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "extra_single_room_fee" DECIMAL(15,2) DEFAULT 0,
    "status" "departure_status_enum" NOT NULL DEFAULT 'OPEN',
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "tour_departures_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tour_itineraries" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "tour_id" UUID NOT NULL,
    "day_number" INTEGER NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "description" TEXT NOT NULL,
    "has_breakfast" BOOLEAN NOT NULL DEFAULT false,
    "has_lunch" BOOLEAN NOT NULL DEFAULT false,
    "has_dinner" BOOLEAN NOT NULL DEFAULT false,
    "hotel_name" VARCHAR(255),
    "hotel_stars" INTEGER,
    "lat" DECIMAL(10,8) NOT NULL,
    "lng" DECIMAL(11,8) NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "tour_itineraries_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tour_itinerary_images" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "tour_itinerary_id" UUID NOT NULL,
    "image_url" TEXT NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "tour_itinerary_images_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "combos" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "agent_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT NOT NULL,
    "type" "combo_type_enum" NOT NULL,
    "tour_id" UUID,
    "hotel_id" UUID,
    "room_type_id" UUID,
    "airline" VARCHAR(100),
    "outbound_route" VARCHAR(50),
    "inbound_route" VARCHAR(50),
    "ticket_class" "ticket_class_enum" DEFAULT 'ECONOMY',
    "baggage_hand_kg" INTEGER DEFAULT 7,
    "baggage_checked_kg" INTEGER DEFAULT 0,
    "duration_days" INTEGER NOT NULL,
    "duration_nights" INTEGER NOT NULL,
    "min_guests" INTEGER NOT NULL DEFAULT 1,
    "max_guests" INTEGER NOT NULL,
    "inclusions" TEXT[],
    "exclusions" TEXT[],
    "cancellation_policy" TEXT NOT NULL,
    "status" "combo_status_enum" DEFAULT 'DRAFT',
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "combos_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "combo_departures" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "combo_id" UUID NOT NULL,
    "departure_date" DATE NOT NULL,
    "return_date" DATE NOT NULL,
    "outbound_flight_time" VARCHAR(50),
    "inbound_flight_time" VARCHAR(50),
    "total_slots" INTEGER NOT NULL,
    "booked_slots" INTEGER NOT NULL DEFAULT 0,
    "original_price" DECIMAL(15,2) NOT NULL,
    "combo_price" DECIMAL(15,2) NOT NULL,
    "discount_percent" DECIMAL(5,2) NOT NULL,
    "status" "combo_departure_status_enum" NOT NULL DEFAULT 'OPEN',
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "combo_departures_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "combo_images" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "combo_id" UUID NOT NULL,
    "image_url" TEXT NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "combo_images_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_bank_accounts" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "agent_id" UUID NOT NULL,
    "bank_name" VARCHAR(100) NOT NULL,
    "account_number" VARCHAR(50) NOT NULL,
    "account_name" VARCHAR(150) NOT NULL,
    "is_default" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "agent_bank_accounts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "bookings" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "booking_code" VARCHAR(50) NOT NULL,
    "user_id" UUID NOT NULL,
    "agent_id" UUID NOT NULL,
    "corporate_id" UUID,
    "corporate_discount" DECIMAL(15,2) DEFAULT 0,
    "type" "product_type_enum" NOT NULL,
    "status" "booking_status_enum" NOT NULL DEFAULT 'PENDING_CONFIRMATION',
    "total_amount" DECIMAL(15,2) NOT NULL,
    "system_voucher_id" UUID,
    "system_voucher_discount" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "agent_promotion_id" UUID,
    "agent_promotion_discount" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "points_redeemed" INTEGER NOT NULL DEFAULT 0,
    "points_discount" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "points_earned" INTEGER NOT NULL DEFAULT 0,
    "final_amount" DECIMAL(15,2) NOT NULL,
    "tax_percent" DECIMAL(5,2) NOT NULL,
    "special_request" TEXT,
    "agent_note" TEXT,
    "cancellation_reason" TEXT,
    "confirmation_deadline_at" TIMESTAMP(3) NOT NULL,
    "payment_deadline_at" TIMESTAMP(3),
    "affiliate_id" UUID,
    "system_internal_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "bookings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "booking_hotel_details" (
    "booking_id" UUID NOT NULL,
    "hotel_id" UUID NOT NULL,
    "room_type_id" UUID NOT NULL,
    "check_in_date" DATE NOT NULL,
    "check_out_date" DATE NOT NULL,
    "room_count" INTEGER NOT NULL DEFAULT 1,
    "base_price" DECIMAL(15,2) NOT NULL,
    "service_fee_percent" DECIMAL(5,2) NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "booking_hotel_details_pkey" PRIMARY KEY ("booking_id")
);

-- CreateTable
CREATE TABLE "booking_hotel_room_operations" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "booking_id" UUID NOT NULL,
    "room_index" INTEGER NOT NULL DEFAULT 1,
    "assigned_room_number" VARCHAR(50),
    "actual_check_in_at" TIMESTAMP(3),
    "actual_check_out_at" TIMESTAMP(3),
    "stay_incident_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "booking_hotel_room_operations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "booking_tour_details" (
    "booking_id" UUID NOT NULL,
    "tour_id" UUID NOT NULL,
    "departure_id" UUID NOT NULL,
    "tour_name" VARCHAR(255) NOT NULL,
    "tour_code" VARCHAR(50) NOT NULL,
    "departure_date" DATE NOT NULL,
    "return_date" DATE NOT NULL,
    "adult_count" INTEGER NOT NULL DEFAULT 1,
    "child_count_5_10" INTEGER NOT NULL DEFAULT 0,
    "child_count_2_4" INTEGER NOT NULL DEFAULT 0,
    "infant_count" INTEGER NOT NULL DEFAULT 0,
    "has_single_room" BOOLEAN NOT NULL DEFAULT false,
    "adult_price" DECIMAL(15,2) NOT NULL,
    "child_price_5_10" DECIMAL(15,2) NOT NULL,
    "child_price_2_4" DECIMAL(15,2) NOT NULL,
    "infant_price" DECIMAL(15,2) NOT NULL,
    "extra_single_room_fee" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "booking_tour_details_pkey" PRIMARY KEY ("booking_id")
);

-- CreateTable
CREATE TABLE "booking_combo_details" (
    "booking_id" UUID NOT NULL,
    "combo_id" UUID NOT NULL,
    "departure_id" UUID NOT NULL,
    "quantity" INTEGER NOT NULL DEFAULT 1,
    "combo_name" VARCHAR(255) NOT NULL,
    "departure_date" DATE NOT NULL,
    "return_date" DATE NOT NULL,
    "outbound_flight_time" VARCHAR(50),
    "inbound_flight_time" VARCHAR(50),
    "original_price" DECIMAL(15,2) NOT NULL,
    "combo_price" DECIMAL(15,2) NOT NULL,
    "discount_percent" DECIMAL(5,2) NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "booking_combo_details_pkey" PRIMARY KEY ("booking_id")
);

-- CreateTable
CREATE TABLE "booking_passengers" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "booking_id" UUID NOT NULL,
    "full_name" VARCHAR(255) NOT NULL,
    "identity_number" VARCHAR(50),
    "phone" VARCHAR(20),
    "gender" "passenger_gender_enum" NOT NULL DEFAULT 'MALE',
    "date_of_birth" DATE NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "booking_passengers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "booking_payments" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "booking_id" UUID NOT NULL,
    "amount_paid" DECIMAL(15,2) NOT NULL,
    "payment_reference" VARCHAR(100) NOT NULL,
    "received_at" TIMESTAMP(3) NOT NULL,
    "staff_id" UUID,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "booking_payments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "system_vouchers" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "code" VARCHAR(50) NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "discount_type" "voucher_discount_type_enum" NOT NULL,
    "discount_value" DECIMAL(15,2) NOT NULL,
    "max_discount_amount" DECIMAL(15,2),
    "min_order_value" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "product_type" "product_type_enum",
    "audience_type" "voucher_audience_enum" DEFAULT 'ALL',
    "total_quantity" INTEGER NOT NULL,
    "used_count" INTEGER NOT NULL DEFAULT 0,
    "per_user_limit" INTEGER NOT NULL DEFAULT 1,
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "system_vouchers_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "system_voucher_destinations" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "voucher_id" UUID NOT NULL,
    "destination_id" UUID NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "system_voucher_destinations_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "system_voucher_target_users" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "voucher_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "system_voucher_target_users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_promotions" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "agent_id" UUID NOT NULL,
    "name" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "voucher_code" VARCHAR(50),
    "type" "promotion_type_enum" NOT NULL,
    "status" "promotion_status_enum" DEFAULT 'DRAFT',
    "discount_value" DECIMAL(15,2) NOT NULL,
    "max_discount_amount" DECIMAL(15,2),
    "min_order_value" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "early_bird_days" INTEGER,
    "last_minute_days" INTEGER DEFAULT 3,
    "flash_start_time" TIME,
    "flash_end_time" TIME,
    "stay_min_nights" INTEGER,
    "stay_free_nights" INTEGER,
    "buy_quantity" INTEGER,
    "get_quantity" INTEGER,
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "total_usage_limit" INTEGER,
    "used_count" INTEGER NOT NULL DEFAULT 0,
    "per_user_limit" INTEGER NOT NULL DEFAULT 1,
    "is_stackable" BOOLEAN NOT NULL DEFAULT false,
    "high_discount_reason" TEXT,
    "moderator_id" UUID,
    "moderation_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "agent_promotions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agent_promotion_targets" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "promotion_id" UUID NOT NULL,
    "hotel_id" UUID,
    "tour_id" UUID,
    "combo_id" UUID,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "agent_promotion_targets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "product_moderation_requests" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "moderator_id" UUID,
    "agent_id" UUID NOT NULL,
    "product_type" "product_type_enum" NOT NULL,
    "hotel_id" UUID,
    "tour_id" UUID,
    "combo_id" UUID,
    "priority" "moderation_priority_enum" DEFAULT 'MEDIUM',
    "status" "moderation_status_enum" NOT NULL DEFAULT 'PENDING',
    "is_info_complete" BOOLEAN NOT NULL DEFAULT false,
    "is_image_valid" BOOLEAN NOT NULL DEFAULT false,
    "is_price_reasonable" BOOLEAN NOT NULL DEFAULT false,
    "is_policy_clear" BOOLEAN NOT NULL DEFAULT false,
    "is_content_safe" BOOLEAN NOT NULL DEFAULT false,
    "is_gps_accurate" BOOLEAN NOT NULL DEFAULT false,
    "feedback_note" TEXT,
    "sla_deadline" TIMESTAMP(3) NOT NULL,
    "resolved_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "product_moderation_requests_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reviews" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "booking_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "product_type" "product_type_enum" NOT NULL,
    "hotel_id" UUID,
    "tour_id" UUID,
    "combo_id" UUID,
    "rating" INTEGER NOT NULL,
    "content" TEXT NOT NULL,
    "status" "review_status_enum" NOT NULL DEFAULT 'PENDING',
    "is_auto_flagged" BOOLEAN NOT NULL DEFAULT false,
    "moderator_id" UUID,
    "moderation_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "reviews_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "system_configs" (
    "id" INTEGER NOT NULL DEFAULT 1,
    "is_review_auto_approve" BOOLEAN NOT NULL DEFAULT true,
    "promotion_auto_approve_threshold_percent" DECIMAL(5,2) NOT NULL DEFAULT 50.00,
    "default_platform_commission_percent" DECIMAL(5,2) NOT NULL DEFAULT 15.00,
    "default_affiliate_commission_percent" DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    "default_vat_percent" DECIMAL(5,2) NOT NULL DEFAULT 10.00,
    "default_service_fee_percent" DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    "min_affiliate_withdrawal_amount" DECIMAL(15,2) NOT NULL DEFAULT 500000.00,
    "spending_per_point_amount" DECIMAL(15,2) NOT NULL DEFAULT 10000.00,
    "points_per_discount_block" INTEGER NOT NULL DEFAULT 100,
    "discount_per_block_amount" DECIMAL(15,2) NOT NULL DEFAULT 10000.00,
    "tier_silver_threshold_amount" DECIMAL(15,2) NOT NULL DEFAULT 5000000.00,
    "tier_gold_threshold_amount" DECIMAL(15,2) NOT NULL DEFAULT 15000000.00,
    "tier_platinum_threshold_amount" DECIMAL(15,2) NOT NULL DEFAULT 50000000.00,
    "site_name" VARCHAR(255) DEFAULT 'Sàn Du Lịch Toàn Cầu',
    "site_logo_url" TEXT,
    "site_favicon_url" TEXT,
    "hotline" VARCHAR(20),
    "support_email" VARCHAR(255),
    "facebook_url" VARCHAR(255),
    "zalo_url" VARCHAR(255),
    "instagram_url" VARCHAR(255),
    "youtube_url" VARCHAR(255),
    "google_analytics_id" VARCHAR(50),
    "facebook_pixel_id" VARCHAR(50),
    "gtm_id" VARCHAR(50),
    "google_maps_api_key" TEXT,
    "map_default_zoom" INTEGER DEFAULT 6,
    "map_default_center_lat" DECIMAL(10,8) DEFAULT 16.047079,
    "map_default_center_lng" DECIMAL(11,8) DEFAULT 108.206230,
    "map_custom_style_json" TEXT,
    "enable_hotel_map" BOOLEAN NOT NULL DEFAULT true,
    "enable_tour_map" BOOLEAN NOT NULL DEFAULT true,
    "enable_search_map" BOOLEAN NOT NULL DEFAULT true,
    "enable_directions_api" BOOLEAN NOT NULL DEFAULT true,
    "enable_street_view" BOOLEAN NOT NULL DEFAULT true,
    "enable_place_autocomplete" BOOLEAN NOT NULL DEFAULT true,
    "ai_provider" VARCHAR(50) DEFAULT 'GEMINI',
    "ai_api_key" TEXT,
    "ai_model_name" VARCHAR(100) DEFAULT 'gemini-1.5-flash',
    "ai_system_prompt" TEXT,
    "ai_daily_limit_per_user" INTEGER NOT NULL DEFAULT 50,
    "ai_max_tokens_per_response" INTEGER NOT NULL DEFAULT 1000,
    "ai_fallback_default_reply" TEXT,
    "ai_tone" VARCHAR(50) DEFAULT 'FRIENDLY',
    "ai_enable_human_fallback" BOOLEAN NOT NULL DEFAULT true,
    "description" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "system_configs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "booking_status_logs" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "booking_id" UUID NOT NULL,
    "old_status" "booking_status_enum" NOT NULL,
    "new_status" "booking_status_enum" NOT NULL,
    "changed_by" UUID NOT NULL,
    "change_reason" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "booking_status_logs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "dispute_tickets" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "ticket_code" VARCHAR(50) NOT NULL,
    "booking_id" UUID NOT NULL,
    "creator_id" UUID NOT NULL,
    "handler_id" UUID,
    "title" VARCHAR(255) NOT NULL,
    "description" TEXT NOT NULL,
    "priority" "dispute_priority_enum" DEFAULT 'MEDIUM',
    "status" "dispute_status_enum" NOT NULL DEFAULT 'OPEN',
    "sla_deadline" TIMESTAMP(3) NOT NULL,
    "final_decision" "dispute_decision_enum",
    "refund_amount" DECIMAL(15,2) DEFAULT 0,
    "compensation_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "closed_at" TIMESTAMP(3),

    CONSTRAINT "dispute_tickets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "dispute_evidences" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "dispute_id" UUID NOT NULL,
    "uploaded_by" UUID NOT NULL,
    "file_url" TEXT NOT NULL,
    "file_type" VARCHAR(50),
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "dispute_evidences_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "dispute_messages" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "dispute_id" UUID NOT NULL,
    "sender_id" UUID NOT NULL,
    "sender_type" "dispute_sender_type_enum" NOT NULL,
    "message" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "dispute_messages_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "static_pages" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "slug" VARCHAR(255) NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "content" TEXT NOT NULL,
    "status" "content_status_enum" DEFAULT 'DRAFT',
    "seo_title" VARCHAR(255),
    "seo_description" TEXT,
    "seo_keywords" VARCHAR(255),
    "og_title" VARCHAR(255),
    "og_description" TEXT,
    "og_image" TEXT,
    "published_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "static_pages_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "static_page_versions" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "page_id" UUID NOT NULL,
    "version_number" INTEGER NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "content" TEXT NOT NULL,
    "seo_title" VARCHAR(255),
    "seo_description" TEXT,
    "seo_keywords" VARCHAR(255),
    "og_image" TEXT,
    "created_by" UUID,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "static_page_versions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "banners" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "title" VARCHAR(255) NOT NULL,
    "description" TEXT,
    "image_url" TEXT NOT NULL,
    "cta_text" VARCHAR(100),
    "target_url" TEXT NOT NULL,
    "position" "banner_position_enum" NOT NULL,
    "sort_order" INTEGER NOT NULL DEFAULT 1,
    "audience_type" "banner_audience_enum" DEFAULT 'ALL',
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "impressions_count" INTEGER NOT NULL DEFAULT 0,
    "clicks_count" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "banners_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "blogs" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "category_id" UUID NOT NULL,
    "author_id" UUID NOT NULL,
    "title" VARCHAR(255) NOT NULL,
    "slug" VARCHAR(255) NOT NULL,
    "summary" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "featured_image" TEXT NOT NULL,
    "status" "content_status_enum" DEFAULT 'DRAFT',
    "views_count" INTEGER NOT NULL DEFAULT 0,
    "seo_title" VARCHAR(255),
    "seo_description" TEXT,
    "seo_keywords" VARCHAR(255),
    "published_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "blogs_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "blog_products" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "blog_id" UUID NOT NULL,
    "product_type" "product_type_enum" NOT NULL,
    "hotel_id" UUID,
    "tour_id" UUID,
    "combo_id" UUID,

    CONSTRAINT "blog_products_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "blog_comments" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "blog_id" UUID NOT NULL,
    "user_id" UUID NOT NULL,
    "content" TEXT NOT NULL,
    "status" "comment_status_enum" NOT NULL DEFAULT 'PENDING',
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "blog_comments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "affiliate_profiles" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "user_id" UUID NOT NULL,
    "affiliate_code" VARCHAR(50) NOT NULL,
    "promotion_channels" TEXT NOT NULL,
    "status" "affiliate_status_enum" NOT NULL DEFAULT 'PENDING',
    "status_note" TEXT,
    "custom_commission_percent" DECIMAL(5,2),
    "clicks_count" INTEGER NOT NULL DEFAULT 0,
    "conversions_count" INTEGER NOT NULL DEFAULT 0,
    "available_balance" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "withdrawn_amount" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "total_earned" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "affiliate_profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "affiliate_commissions" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "affiliate_id" UUID NOT NULL,
    "booking_id" UUID NOT NULL,
    "total_amount" DECIMAL(15,2) NOT NULL,
    "commission_percent" DECIMAL(5,2) NOT NULL,
    "commission_amount" DECIMAL(15,2) NOT NULL,
    "status" "affiliate_commission_status_enum" NOT NULL DEFAULT 'PENDING',
    "status_note" TEXT,
    "available_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "affiliate_commissions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "affiliate_withdrawals" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "affiliate_id" UUID NOT NULL,
    "amount" DECIMAL(15,2) NOT NULL,
    "bank_name" VARCHAR(100) NOT NULL,
    "bank_account_number" VARCHAR(50) NOT NULL,
    "bank_account_name" VARCHAR(255) NOT NULL,
    "status" "withdrawal_status_enum" NOT NULL DEFAULT 'PENDING',
    "processed_by" UUID,
    "transaction_reference" VARCHAR(255),
    "admin_note" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "affiliate_withdrawals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_loyalty_profiles" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "user_id" UUID NOT NULL,
    "current_tier" "membership_tier_enum" NOT NULL DEFAULT 'BRONZE',
    "current_points" INTEGER NOT NULL DEFAULT 0,
    "total_accumulated_points" INTEGER NOT NULL DEFAULT 0,
    "rolling_12m_spending" DECIMAL(15,2) NOT NULL DEFAULT 0,
    "updated_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_loyalty_profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_point_logs" (
    "id" UUID NOT NULL DEFAULT gen_random_uuid(),
    "user_id" UUID NOT NULL,
    "booking_id" UUID,
    "type" "point_transaction_type_enum" NOT NULL,
    "points" INTEGER NOT NULL,
    "points_available" INTEGER NOT NULL DEFAULT 0,
    "description" TEXT,
    "expired_at" TIMESTAMP(3),
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "user_point_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "roles_name_key" ON "roles"("name");

-- CreateIndex
CREATE UNIQUE INDEX "permissions_code_key" ON "permissions"("code");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_username_key" ON "users"("username");

-- CreateIndex
CREATE UNIQUE INDEX "users_phone_key" ON "users"("phone");

-- CreateIndex
CREATE UNIQUE INDEX "agents_user_id_key" ON "agents"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "agents_agent_code_key" ON "agents"("agent_code");

-- CreateIndex
CREATE UNIQUE INDEX "agents_tax_code_key" ON "agents"("tax_code");

-- CreateIndex
CREATE UNIQUE INDEX "agents_representative_id_number_key" ON "agents"("representative_id_number");

-- CreateIndex
CREATE INDEX "agent_images_agent_id_sort_order_idx" ON "agent_images"("agent_id", "sort_order");

-- CreateIndex
CREATE UNIQUE INDEX "corporates_corporate_code_key" ON "corporates"("corporate_code");

-- CreateIndex
CREATE UNIQUE INDEX "corporates_tax_code_key" ON "corporates"("tax_code");

-- CreateIndex
CREATE UNIQUE INDEX "corporate_employees_user_id_key" ON "corporate_employees"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "corporate_contracts_contract_number_key" ON "corporate_contracts"("contract_number");

-- CreateIndex
CREATE INDEX "corporate_contracts_corporate_id_idx" ON "corporate_contracts"("corporate_id");

-- CreateIndex
CREATE INDEX "corporate_contracts_start_date_end_date_idx" ON "corporate_contracts"("start_date", "end_date");

-- CreateIndex
CREATE UNIQUE INDEX "destinations_administrative_code_key" ON "destinations"("administrative_code");

-- CreateIndex
CREATE UNIQUE INDEX "destinations_slug_key" ON "destinations"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "activity_field_categories_name_key" ON "activity_field_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "activity_field_categories_slug_key" ON "activity_field_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "bed_categories_code_key" ON "bed_categories"("code");

-- CreateIndex
CREATE UNIQUE INDEX "blog_categories_slug_key" ON "blog_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "tour_categories_name_key" ON "tour_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "tour_categories_slug_key" ON "tour_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "hotel_categories_name_key" ON "hotel_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "hotel_categories_slug_key" ON "hotel_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "star_rating_categories_star_number_key" ON "star_rating_categories"("star_number");

-- CreateIndex
CREATE UNIQUE INDEX "star_rating_categories_slug_key" ON "star_rating_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "room_categories_name_key" ON "room_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "room_categories_slug_key" ON "room_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "hotel_facility_categories_name_key" ON "hotel_facility_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "hotel_facility_categories_slug_key" ON "hotel_facility_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "room_facility_categories_name_key" ON "room_facility_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "room_facility_categories_slug_key" ON "room_facility_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "transportation_categories_name_key" ON "transportation_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "transportation_categories_slug_key" ON "transportation_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "meal_categories_name_key" ON "meal_categories"("name");

-- CreateIndex
CREATE UNIQUE INDEX "meal_categories_slug_key" ON "meal_categories"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "hotels_slug_key" ON "hotels"("slug");

-- CreateIndex
CREATE INDEX "hotel_images_hotel_id_sort_order_idx" ON "hotel_images"("hotel_id", "sort_order");

-- CreateIndex
CREATE INDEX "room_images_room_type_id_sort_order_idx" ON "room_images"("room_type_id", "sort_order");

-- CreateIndex
CREATE UNIQUE INDEX "room_price_settings_room_type_id_key" ON "room_price_settings"("room_type_id");

-- CreateIndex
CREATE INDEX "idx_room_price_settings_type_unique_active" ON "room_price_settings"("room_type_id");

-- CreateIndex
CREATE INDEX "room_price_rules_room_type_id_rate_type_idx" ON "room_price_rules"("room_type_id", "rate_type");

-- CreateIndex
CREATE INDEX "room_price_rules_start_date_end_date_idx" ON "room_price_rules"("start_date", "end_date");

-- CreateIndex
CREATE INDEX "idx_price_rules_perf" ON "room_price_rules"("room_type_id", "start_date", "end_date");

-- CreateIndex
CREATE UNIQUE INDEX "idx_room_inventory_date_unique" ON "room_type_inventories"("room_type_id", "inventory_date");

-- CreateIndex
CREATE UNIQUE INDEX "tours_code_key" ON "tours"("code");

-- CreateIndex
CREATE INDEX "tours_code_idx" ON "tours"("code");

-- CreateIndex
CREATE INDEX "tours_status_idx" ON "tours"("status");

-- CreateIndex
CREATE INDEX "tours_agent_id_idx" ON "tours"("agent_id");

-- CreateIndex
CREATE INDEX "tours_departure_id_status_idx" ON "tours"("departure_id", "status");

-- CreateIndex
CREATE INDEX "tour_images_tour_id_sort_order_idx" ON "tour_images"("tour_id", "sort_order");

-- CreateIndex
CREATE INDEX "tour_departures_tour_id_departure_date_idx" ON "tour_departures"("tour_id", "departure_date");

-- CreateIndex
CREATE INDEX "tour_departures_departure_date_idx" ON "tour_departures"("departure_date");

-- CreateIndex
CREATE INDEX "tour_departures_status_idx" ON "tour_departures"("status");

-- CreateIndex
CREATE INDEX "idx_tour_departures_search_active" ON "tour_departures"("departure_date", "status");

-- CreateIndex
CREATE INDEX "idx_tour_itinerary_day_unique_active" ON "tour_itineraries"("tour_id", "day_number");

-- CreateIndex
CREATE INDEX "tour_itinerary_images_tour_itinerary_id_sort_order_idx" ON "tour_itinerary_images"("tour_itinerary_id", "sort_order");

-- CreateIndex
CREATE INDEX "combos_type_idx" ON "combos"("type");

-- CreateIndex
CREATE INDEX "combos_status_idx" ON "combos"("status");

-- CreateIndex
CREATE INDEX "combos_agent_id_idx" ON "combos"("agent_id");

-- CreateIndex
CREATE INDEX "combo_departures_departure_date_idx" ON "combo_departures"("departure_date");

-- CreateIndex
CREATE INDEX "combo_departures_status_idx" ON "combo_departures"("status");

-- CreateIndex
CREATE UNIQUE INDEX "idx_combo_departure_date_unique" ON "combo_departures"("combo_id", "departure_date");

-- CreateIndex
CREATE INDEX "combo_images_combo_id_sort_order_idx" ON "combo_images"("combo_id", "sort_order");

-- CreateIndex
CREATE INDEX "agent_bank_accounts_agent_id_is_default_idx" ON "agent_bank_accounts"("agent_id", "is_default");

-- CreateIndex
CREATE UNIQUE INDEX "bookings_booking_code_key" ON "bookings"("booking_code");

-- CreateIndex
CREATE INDEX "bookings_booking_code_idx" ON "bookings"("booking_code");

-- CreateIndex
CREATE INDEX "bookings_status_idx" ON "bookings"("status");

-- CreateIndex
CREATE INDEX "bookings_type_idx" ON "bookings"("type");

-- CreateIndex
CREATE INDEX "bookings_agent_id_idx" ON "bookings"("agent_id");

-- CreateIndex
CREATE INDEX "bookings_user_id_idx" ON "bookings"("user_id");

-- CreateIndex
CREATE INDEX "idx_agent_booking_filters" ON "bookings"("agent_id", "status", "type");

-- CreateIndex
CREATE UNIQUE INDEX "idx_booking_room_op_unique_active" ON "booking_hotel_room_operations"("booking_id", "room_index");

-- CreateIndex
CREATE INDEX "booking_passengers_booking_id_idx" ON "booking_passengers"("booking_id");

-- CreateIndex
CREATE INDEX "booking_passengers_identity_number_idx" ON "booking_passengers"("identity_number");

-- CreateIndex
CREATE INDEX "booking_payments_booking_id_idx" ON "booking_payments"("booking_id");

-- CreateIndex
CREATE INDEX "booking_payments_payment_reference_idx" ON "booking_payments"("payment_reference");

-- CreateIndex
CREATE UNIQUE INDEX "system_vouchers_code_key" ON "system_vouchers"("code");

-- CreateIndex
CREATE INDEX "system_vouchers_code_idx" ON "system_vouchers"("code");

-- CreateIndex
CREATE INDEX "system_vouchers_is_active_idx" ON "system_vouchers"("is_active");

-- CreateIndex
CREATE INDEX "system_vouchers_start_date_end_date_idx" ON "system_vouchers"("start_date", "end_date");

-- CreateIndex
CREATE INDEX "agent_promotions_voucher_code_idx" ON "agent_promotions"("voucher_code");

-- CreateIndex
CREATE INDEX "agent_promotions_status_idx" ON "agent_promotions"("status");

-- CreateIndex
CREATE INDEX "agent_promotions_agent_id_idx" ON "agent_promotions"("agent_id");

-- CreateIndex
CREATE INDEX "agent_promotions_start_date_end_date_idx" ON "agent_promotions"("start_date", "end_date");

-- CreateIndex
CREATE INDEX "product_moderation_requests_product_type_status_idx" ON "product_moderation_requests"("product_type", "status");

-- CreateIndex
CREATE INDEX "product_moderation_requests_status_idx" ON "product_moderation_requests"("status");

-- CreateIndex
CREATE INDEX "product_moderation_requests_agent_id_idx" ON "product_moderation_requests"("agent_id");

-- CreateIndex
CREATE INDEX "reviews_product_type_status_idx" ON "reviews"("product_type", "status");

-- CreateIndex
CREATE UNIQUE INDEX "idx_user_booking_review_unique" ON "reviews"("user_id", "booking_id");

-- CreateIndex
CREATE INDEX "booking_status_logs_booking_id_idx" ON "booking_status_logs"("booking_id");

-- CreateIndex
CREATE INDEX "booking_status_logs_created_at_idx" ON "booking_status_logs"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "dispute_tickets_ticket_code_key" ON "dispute_tickets"("ticket_code");

-- CreateIndex
CREATE INDEX "dispute_tickets_ticket_code_idx" ON "dispute_tickets"("ticket_code");

-- CreateIndex
CREATE INDEX "dispute_tickets_status_idx" ON "dispute_tickets"("status");

-- CreateIndex
CREATE INDEX "dispute_tickets_priority_idx" ON "dispute_tickets"("priority");

-- CreateIndex
CREATE INDEX "dispute_tickets_booking_id_idx" ON "dispute_tickets"("booking_id");

-- CreateIndex
CREATE INDEX "idx_dispute_sla_tracking" ON "dispute_tickets"("status", "sla_deadline");

-- CreateIndex
CREATE INDEX "dispute_evidences_dispute_id_idx" ON "dispute_evidences"("dispute_id");

-- CreateIndex
CREATE INDEX "dispute_messages_dispute_id_idx" ON "dispute_messages"("dispute_id");

-- CreateIndex
CREATE INDEX "dispute_messages_created_at_idx" ON "dispute_messages"("created_at");

-- CreateIndex
CREATE UNIQUE INDEX "static_pages_slug_key" ON "static_pages"("slug");

-- CreateIndex
CREATE INDEX "static_pages_slug_idx" ON "static_pages"("slug");

-- CreateIndex
CREATE INDEX "static_pages_status_idx" ON "static_pages"("status");

-- CreateIndex
CREATE UNIQUE INDEX "idx_page_version_unique" ON "static_page_versions"("page_id", "version_number");

-- CreateIndex
CREATE INDEX "banners_position_idx" ON "banners"("position");

-- CreateIndex
CREATE INDEX "banners_is_active_idx" ON "banners"("is_active");

-- CreateIndex
CREATE INDEX "banners_start_date_end_date_idx" ON "banners"("start_date", "end_date");

-- CreateIndex
CREATE UNIQUE INDEX "blogs_slug_key" ON "blogs"("slug");

-- CreateIndex
CREATE INDEX "blogs_status_idx" ON "blogs"("status");

-- CreateIndex
CREATE INDEX "blogs_category_id_idx" ON "blogs"("category_id");

-- CreateIndex
CREATE INDEX "blogs_published_at_idx" ON "blogs"("published_at");

-- CreateIndex
CREATE INDEX "blog_products_blog_id_idx" ON "blog_products"("blog_id");

-- CreateIndex
CREATE INDEX "blog_comments_blog_id_idx" ON "blog_comments"("blog_id");

-- CreateIndex
CREATE INDEX "blog_comments_status_idx" ON "blog_comments"("status");

-- CreateIndex
CREATE UNIQUE INDEX "affiliate_profiles_user_id_key" ON "affiliate_profiles"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "affiliate_profiles_affiliate_code_key" ON "affiliate_profiles"("affiliate_code");

-- CreateIndex
CREATE INDEX "affiliate_profiles_user_id_idx" ON "affiliate_profiles"("user_id");

-- CreateIndex
CREATE INDEX "affiliate_profiles_affiliate_code_idx" ON "affiliate_profiles"("affiliate_code");

-- CreateIndex
CREATE INDEX "affiliate_profiles_status_idx" ON "affiliate_profiles"("status");

-- CreateIndex
CREATE INDEX "affiliate_commissions_affiliate_id_idx" ON "affiliate_commissions"("affiliate_id");

-- CreateIndex
CREATE INDEX "affiliate_commissions_booking_id_idx" ON "affiliate_commissions"("booking_id");

-- CreateIndex
CREATE INDEX "affiliate_commissions_status_idx" ON "affiliate_commissions"("status");

-- CreateIndex
CREATE INDEX "idx_commission_release_job" ON "affiliate_commissions"("status", "available_at");

-- CreateIndex
CREATE INDEX "affiliate_withdrawals_affiliate_id_idx" ON "affiliate_withdrawals"("affiliate_id");

-- CreateIndex
CREATE INDEX "affiliate_withdrawals_status_idx" ON "affiliate_withdrawals"("status");

-- CreateIndex
CREATE UNIQUE INDEX "user_loyalty_profiles_user_id_key" ON "user_loyalty_profiles"("user_id");

-- CreateIndex
CREATE INDEX "user_loyalty_profiles_user_id_idx" ON "user_loyalty_profiles"("user_id");

-- CreateIndex
CREATE INDEX "user_loyalty_profiles_current_tier_idx" ON "user_loyalty_profiles"("current_tier");

-- CreateIndex
CREATE INDEX "user_point_logs_user_id_idx" ON "user_point_logs"("user_id");

-- CreateIndex
CREATE INDEX "user_point_logs_type_idx" ON "user_point_logs"("type");

-- CreateIndex
CREATE INDEX "user_point_logs_expired_at_idx" ON "user_point_logs"("expired_at");

-- CreateIndex
CREATE INDEX "idx_user_points_fifo_tracking" ON "user_point_logs"("user_id", "points_available");

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "role_permissions" ADD CONSTRAINT "role_permissions_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "permissions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_roles" ADD CONSTRAINT "user_roles_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agents" ADD CONSTRAINT "agents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_activity_fields" ADD CONSTRAINT "agent_activity_fields_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_activity_fields" ADD CONSTRAINT "agent_activity_fields_activity_field_id_fkey" FOREIGN KEY ("activity_field_id") REFERENCES "activity_field_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_images" ADD CONSTRAINT "agent_images_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "staff_audit_logs" ADD CONSTRAINT "staff_audit_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "corporate_employees" ADD CONSTRAINT "corporate_employees_corporate_id_fkey" FOREIGN KEY ("corporate_id") REFERENCES "corporates"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "corporate_employees" ADD CONSTRAINT "corporate_employees_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "corporate_contracts" ADD CONSTRAINT "corporate_contracts_corporate_id_fkey" FOREIGN KEY ("corporate_id") REFERENCES "corporates"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "destinations" ADD CONSTRAINT "destinations_parent_id_fkey" FOREIGN KEY ("parent_id") REFERENCES "destinations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hotels" ADD CONSTRAINT "hotels_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hotels" ADD CONSTRAINT "hotels_destination_id_fkey" FOREIGN KEY ("destination_id") REFERENCES "destinations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hotels" ADD CONSTRAINT "hotels_hotel_category_id_fkey" FOREIGN KEY ("hotel_category_id") REFERENCES "hotel_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hotels" ADD CONSTRAINT "hotels_star_rating_id_fkey" FOREIGN KEY ("star_rating_id") REFERENCES "star_rating_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hotel_facilities" ADD CONSTRAINT "hotel_facilities_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hotel_facilities" ADD CONSTRAINT "hotel_facilities_hotel_facility_category_id_fkey" FOREIGN KEY ("hotel_facility_category_id") REFERENCES "hotel_facility_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "hotel_images" ADD CONSTRAINT "hotel_images_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_types" ADD CONSTRAINT "room_types_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_facilities" ADD CONSTRAINT "room_facilities_room_id_fkey" FOREIGN KEY ("room_id") REFERENCES "room_types"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_facilities" ADD CONSTRAINT "room_facilities_room_facility_category_id_fkey" FOREIGN KEY ("room_facility_category_id") REFERENCES "room_facility_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_type_beds" ADD CONSTRAINT "room_type_beds_room_type_id_fkey" FOREIGN KEY ("room_type_id") REFERENCES "room_types"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_type_beds" ADD CONSTRAINT "room_type_beds_bed_category_id_fkey" FOREIGN KEY ("bed_category_id") REFERENCES "bed_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_images" ADD CONSTRAINT "room_images_room_type_id_fkey" FOREIGN KEY ("room_type_id") REFERENCES "room_types"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_price_settings" ADD CONSTRAINT "room_price_settings_room_type_id_fkey" FOREIGN KEY ("room_type_id") REFERENCES "room_types"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_price_rules" ADD CONSTRAINT "room_price_rules_room_type_id_fkey" FOREIGN KEY ("room_type_id") REFERENCES "room_types"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "room_type_inventories" ADD CONSTRAINT "room_type_inventories_room_type_id_fkey" FOREIGN KEY ("room_type_id") REFERENCES "room_types"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tours" ADD CONSTRAINT "tours_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tours" ADD CONSTRAINT "tours_departure_id_fkey" FOREIGN KEY ("departure_id") REFERENCES "destinations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_category_relations" ADD CONSTRAINT "tour_category_relations_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_category_relations" ADD CONSTRAINT "tour_category_relations_tour_category_id_fkey" FOREIGN KEY ("tour_category_id") REFERENCES "tour_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_destinations" ADD CONSTRAINT "tour_destinations_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_destinations" ADD CONSTRAINT "tour_destinations_destination_id_fkey" FOREIGN KEY ("destination_id") REFERENCES "destinations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_transportations" ADD CONSTRAINT "tour_transportations_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_transportations" ADD CONSTRAINT "tour_transportations_transportation_category_id_fkey" FOREIGN KEY ("transportation_category_id") REFERENCES "transportation_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_images" ADD CONSTRAINT "tour_images_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_departures" ADD CONSTRAINT "tour_departures_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_itineraries" ADD CONSTRAINT "tour_itineraries_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tour_itinerary_images" ADD CONSTRAINT "tour_itinerary_images_tour_itinerary_id_fkey" FOREIGN KEY ("tour_itinerary_id") REFERENCES "tour_itineraries"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "combos" ADD CONSTRAINT "combos_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "combos" ADD CONSTRAINT "combos_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "combos" ADD CONSTRAINT "combos_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "combos" ADD CONSTRAINT "combos_room_type_id_fkey" FOREIGN KEY ("room_type_id") REFERENCES "room_types"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "combo_departures" ADD CONSTRAINT "combo_departures_combo_id_fkey" FOREIGN KEY ("combo_id") REFERENCES "combos"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "combo_images" ADD CONSTRAINT "combo_images_combo_id_fkey" FOREIGN KEY ("combo_id") REFERENCES "combos"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_bank_accounts" ADD CONSTRAINT "agent_bank_accounts_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_corporate_id_fkey" FOREIGN KEY ("corporate_id") REFERENCES "corporates"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_system_voucher_id_fkey" FOREIGN KEY ("system_voucher_id") REFERENCES "system_vouchers"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_agent_promotion_id_fkey" FOREIGN KEY ("agent_promotion_id") REFERENCES "agent_promotions"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bookings" ADD CONSTRAINT "bookings_affiliate_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliate_profiles"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_hotel_details" ADD CONSTRAINT "booking_hotel_details_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_hotel_details" ADD CONSTRAINT "booking_hotel_details_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_hotel_details" ADD CONSTRAINT "booking_hotel_details_room_type_id_fkey" FOREIGN KEY ("room_type_id") REFERENCES "room_types"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_hotel_room_operations" ADD CONSTRAINT "booking_hotel_room_operations_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "booking_hotel_details"("booking_id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_tour_details" ADD CONSTRAINT "booking_tour_details_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_tour_details" ADD CONSTRAINT "booking_tour_details_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_tour_details" ADD CONSTRAINT "booking_tour_details_departure_id_fkey" FOREIGN KEY ("departure_id") REFERENCES "tour_departures"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_combo_details" ADD CONSTRAINT "booking_combo_details_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_combo_details" ADD CONSTRAINT "booking_combo_details_combo_id_fkey" FOREIGN KEY ("combo_id") REFERENCES "combos"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_combo_details" ADD CONSTRAINT "booking_combo_details_departure_id_fkey" FOREIGN KEY ("departure_id") REFERENCES "combo_departures"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_passengers" ADD CONSTRAINT "booking_passengers_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_payments" ADD CONSTRAINT "booking_payments_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_payments" ADD CONSTRAINT "booking_payments_staff_id_fkey" FOREIGN KEY ("staff_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "system_voucher_destinations" ADD CONSTRAINT "system_voucher_destinations_voucher_id_fkey" FOREIGN KEY ("voucher_id") REFERENCES "system_vouchers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "system_voucher_destinations" ADD CONSTRAINT "system_voucher_destinations_destination_id_fkey" FOREIGN KEY ("destination_id") REFERENCES "destinations"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "system_voucher_target_users" ADD CONSTRAINT "system_voucher_target_users_voucher_id_fkey" FOREIGN KEY ("voucher_id") REFERENCES "system_vouchers"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "system_voucher_target_users" ADD CONSTRAINT "system_voucher_target_users_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_promotions" ADD CONSTRAINT "agent_promotions_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_promotions" ADD CONSTRAINT "agent_promotions_moderator_id_fkey" FOREIGN KEY ("moderator_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_promotion_targets" ADD CONSTRAINT "agent_promotion_targets_promotion_id_fkey" FOREIGN KEY ("promotion_id") REFERENCES "agent_promotions"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_promotion_targets" ADD CONSTRAINT "agent_promotion_targets_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_promotion_targets" ADD CONSTRAINT "agent_promotion_targets_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agent_promotion_targets" ADD CONSTRAINT "agent_promotion_targets_combo_id_fkey" FOREIGN KEY ("combo_id") REFERENCES "combos"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_moderation_requests" ADD CONSTRAINT "product_moderation_requests_moderator_id_fkey" FOREIGN KEY ("moderator_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_moderation_requests" ADD CONSTRAINT "product_moderation_requests_agent_id_fkey" FOREIGN KEY ("agent_id") REFERENCES "agents"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_moderation_requests" ADD CONSTRAINT "product_moderation_requests_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_moderation_requests" ADD CONSTRAINT "product_moderation_requests_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "product_moderation_requests" ADD CONSTRAINT "product_moderation_requests_combo_id_fkey" FOREIGN KEY ("combo_id") REFERENCES "combos"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_combo_id_fkey" FOREIGN KEY ("combo_id") REFERENCES "combos"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_status_logs" ADD CONSTRAINT "booking_status_logs_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "booking_status_logs" ADD CONSTRAINT "booking_status_logs_changed_by_fkey" FOREIGN KEY ("changed_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dispute_tickets" ADD CONSTRAINT "dispute_tickets_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dispute_tickets" ADD CONSTRAINT "dispute_tickets_creator_id_fkey" FOREIGN KEY ("creator_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dispute_tickets" ADD CONSTRAINT "dispute_tickets_handler_id_fkey" FOREIGN KEY ("handler_id") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dispute_evidences" ADD CONSTRAINT "dispute_evidences_dispute_id_fkey" FOREIGN KEY ("dispute_id") REFERENCES "dispute_tickets"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dispute_evidences" ADD CONSTRAINT "dispute_evidences_uploaded_by_fkey" FOREIGN KEY ("uploaded_by") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dispute_messages" ADD CONSTRAINT "dispute_messages_dispute_id_fkey" FOREIGN KEY ("dispute_id") REFERENCES "dispute_tickets"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "dispute_messages" ADD CONSTRAINT "dispute_messages_sender_id_fkey" FOREIGN KEY ("sender_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "static_page_versions" ADD CONSTRAINT "static_page_versions_page_id_fkey" FOREIGN KEY ("page_id") REFERENCES "static_pages"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "static_page_versions" ADD CONSTRAINT "static_page_versions_created_by_fkey" FOREIGN KEY ("created_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blogs" ADD CONSTRAINT "blogs_category_id_fkey" FOREIGN KEY ("category_id") REFERENCES "blog_categories"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blogs" ADD CONSTRAINT "blogs_author_id_fkey" FOREIGN KEY ("author_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_products" ADD CONSTRAINT "blog_products_blog_id_fkey" FOREIGN KEY ("blog_id") REFERENCES "blogs"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_products" ADD CONSTRAINT "blog_products_hotel_id_fkey" FOREIGN KEY ("hotel_id") REFERENCES "hotels"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_products" ADD CONSTRAINT "blog_products_tour_id_fkey" FOREIGN KEY ("tour_id") REFERENCES "tours"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_products" ADD CONSTRAINT "blog_products_combo_id_fkey" FOREIGN KEY ("combo_id") REFERENCES "combos"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_comments" ADD CONSTRAINT "blog_comments_blog_id_fkey" FOREIGN KEY ("blog_id") REFERENCES "blogs"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "blog_comments" ADD CONSTRAINT "blog_comments_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "affiliate_profiles" ADD CONSTRAINT "affiliate_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "affiliate_commissions" ADD CONSTRAINT "affiliate_commissions_affiliate_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliate_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "affiliate_commissions" ADD CONSTRAINT "affiliate_commissions_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "affiliate_withdrawals" ADD CONSTRAINT "affiliate_withdrawals_affiliate_id_fkey" FOREIGN KEY ("affiliate_id") REFERENCES "affiliate_profiles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "affiliate_withdrawals" ADD CONSTRAINT "affiliate_withdrawals_processed_by_fkey" FOREIGN KEY ("processed_by") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_loyalty_profiles" ADD CONSTRAINT "user_loyalty_profiles_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_point_logs" ADD CONSTRAINT "user_point_logs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_point_logs" ADD CONSTRAINT "user_point_logs_booking_id_fkey" FOREIGN KEY ("booking_id") REFERENCES "bookings"("id") ON DELETE SET NULL ON UPDATE CASCADE;
