/*
  Warnings:

  - A unique constraint covering the columns `[name]` on the table `transportation_categories` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[slug]` on the table `transportation_categories` will be added. If there are existing duplicate values, this will fail.
  - Made the column `sort_order` on table `transportation_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `is_active` on table `transportation_categories` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "transportation_categories_name_key";

-- DropIndex
DROP INDEX "transportation_categories_slug_key";

-- AlterTable
ALTER TABLE "transportation_categories" ALTER COLUMN "sort_order" SET NOT NULL,
ALTER COLUMN "is_active" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "transportation_categories_name_key" ON "transportation_categories"("name") WHERE ("deleted_at" IS NULL);

-- CreateIndex
CREATE UNIQUE INDEX "transportation_categories_slug_key" ON "transportation_categories"("slug") WHERE ("deleted_at" IS NULL);
