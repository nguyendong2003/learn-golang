/*
  Warnings:

  - A unique constraint covering the columns `[name,slug]` on the table `tour_categories` will be added. If there are existing duplicate values, this will fail.
  - Made the column `sort_order` on table `tour_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `is_active` on table `tour_categories` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "tour_categories_name_key";

-- DropIndex
DROP INDEX "tour_categories_slug_key";

-- AlterTable
ALTER TABLE "tour_categories" ALTER COLUMN "sort_order" SET NOT NULL,
ALTER COLUMN "is_active" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "tour_categories_name_slug_key" ON "tour_categories"("name", "slug") WHERE ("deleted_at" IS NULL);
