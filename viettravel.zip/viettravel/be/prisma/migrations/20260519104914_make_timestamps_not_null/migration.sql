/*
  Warnings:

  - Made the column `created_at` on table `activity_field_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `activity_field_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `affiliate_commissions` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `affiliate_commissions` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `affiliate_profiles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `affiliate_profiles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `affiliate_withdrawals` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `affiliate_withdrawals` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `agent_bank_accounts` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `agent_bank_accounts` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `agent_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `agent_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `agent_promotion_targets` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `agent_promotion_targets` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `agent_promotions` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `agent_promotions` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `agents` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `agents` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `banners` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `banners` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `bed_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `bed_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `blog_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `blog_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `blog_comments` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `blog_comments` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `blogs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `blogs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `booking_combo_details` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `booking_combo_details` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `booking_hotel_details` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `booking_hotel_details` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `booking_hotel_room_operations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `booking_hotel_room_operations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `booking_passengers` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `booking_passengers` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `booking_payments` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `booking_payments` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `booking_status_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `booking_tour_details` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `booking_tour_details` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `bookings` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `bookings` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `combo_departures` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `combo_departures` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `combo_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `combo_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `combos` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `combos` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `corporate_contracts` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `corporate_contracts` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `corporate_employees` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `corporates` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `corporates` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `destinations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `destinations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `dispute_evidences` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `dispute_messages` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `dispute_tickets` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `dispute_tickets` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `hotel_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `hotel_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `hotel_facilities` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `hotel_facilities` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `hotel_facility_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `hotel_facility_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `hotel_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `hotel_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `hotels` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `hotels` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `meal_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `meal_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `permissions` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `permissions` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `product_moderation_requests` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `product_moderation_requests` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `reviews` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `reviews` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `roles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `roles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_facilities` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_facilities` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_facility_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_facility_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_price_rules` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_price_rules` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_price_settings` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_price_settings` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_type_beds` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_type_beds` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_type_inventories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_type_inventories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `room_types` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `room_types` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `staff_audit_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `star_rating_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `star_rating_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `static_page_versions` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `static_pages` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `static_pages` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `system_configs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `system_configs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `system_voucher_destinations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `system_voucher_destinations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `system_voucher_target_users` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `system_voucher_target_users` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `system_vouchers` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `system_vouchers` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_category_relations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_category_relations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_departures` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_departures` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_destinations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_destinations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_itineraries` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_itineraries` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_itinerary_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_itinerary_images` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tour_transportations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tour_transportations` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `tours` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `tours` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `transportation_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `transportation_categories` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `user_loyalty_profiles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `user_point_logs` required. This step will fail if there are existing NULL values in that column.
  - Made the column `name` on table `users` required. This step will fail if there are existing NULL values in that column.
  - Made the column `status` on table `users` required. This step will fail if there are existing NULL values in that column.
  - Made the column `is_affiliate` on table `users` required. This step will fail if there are existing NULL values in that column.
  - Made the column `created_at` on table `users` required. This step will fail if there are existing NULL values in that column.
  - Made the column `updated_at` on table `users` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "activity_field_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "affiliate_commissions" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "affiliate_profiles" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "affiliate_withdrawals" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "agent_bank_accounts" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "agent_images" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "agent_promotion_targets" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "agent_promotions" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "agents" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "banners" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "bed_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "blog_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "blog_comments" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "blogs" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "booking_combo_details" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "booking_hotel_details" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "booking_hotel_room_operations" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "booking_passengers" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "booking_payments" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "booking_status_logs" ALTER COLUMN "created_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "booking_tour_details" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "bookings" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "combo_departures" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "combo_images" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "combos" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "corporate_contracts" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "corporate_employees" ALTER COLUMN "created_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "corporates" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "destinations" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "dispute_evidences" ALTER COLUMN "created_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "dispute_messages" ALTER COLUMN "created_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "dispute_tickets" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "hotel_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "hotel_facilities" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "hotel_facility_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "hotel_images" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "hotels" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "meal_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "permissions" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "product_moderation_requests" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "reviews" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "roles" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_facilities" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_facility_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_images" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_price_rules" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_price_settings" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_type_beds" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_type_inventories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "room_types" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "staff_audit_logs" ALTER COLUMN "created_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "star_rating_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "static_page_versions" ALTER COLUMN "created_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "static_pages" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "system_configs" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "system_voucher_destinations" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "system_voucher_target_users" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "system_vouchers" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_category_relations" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_departures" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_destinations" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_images" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_itineraries" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_itinerary_images" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tour_transportations" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "tours" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "transportation_categories" ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "user_loyalty_profiles" ALTER COLUMN "updated_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "user_point_logs" ALTER COLUMN "created_at" SET NOT NULL;

-- AlterTable
ALTER TABLE "users" ALTER COLUMN "name" SET NOT NULL,
ALTER COLUMN "status" SET NOT NULL,
ALTER COLUMN "is_affiliate" SET NOT NULL,
ALTER COLUMN "created_at" SET NOT NULL,
ALTER COLUMN "updated_at" SET NOT NULL;
