import { PrismaPg } from '@prisma/adapter-pg'
import { seedRolePermissions } from './seeds/role-permissions.seed'
import { seedRoles } from './seeds/roles.seed'
import { seedPermissions } from './seeds/permissions.seed'
import { seedUsers } from './seeds/users.seed'
import { seedUserRoles } from './seeds/user-roles.seed'
import { seedDestinations } from './seeds/destinations.seed'
import { PrismaClient } from '@/generated/prisma/client'
import { seedCategories } from './seeds/categories.seed'
import { seedTourCategories } from './seeds/tour-categories.seed'
import { seedTransportationCategories } from './seeds/transportation-categories.seed'
import { seedTours } from './seeds/tours.seed'

const prisma = new PrismaClient({
  adapter: new PrismaPg({
    connectionString: process.env.DATABASE_URL,
  }),
})

async function main() {
  await prisma.$transaction(async (tx) => {
    const roles = await seedRoles(tx)
    const permissions = await seedPermissions(tx)
    const users = await seedUsers(tx)
    // const categories = await seedCategories(tx)

    await seedUserRoles(tx, roles, users)
    await seedRolePermissions(tx, roles, permissions)
    const destinations = await seedDestinations(tx)
    const tourCategories = await seedTourCategories(tx)
    const transportationCategories = await seedTransportationCategories(tx)
    const tours = await seedTours(tx, tourCategories, transportationCategories, destinations)
  })

  process.stdout.write('Seed completed successfully.\n')
}

main()
  .then(async () => {
    await prisma.$disconnect()
  })
  .catch(async (error) => {
    console.error(error)
    await prisma.$disconnect()
    process.exit(1)
  })
