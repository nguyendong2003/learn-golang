# Features

Business/domain modules.

Each feature owns its API calls, components, hooks, store, types, validations, constants, and public exports.
