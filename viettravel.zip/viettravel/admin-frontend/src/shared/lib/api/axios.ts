import 'client-only'

import axios from 'axios'
import {
  requestErrorHandler,
  requestInterceptor,
  responseErrorHandler,
  responseSuccessHandler,
} from './interceptors'
import { env } from '../constants'

const baseURL = env.apiUrl

if (!baseURL && process.env.NODE_ENV !== 'production') {
  console.warn('Missing NEXT_PUBLIC_API_URL. Copy .env.example to .env.local and set backend URL.')
}

const clientApi = axios.create({
  baseURL,
  timeout: 10000,
})

clientApi.interceptors.request.use(requestInterceptor, requestErrorHandler)
clientApi.interceptors.response.use(responseSuccessHandler, responseErrorHandler)

export { clientApi }
export default clientApi
