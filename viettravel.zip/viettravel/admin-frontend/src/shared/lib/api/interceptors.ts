import type { AxiosError, AxiosResponse, InternalAxiosRequestConfig } from 'axios'
import { ROUTES, STORAGE_KEYS } from '../constants'

type ApiErrorResponse = {
  message?: string
  code?: string
}

export type ApiError = {
  status?: number
  code?: string
  message: string
  originalError: AxiosError
}

export const requestInterceptor = (config: InternalAxiosRequestConfig) => {
  if (typeof window === 'undefined') {
    return config
  }

  const token = localStorage.getItem(STORAGE_KEYS.accessToken)
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }

  return config
}

export const requestErrorHandler = (error: unknown) => {
  return Promise.reject(error)
}

export const responseSuccessHandler = (response: AxiosResponse) => {
  return response.data
}

export const responseErrorHandler = (error: AxiosError) => {
  const status = error.response?.status
  const data = error.response?.data as ApiErrorResponse | undefined

  if (status === 401 && typeof window !== 'undefined') {
    localStorage.removeItem(STORAGE_KEYS.accessToken)

    if (window.location.pathname !== ROUTES.login) {
      window.location.assign(ROUTES.login)
    }
  }

  const apiError: ApiError = {
    status,
    code: data?.code ?? error.code,
    message: data?.message ?? error.message ?? 'Something went wrong',
    originalError: error,
  }

  return Promise.reject(apiError)
}
