import { QueryClient } from '@tanstack/react-query'

export const createQueryClient = () => {
  const millisecondsPerSecond = 1000
  const secondsPerMinute = 60

  return new QueryClient({
    defaultOptions: {
      queries: {
        staleTime: secondsPerMinute * millisecondsPerSecond,
        retry: 2,
      },
    },
  })
}
