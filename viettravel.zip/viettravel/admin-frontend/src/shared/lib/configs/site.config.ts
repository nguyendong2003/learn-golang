export const siteConfig = {
  name: 'VietTravel',
  description: 'VietTravel user frontend',
} as const
