import dayjs from 'dayjs'

export const formatDate = (value: string | number | Date, format = 'DD/MM/YYYY') => {
  return dayjs(value).format(format)
}
