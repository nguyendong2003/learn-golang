export const APP_NAME = 'TravelViet'
