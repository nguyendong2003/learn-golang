// Minimal admin color tokens
export const ADMIN_COLORS = {
  background: '#0b1220',
  surface: '#111827',
  surfaceMuted: '#151f2d',
  foreground: '#f8fafc',
  textPrimary: '#e2e8f0',
  textSecondary: '#cbd5e1',

  primary: '#3b82f6',
  primaryHover: '#2563eb',
  accent: '#22d3ee',

  success: '#22c55e',
  danger: '#ef4444',
  warning: '#f59e0b',

  border: '#273449',
  borderLight: '#334155',
} as const

export const DESTINATION_COLORS = {
  // keep a small set for later use
  haLong: { bg: '#0c4a6e', stripe: '#083b5a' },
  sapa: { bg: '#2d6a4f', stripe: '#1b4332' },
} as const
