# Shared

Truly reusable/global code only.

Feature-specific code belongs in `src/features/<feature>`.
