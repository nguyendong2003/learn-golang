export default function AdminDashboardPage() {
  return (
    <main className="min-h-screen bg-background px-6 py-12 text-foreground">
      <div className="mx-auto w-full max-w-6xl space-y-8">
        <div className="rounded-3xl border border-border bg-surface p-8 shadow-[var(--shadow)]">
          <p className="text-sm uppercase tracking-[0.32em] text-accent">Admin dashboard</p>
          <h1 className="mt-4 text-4xl font-semibold text-foreground">Welcome to VietTravel Admin</h1>
          <p className="mt-3 max-w-2xl text-text-secondary">This is the admin skeleton for the management interface. Build admin widgets and reports here.</p>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          {[
            { title: "Users", value: "0", description: "Manage customers and staff." },
            { title: "Bookings", value: "0", description: "Review current booking activity." },
            { title: "Approvals", value: "0", description: "Pending tours, hotels, and promotions." },
          ].map((item) => (
            <section key={item.title} className="rounded-3xl border border-border bg-surface p-6">
              <p className="text-sm font-medium uppercase tracking-[0.24em] text-text-secondary">{item.title}</p>
              <p className="mt-4 text-4xl font-semibold text-foreground">{item.value}</p>
              <p className="mt-2 text-sm leading-6 text-text-tertiary">{item.description}</p>
            </section>
          ))}
        </div>
      </div>
    </main>
  );
}
