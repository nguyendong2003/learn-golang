export default function AdminModerationPage() {
  return (
    <main className="min-h-screen bg-background px-6 py-12 text-foreground">
      <div className="mx-auto w-full max-w-5xl rounded-3xl border border-border bg-surface p-8 shadow-[var(--shadow)]">
        <p className="text-sm uppercase tracking-[0.32em] text-accent">Moderation</p>
        <h1 className="mt-4 text-3xl font-semibold text-foreground">Content moderation</h1>
        <p className="mt-2 text-text-secondary">Placeholder page for review and approval workflows.</p>
      </div>
    </main>
  );
}
