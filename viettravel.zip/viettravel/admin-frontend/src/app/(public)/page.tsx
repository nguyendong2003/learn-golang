import Link from "next/link";

export default function Home() {
  return (
    <main className="min-h-screen bg-background px-6 py-12 text-foreground">
      <div className="mx-auto flex w-full max-w-4xl flex-col gap-10 rounded-3xl border border-border bg-surface p-10 shadow-[var(--shadow)]">
        <div className="space-y-4">
          <p className="text-sm uppercase tracking-[0.3em] text-accent">VietTravel Admin</p>
          <h1 className="text-4xl font-semibold text-foreground">Admin panel skeleton is ready.</h1>
          <p className="max-w-2xl text-base leading-7 text-text-secondary">
            This admin frontend is using a management-oriented skeleton. Navigate to login to begin building the admin dashboard.
          </p>
        </div>

        <div className="flex flex-col gap-4 sm:flex-row">
          <Link
            href="/auth/login"
            className="inline-flex items-center justify-center rounded-full bg-primary px-6 py-3 text-sm font-semibold text-white transition hover:bg-primary-hover"
          >
            Go to Login
          </Link>
          <Link
            href="/admin/dashboard"
            className="inline-flex items-center justify-center rounded-full border border-border px-6 py-3 text-sm font-semibold text-foreground transition hover:bg-surface-muted"
          >
            Preview Dashboard
          </Link>
        </div>
      </div>
    </main>
  );
}
