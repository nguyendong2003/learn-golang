import Link from "next/link";

export default function LoginPage() {
  return (
    <main className="min-h-screen bg-background px-6 py-12 text-foreground">
      <div className="mx-auto w-full max-w-lg rounded-3xl border border-border bg-surface p-10 shadow-[var(--shadow)]">
        <div className="mb-8 space-y-3">
          <p className="text-sm uppercase tracking-[0.32em] text-accent">Admin login</p>
          <h1 className="text-3xl font-semibold text-foreground">Sign in to VietTravel Admin</h1>
          <p className="text-text-secondary">Use your admin credentials to access the management dashboard.</p>
        </div>

        <form className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-text-secondary">Email</label>
            <input
              type="email"
              placeholder="admin@example.com"
              className="w-full rounded-2xl border border-border bg-surface-muted px-4 py-3 text-foreground outline-none transition focus:border-primary"
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-text-secondary">Password</label>
            <input
              type="password"
              placeholder="••••••••"
              className="w-full rounded-2xl border border-border bg-surface-muted px-4 py-3 text-foreground outline-none transition focus:border-primary"
            />
          </div>

          <button
            type="button"
            className="w-full rounded-2xl bg-primary px-4 py-3 text-sm font-semibold text-white transition hover:bg-primary-hover"
          >
            Sign in
          </button>
        </form>

        <p className="mt-8 text-center text-sm text-text-tertiary">
          Or return to <Link href="/" className="text-accent underline">home</Link>.
        </p>
      </div>
    </main>
  );
}
