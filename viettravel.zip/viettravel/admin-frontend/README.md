# VietTravel Admin Frontend

Admin panel for the VietTravel management system.

## Tech Stack

- Next.js 16 App Router
- React 19
- TypeScript
- Tailwind CSS 4
- TanStack Query
- Axios
- React Hook Form
- Zod
- Zustand
- Day.js
- pnpm

## Requirements

- Node.js 20+
- pnpm

## Installation

Install dependencies:

```bash
pnpm install
```

Create local environment file:

```bash
cp .env.example .env.local
```

Update `.env.local`:

```env
NEXT_PUBLIC_API_URL=http://localhost:8080/api
```

Run development server:

```bash
pnpm dev
```

Open:

```txt
http://localhost:3000
```

## Scripts

```bash
pnpm dev
pnpm build
pnpm start
pnpm lint
pnpm typecheck
```

## Project Structure

```txt
src/
  app/                # Next.js App Router
    (public)/         # Public landing / redirect page
    (auth)/           # Auth routes for admin login
    (admin)/          # Admin routes and dashboard
    layout.tsx
    providers.tsx
    globals.css

  features/           # Admin feature modules
    auth/
    dashboard/
    users/
    agents/
    bookings/
    moderation/
    finance/
    settings/

  shared/             # Reusable global code
    ui/               # Generic UI components
    layouts/          # Shared layouts
    lib/
      api/            # Axios, interceptors, query client
      constants/      # App constants, routes, storage keys, env
      utils/          # Shared utilities
    types/            # Shared TypeScript types
    validations/      # Shared Zod schemas

  assets/
    fonts/
```

## Admin Skeleton

This project currently provides an admin-oriented skeleton with:

- admin color palette and global styles
- login and dashboard page placeholders
- route groups for auth and admin
- shared providers for React Query

## Common Setup

### API Client

Shared API setup lives in:

```txt
src/shared/lib/api/
  axios.ts
  interceptors.ts
  query-client.ts
  index.ts
```

Use:

```ts
import { apiClient } from '@/shared/lib/api'
```

### React Query

The shared query client is created in:

```txt
src/shared/lib/api/query-client.ts
```

It is mounted in:

```txt
src/app/providers.tsx
```

### Push checklist

Before pushing or opening a PR, run the checks and confirm the items below:

```bash
pnpm lint
pnpm typecheck
pnpm build
```

- `.gitignore` excludes `node_modules`, `.next`, and build/cache
- No leftover root `node_modules` or unwanted `pnpm-lock.yaml` at workspace root
- `.env.example` present and `.env.local` is not committed

Recommended commit message: `chore(admin): init admin frontend skeleton`

### Validation Before Commit

Run:

```bash
pnpm lint
pnpm typecheck
pnpm build
```

## Code Organization Rules

- Keep route files inside `src/app`.
- Keep feature-specific logic inside `src/features/<feature>`.
- Keep reusable UI in `src/shared/ui`.
- Keep shared layouts in `src/shared/layouts`.
- Keep shared non-UI logic in `src/shared/lib`.
- Do not move code to `shared` until at least two features need it.
- Do not hardcode API URLs, storage keys, routes, or shared colors in feature code.

## Validation Before Commit

Run:

```bash
pnpm lint
pnpm typecheck
pnpm build
```
