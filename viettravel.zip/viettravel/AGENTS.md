# AGENTS.md

This file is the **mandatory starting point**. Read it before performing any task.

## Stack (locked)

| Layer      | Tech                       | Version  |
| ---------- | -------------------------- | -------- |
| Runtime    | Node.js                    | 22 LTS   |
| Framework  | NestJS                     | ^11      |
| ORM        | Prisma                     | ^6       |
| Database   | PostgreSQL                 | 17       |
| Validation | Zod + nestjs-zod           | ^3 / ^4  |
| Queue      | BullMQ + ioredis           | ^5       |
| Auth       | @nestjs/jwt + passport-jwt | ^11 / ^4 |
| Logging    | nestjs-pino                | ^4       |
| Rate limit | @nestjs/throttler          | ^6       |

## Apps

```
apps/api/        → NestJS backend (port 3001)
packages/types/  → Zod schemas — source of truth for FE + BE
```

## Non-negotiable rules

1. **Schema-first:** modify Zod (`packages/types/`) first → then Prisma + DTO
2. **Every endpoint** must have `@Roles()` + ownership check in service
3. **Every mutation** by admin/agent must write `AuditLog`
4. **Multi-step write** must use `prisma.$transaction`
5. **Soft delete** (`deletedAt`), never hard delete
6. **VND currency** store as `Int` type (don't use `Float`/`Decimal`)
7. **Datetime** store UTC, display `Asia/Ho_Chi_Minh`
8. Don't use `class-validator` / `class-transformer`
9. Don't use `console.log` — use `new Logger(ClassName.name)`
10. Don't use `throw new Error(string)` — use `BusinessException(ErrorCode.XXX)`
11. Don't read `process.env.X` outside `config/env.schema.ts`

## Skills index

| When                             | Skill to read                            |
| -------------------------------- | ---------------------------------------- |
| Start any BE task                | `.agent/skills/plan-task/SKILL.md`       |
| Write service / controller / DTO | `.agent/skills/coding-patterns/SKILL.md` |
| Create new module                | `.agent/skills/create-module/SKILL.md`   |
| Auth, guard, role, JWT           | `.agent/skills/auth-rbac/SKILL.md`       |
| Validate input, Zod schema       | `.agent/skills/validation/SKILL.md`      |
| Handle errors, exception filter  | `.agent/skills/error-handling/SKILL.md`  |
| Prisma schema, migration         | `.agent/skills/database/SKILL.md`        |
| Write unit test / e2e test       | `.agent/skills/testing/SKILL.md`         |

## Standard Workflow

```
1. Read FRD → record FR-xxx, BR-xx, Actor, Pre/Postconditions, Error cases
2. Update Zod schema  (packages/types/src/schemas/)
3. Update Prisma schema + create migration
4. Write DTO  (createZodDto wrapper)
5. Write Service  (business logic + transaction + audit)
6. Write Controller  (thin, @Roles required)
7. Write unit test (.spec.ts) + e2e test (.e2e-spec.ts)
8. pnpm lint && pnpm type-check && pnpm test
9. Commit: feat(module): FR-xxx short description
```

## Commit convention

```
feat(tours):    FR-AG-007 agent creates new tour
fix(bookings):  BR-14 calculate cancellation fee after 24h
refactor(auth): extract TokensService to separate module
test(payments): add e2e test happy path VNPay
```
