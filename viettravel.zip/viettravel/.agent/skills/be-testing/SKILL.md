---
name: testing
description: Unit test (service) and e2e test (controller) patterns with Jest + Supertest + Prisma test DB. Use when writing tests for any service/controller.
---

# Testing

## When to use

- Use this skill when writing or updating service unit tests and controller e2e tests.
- Use it together with `coding-patterns` for the implementation and `database` when test data depends on Prisma models.

## Inputs needed

- Target module and behavior under test
- Service method or controller route name
- Main success path and expected error cases
- Required auth role and ownership rules
- Whether the test needs Prisma, audit, queue, or other providers

## Core rules

- Unit test services with mocked Prisma and providers.
- E2E test controllers with real DB and real auth flow.
- Do not mock Prisma in e2e tests.
- Reset test DB between e2e tests.
- Test behavior, not implementation details.
- Cover at least one happy path and the main failure cases.

## Stack

- Unit: **Jest 29** + `@nestjs/testing`
- E2E: **Supertest** + Jest + test DB (`travel_test`)
- Don't mock Prisma in e2e — test with real DB

## File layout

```
src/modules/tours/
├── tours.service.ts
├── tours.service.spec.ts       # unit — mock Prisma
└── tours.controller.spec.ts    # unit — mock Service
test/
├── tours.e2e-spec.ts
├── helpers/
│   ├── test-app.ts
│   ├── auth.helper.ts           # login → JWT token
│   └── factories/
│       ├── user.factory.ts
│       └── tour.factory.ts
└── jest-e2e.json
```

## File targets

- `*.service.spec.ts` → service unit tests
- `*.controller.spec.ts` → controller unit tests
- `test/*.e2e-spec.ts` → controller e2e tests
- `test/helpers/*` → shared test helpers and factories

## Unit test — service

```ts
// tours.service.spec.ts
import { Test } from "@nestjs/testing";
import { ToursService } from "./tours.service";
import { PrismaService } from "@/prisma/prisma.service";
import { AuditService } from "@/modules/audit/audit.service";

const prismaMock = {
  tour: {
    create: jest.fn(),
    findFirst: jest.fn(),
    findMany: jest.fn(),
    count: jest.fn(),
    update: jest.fn(),
  },
  agent: { findUnique: jest.fn() },
  $transaction: jest.fn((fn) => fn(prismaMock)),
};

describe("ToursService", () => {
  let service: ToursService;
  const auditMock = { log: jest.fn() };

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [
        ToursService,
        { provide: PrismaService, useValue: prismaMock },
        { provide: AuditService, useValue: auditMock },
      ],
    }).compile();

    service = module.get(ToursService);
    jest.clearAllMocks();
  });

  describe("create", () => {
    it("creates tour and writes audit log", async () => {
      const agent = { id: "agent-1" };
      const tour = { id: "tour-1", name: "Ha Long", agentId: "agent-1" };
      prismaMock.agent.findUnique.mockResolvedValue(agent);
      prismaMock.tour.create.mockResolvedValue(tour);

      const result = await service.create(
        { id: "user-1", agentId: "agent-1", role: "AGENT" },
        {
          name: "Ha Long",
          basePrice: 1_500_000,
          maxSeats: 20,
          departureDate: "2027-01-01",
          departureCityId: "city-1",
        },
      );

      expect(result.id).toBe("tour-1");
      expect(prismaMock.$transaction).toHaveBeenCalled();
      expect(auditMock.log).toHaveBeenCalledWith(
        expect.objectContaining({ action: "TOUR_CREATE" }),
      );
    });

    it("throws AGENT_NOT_FOUND when agent does not exist", async () => {
      prismaMock.agent.findUnique.mockResolvedValue(null);

      await expect(
        service.create(
          { id: "u1", agentId: "a1", role: "AGENT" },
          {
            name: "X",
            basePrice: 1,
            maxSeats: 1,
            departureDate: "2027-01-01",
            departureCityId: "c1",
          },
        ),
      ).rejects.toMatchObject({ code: "AGENT_NOT_FOUND" });
    });
  });
});
```

## Test patterns

- Arrange mocks first, then act, then assert.
- Use `jest.clearAllMocks()` in `beforeEach`.
- Keep one business rule per test.
- Prefer explicit error assertions with `rejects.toMatchObject`.
- Mock external providers at the boundary only.

## E2E test — controller

```ts
// test/tours.e2e-spec.ts
import * as request from "supertest";
import { INestApplication } from "@nestjs/common";
import { PrismaService } from "@/prisma/prisma.service";
import { createTestApp, resetDatabase } from "./helpers/test-app";
import { loginAs } from "./helpers/auth.helper";

describe("Tours (e2e)", () => {
  let app: INestApplication;
  let prisma: PrismaService;
  let agentToken: string;

  beforeAll(async () => {
    ({ app, prisma } = await createTestApp());
  });

  afterAll(async () => {
    await app.close();
  });

  beforeEach(async () => {
    await resetDatabase(prisma);
    agentToken = await loginAs(app, "agent");
  });

  it("POST /api/v1/tours → 201", async () => {
    const res = await request(app.getHttpServer())
      .post("/api/v1/tours")
      .set("Authorization", `Bearer ${agentToken}`)
      .send({
        name: "Ha Long Tour",
        basePrice: 1_500_000,
        maxSeats: 20,
        departureDate: "2027-06-01",
        departureCityId: "city-1",
      });

    expect(res.status).toBe(201);
    expect(res.body.data).toMatchObject({
      name: "Ha Long Tour",
      status: "DRAFT",
    });
  });

  it("POST /api/v1/tours → 401 without token", async () => {
    const res = await request(app.getHttpServer())
      .post("/api/v1/tours")
      .send({ name: "X" });
    expect(res.status).toBe(401);
  });
});
```

## E2E rules

- Use Supertest against the real Nest app.
- Login for real to get a token.
- Reset DB before each test.
- Test 1 happy path and the most important auth / validation failures.

## Test helpers

```ts
// test/helpers/test-app.ts
export async function createTestApp() {
  const moduleRef = await Test.createTestingModule({
    imports: [AppModule],
  }).compile();
  const app = moduleRef.createNestApplication();
  app.useGlobalPipes(new ZodValidationPipe());
  app.setGlobalPrefix("api/v1");
  app.useGlobalFilters(new AllExceptionsFilter());
  await app.init();
  const prisma = app.get(PrismaService);
  return { app, prisma };
}

export async function resetDatabase(prisma: PrismaService) {
  const tables = await prisma.$queryRaw<{ tablename: string }[]>`
    SELECT tablename FROM pg_tables
    WHERE schemaname = 'public' AND tablename != '_prisma_migrations'
  `;
  for (const { tablename } of tables) {
    await prisma.$executeRawUnsafe(
      `TRUNCATE TABLE "${tablename}" RESTART IDENTITY CASCADE;`,
    );
  }
}
```

```ts
// test/helpers/auth.helper.ts
export async function loginAs(app: INestApplication, role: 'agent' | 'admin' | 'user') {
  const credentials = { agent: { email: 'agent@test.com', password: 'Test@1234' }, ... };
  const res = await request(app.getHttpServer())
    .post('/api/v1/auth/login')
    .send(credentials[role]);
  return res.body.data.accessToken;
}
```

## .env.test

```dotenv
NODE_ENV=test
DATABASE_URL=postgresql://travel:travel@localhost:5432/travel_test
REDIS_HOST=localhost
REDIS_PORT=6379
JWT_ACCESS_SECRET=test-access-secret-32-chars-min!!
JWT_REFRESH_SECRET=test-refresh-secret-32-chars-min!
```

## Anti-patterns

- ❌ Mocking Prisma in e2e tests
- ❌ Writing tests that assert internal implementation instead of behavior
- ❌ Testing too many cases in one test
- ❌ Forgetting to reset the DB between e2e tests
- ❌ Omitting the auth flow in controller tests that require roles
