---
name: coding-patterns
description: Agent-ready backend coding patterns for services, controllers, DTOs, transactions, pagination, audit logs, and jobs queues. Use when implementing NestJS backend code.
---

# Coding Patterns

## When to use

- Use this skill before writing or changing NestJS backend code.
- Prefer it when the task touches service logic, controller design, DTOs, Prisma access, audit logs, or BullMQ jobs.
- Do not use it as a replacement for domain FRD or module-specific skills; use it together with the relevant domain skill.

## Project rules

- Follow schema-first: update Zod in `packages/types/` before DTOs or Prisma changes.
- Every endpoint must have `@Roles()` and ownership checks in the service.
- Every admin/agent mutation must write `AuditLog`.
- Multi-step writes must use `prisma.$transaction`.
- Use soft delete with `deletedAt`; never hard delete.
- Store VND as `Int`, not `Float` or `Decimal`.
- Store datetime in UTC and display in `Asia/Ho_Chi_Minh`.
- Do not use `class-validator` or `class-transformer`.
- Do not read `process.env.X` outside `config/env.schema.ts`.
- Use `new Logger(ClassName.name)` instead of `console.log`.
- Throw `BusinessException(ErrorCode.XXX)`, not raw `Error`.

## Implementation flow

1. Identify the FR, BR, actor, ownership boundary, and side effects.
2. Choose the data model and update Zod first if the contract changes.
3. Implement service logic with transaction, audit, and idempotency where needed.
4. Keep the controller thin: auth, roles, param parsing, and delegation only.
5. Add tests for the main happy path and the important business rule / failure path.

## Service template

```ts
@Injectable()
export class ToursService {
  private readonly logger = new Logger(ToursService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  /** FR-AG-007 — Agent creates tour. BR-71: departureDate > now() */
  async create(actor: AuthUser, dto: CreateTourDto) {
    const tour = await this.prisma.$transaction(async (tx) => {
      const agent = await tx.agent.findUnique({ where: { id: actor.agentId } });
      if (!agent) throw new BusinessException(ErrorCode.AGENT_NOT_FOUND);

      // BR-71
      if (new Date(dto.departureDate) <= new Date()) {
        throw new BusinessException(ErrorCode.INVALID_DEPARTURE_DATE);
      }

      return tx.tour.create({
        data: { ...dto, agentId: agent.id, status: "DRAFT" },
      });
    });

    await this.audit.log({
      actorId: actor.id,
      action: "TOUR_CREATE",
      targetId: tour.id,
    });
    this.logger.log({ tourId: tour.id }, "Tour created");
    return tour;
  }
}
```

**Rules:**

- `new Logger(ClassName.name)` — 1 instance per class
- `$transaction` when write > 1 model
- `audit.log()` for every admin/agent mutation
- Don't receive raw `Request` — controller passes typed params
- Keep business validation in the service, not the controller
- Use `BusinessException(ErrorCode.XXX)` for expected failures

## Controller template

```ts
@ApiTags("tours")
@ApiBearerAuth()
@Controller("tours")
@UseGuards(JwtAuthGuard, RolesGuard)
export class ToursController {
  constructor(private readonly tours: ToursService) {}

  @Post()
  @Roles(UserRole.AGENT)
  @HttpCode(201)
  create(@CurrentUser() actor: AuthUser, @Body() dto: CreateTourDto) {
    return this.tours.create(actor, dto);
  }

  @Get()
  @Roles(UserRole.AGENT, UserRole.ADMIN, UserRole.USER)
  findAll(@Query() query: QueryTourDto) {
    return this.tours.findAll(query);
  }

  @Get(":id")
  @Roles(UserRole.AGENT, UserRole.ADMIN, UserRole.USER)
  findOne(@Param("id") id: string, @CurrentUser() actor: AuthUser) {
    return this.tours.findOne(id, actor);
  }

  @Patch(":id")
  @Roles(UserRole.AGENT)
  update(
    @Param("id") id: string,
    @CurrentUser() actor: AuthUser,
    @Body() dto: UpdateTourDto,
  ) {
    return this.tours.update(id, actor, dto);
  }

  @Delete(":id")
  @Roles(UserRole.AGENT, UserRole.ADMIN)
  @HttpCode(204)
  remove(@Param("id") id: string, @CurrentUser() actor: AuthUser) {
    return this.tours.remove(id, actor);
  }
}
```

## DTO template

```ts
// 1. Schema — packages/types/src/schemas/tour.schema.ts
export const CreateTourSchema = z.object({
  name: z.string().min(3).max(200),
  basePrice: z.number().int().positive(), // VND
  maxSeats: z.number().int().min(1).max(500),
  departureDate: z.string().date(), // BR-71
  departureCityId: z.string().cuid(),
});
export type CreateTourInput = z.infer<typeof CreateTourSchema>;

// 2. DTO — apps/api/src/modules/tours/dto/create-tour.dto.ts
export class CreateTourDto extends createZodDto(CreateTourSchema) {}

// 3. Update DTO
export class UpdateTourDto extends createZodDto(CreateTourSchema.partial()) {}
```

## Paginated list

```ts
async findAll(query: QueryTourDto) {
  const { page = 1, limit = 20, search, status } = query;
  const where = {
    deletedAt: null,
    ...(status && { status }),
    ...(search && { name: { contains: search, mode: 'insensitive' as const } }),
  };

  const [items, total] = await Promise.all([
    this.prisma.tour.findMany({
      where,
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' },
    }),
    this.prisma.tour.count({ where }),
  ]);

  return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
}
```

## Ownership check

```ts
async findOne(id: string, actor: AuthUser) {
  const tour = await this.prisma.tour.findUnique({ where: { id, deletedAt: null } });
  if (!tour) throw new BusinessException(ErrorCode.TOUR_NOT_FOUND);

  if (actor.role === UserRole.AGENT && tour.agentId !== actor.agentId) {
    throw new BusinessException(ErrorCode.FORBIDDEN_OWNERSHIP);
  }
  return tour;
}
```

## Soft delete

```ts
async remove(id: string, actor: AuthUser) {
  await this.findOne(id, actor); // ownership check
  await this.prisma.tour.update({ where: { id }, data: { deletedAt: new Date() } });
  await this.audit.log({ actorId: actor.id, action: 'TOUR_DELETE', targetId: id });
}
```

## Logging format

```ts
this.logger.log({ bookingId, userId }, "Booking confirmed"); // object first
this.logger.warn({ retries, jobId }, "Email retry limit");
this.logger.error({ err, context }, "Payment webhook failed");
// Don't log PII: email, phone, passwordHash
```

## Jobs queue template

```ts
// jobs/queues.ts
export const QUEUE = {
  EMAIL: "email",
  BOOKING_EXPIRY: "booking-expiry",
  COMMISSION: "commission",
  AUDIT: "audit",
} as const;
```

```ts
// jobs/jobs.module.ts
@Module({
  imports: [
    BullModule.forRootAsync({
      useFactory: (config: ConfigService) => ({
        connection: {
          host: config.get("REDIS_HOST"),
          port: config.get<number>("REDIS_PORT"),
          password: config.get("REDIS_PASSWORD"),
        },
      }),
      inject: [ConfigService],
    }),
    BullModule.registerQueue(
      { name: QUEUE.EMAIL },
      { name: QUEUE.BOOKING_EXPIRY },
      { name: QUEUE.COMMISSION },
      { name: QUEUE.AUDIT },
    ),
  ],
})
export class JobsModule {}
```

```ts
@Processor(QUEUE.EMAIL, { concurrency: 5 })
export class EmailProcessor extends WorkerHost {
  private readonly logger = new Logger(EmailProcessor.name);

  constructor(private readonly mailer: MailerService) {
    super();
  }

  async process(job: Job<EmailJobData>) {
    await this.mailer.send(job.data);
    return { sentAt: new Date().toISOString() };
  }

  @OnWorkerEvent("failed")
  onFailed(job: Job<EmailJobData>, err: Error) {
    this.logger.error(
      { jobId: job.id, attempts: job.attemptsMade, err },
      "Email job failed",
    );
  }
}
```

```ts
// producer
await this.emailQueue.add(
  "booking-confirmation",
  {
    to: booking.user.email,
    template: "booking-confirmation",
    payload: { bookingCode: booking.code },
  },
  {
    attempts: 3,
    backoff: { type: "exponential", delay: 5000 },
    removeOnComplete: { age: 24 * 3600 },
    removeOnFail: { age: 7 * 24 * 3600 },
    jobId: `booking:${booking.id}:confirmation`,
  },
);
```

**Rules:**

- Use BullMQ for async, delayed, scheduled, or retryable work
- Keep HTTP handlers thin: enqueue and return quickly when possible
- Put business logic in services, not processors
- Always set `attempts`, `backoff`, and `removeOnComplete` for external calls
- Use deterministic `jobId` for idempotency when duplicate jobs must be skipped
- Use `Logger`, not `console.log`, inside processors

## Anti-patterns

- ❌ Putting business logic in controllers or processors
- ❌ Skipping ownership checks because the endpoint is already authenticated
- ❌ Writing directly to multiple models without a transaction
- ❌ Returning raw Prisma objects when the endpoint needs a stable response shape
- ❌ Using `throw new Error()` for expected validation or business failures
- ❌ Forgetting audit logs for admin or agent mutations
- ❌ Using hard delete instead of soft delete
- ❌ Adding queue jobs without retry, backoff, or idempotency when duplicates matter
