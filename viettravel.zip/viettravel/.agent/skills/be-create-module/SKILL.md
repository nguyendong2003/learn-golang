---
name: create-module
description: Create new NestJS feature module from scratch — correct structure, correct order. Use when adding new domain entity (tours, hotels, bookings, vouchers...).
---

# Create New Feature Module

## When to use

- Use this skill when creating a new backend feature module from scratch.
- Prefer it for new domain entities like tours, hotels, bookings, vouchers, or any new API feature that needs schema, DTOs, service, controller, and tests.

## Inputs needed

- Domain name and feature name
- Actor and ownership rules
- Prisma fields and relations
- Whether the module needs audit logs, queue jobs, or external providers

## File creation order (don't change)

```
1. packages/types/src/schemas/<entity>.schema.ts   ← Zod schema
2. apps/api/prisma/schema.prisma                   ← Prisma model
3. migration: pnpm --filter api prisma migrate dev --name add_<entity>
4. src/modules/<feature>/dto/create-<entity>.dto.ts
5. src/modules/<feature>/dto/update-<entity>.dto.ts
6. src/modules/<feature>/dto/query-<entity>.dto.ts
7. src/modules/<feature>/<feature>.service.ts
8. src/modules/<feature>/<feature>.controller.ts
9. src/modules/<feature>/<feature>.module.ts
10. app.module.ts  ← add import
11. <feature>.service.spec.ts  +  <feature>.e2e-spec.ts
```

## Folder structure

```
src/modules/bookings/
├── dto/
│   ├── create-booking.dto.ts
│   ├── update-booking.dto.ts
│   └── query-booking.dto.ts
├── bookings.controller.ts
├── bookings.service.ts
├── bookings.module.ts
├── bookings.service.spec.ts
└── bookings.e2e-spec.ts
```

## Module template

```ts
// bookings.module.ts
@Module({
  imports: [PrismaModule, AuditModule],
  controllers: [BookingsController],
  providers: [BookingsService],
  exports: [BookingsService], // only export if other module needs injection
})
export class BookingsModule {}
```

```ts
// app.module.ts — add to imports[]
@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true, validate: validateEnv }),
    PrismaModule,
    AuditModule,
    BookingsModule, // ← add here
  ],
})
export class AppModule {}
```

## Module wiring rules

- Module A needs ServiceB → `BModule` must `exports: [BService]`, `AModule` must `imports: [BModule]`
- Don't inject `PrismaService` cross-module to access another module's table — use that module's service
- Avoid `forwardRef` — if needed, extract shared logic to new module (example: `NotificationsModule`)

## Anti-patterns

- ❌ Creating the controller before the schema and Prisma model
- ❌ Skipping DTO files because the schema already exists
- ❌ Injecting `PrismaService` across modules instead of using the owning module
- ❌ Adding `forwardRef` when a small shared module would be cleaner
- ❌ Forgetting to register the new module in `app.module.ts`
- ❌ Missing tests after generating the module

## Checklist

```
- [ ] Zod schema in packages/types
- [ ] Prisma model + migration
- [ ] 3 DTO files (create, update, query)
- [ ] Service with @Injectable, Logger, constructor inject
- [ ] Controller with @ApiTags, @ApiBearerAuth, @UseGuards, @Roles on every route
- [ ] Module file with imports/controllers/providers/exports
- [ ] Register in app.module.ts
- [ ] Unit test + e2e test
```
