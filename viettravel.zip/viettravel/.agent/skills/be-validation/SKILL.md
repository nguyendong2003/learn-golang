---
name: validation
description: Validate input with Zod + nestjs-zod. Patterns for request body, query params, path params, env vars. Don't use class-validator.
---

# Validation with Zod + nestjs-zod

## When to use

- Use this skill when defining or changing request validation, env validation, or DTO wrappers.
- Use it together with `coding-patterns` for DTO/controller usage and `database` when the schema change affects Prisma.

## Inputs needed

- Target route or payload name
- Required fields and business rules
- Query params, sort, and pagination needs
- Env variables and defaults
- Any enum or relation source of truth

## Core rules

- Define Zod schemas once in `packages/types/src/schemas/`.
- Use `createZodDto(Schema)` in `apps/api`.
- Do not use `class-validator` or `class-transformer`.
- Coerce query params that arrive as strings.
- Keep env validation in `config/env.schema.ts`.

## Principles

1. Zod Schema defined once in `packages/types/src/schemas/`
2. DTO in `apps/api` is just wrapper `createZodDto(Schema)`
3. Never use `@IsString()`, `@IsNotEmpty()` (class-validator removed)

## Schema patterns

- Keep schema names aligned with the use case: `Create*`, `Update*`, `Query*`.
- Keep business constraints in Zod so controllers stay thin.

**Pattern**

```ts
import { z } from "zod";
import { TourStatus } from "../enums/tour-status.enum";

export const CreateTourSchema = z.object({
  name: z.string().min(3).max(200),
  description: z.string().max(5000).optional(),
  basePrice: z.number().int().positive(),
  maxSeats: z.number().int().min(1).max(500),
  departureDate: z.string().date(),
  departureCityId: z.string().cuid(),
});

export const UpdateTourSchema = CreateTourSchema.partial();

export const QueryTourSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  status: z.nativeEnum(TourStatus).optional(),
  search: z.string().max(200).optional(),
  sortBy: z.enum(["createdAt", "basePrice", "name"]).default("createdAt"),
  order: z.enum(["asc", "desc"]).default("desc"),
});

export type CreateTourInput = z.infer<typeof CreateTourSchema>;
export type UpdateTourInput = z.infer<typeof UpdateTourSchema>;
export type QueryTourInput = z.infer<typeof QueryTourSchema>;
```

## DTO wrapper

- DTO files should only wrap the schema.

**Pattern**

```ts
import { createZodDto } from "nestjs-zod";
import { CreateTourSchema } from "@repo/types";

export class CreateTourDto extends createZodDto(CreateTourSchema) {}
export class UpdateTourDto extends createZodDto(UpdateTourSchema) {}
export class QueryTourDto extends createZodDto(QueryTourSchema) {}
```

## Global pipe (main.ts — already setup)

```ts
app.useGlobalPipes(new ZodValidationPipe());
```

When validation fails → automatically returns `400` with format:

```json
{ "error": { "code": "VALIDATION_FAILED", "message": "...", "details": [...] } }
```

## Env validation

- Keep all environment parsing in one schema and one `validateEnv` function.

**Pattern**

```ts
import { z } from "zod";

const EnvSchema = z.object({
  NODE_ENV: z
    .enum(["development", "test", "production"])
    .default("development"),
  PORT: z.coerce.number().default(3001),
  DATABASE_URL: z.string().url(),
  REDIS_HOST: z.string().default("localhost"),
  REDIS_PORT: z.coerce.number().default(6379),
  JWT_ACCESS_SECRET: z.string().min(32),
  JWT_REFRESH_SECRET: z.string().min(32),
  JWT_ACCESS_TTL: z.string().default("15m"),
  JWT_REFRESH_TTL: z.string().default("30d"),
  MAIL_FROM: z.string().email(),
});

export type Env = z.infer<typeof EnvSchema>;
export const validateEnv = (config: Record<string, unknown>) =>
  EnvSchema.parse(config);
```

## Common Zod refinements

- Future date: `z.coerce.date().refine((d) => d > new Date(), "Must be future date")`
- VND amount: `z.number().int().positive()`
- ID: `z.string().cuid()`
- Enum: `z.nativeEnum(BookingStatus)`
- Optional URL: `z.string().url().optional()`
- Array with size bounds: `z.array(z.string()).min(1).max(10)`

## Query params — coerce

Query string always string → use `z.coerce.*` for numbers and booleans:

```ts
page: z.coerce.number().int().min(1).default(1),
isActive: z.coerce.boolean().default(true),
```

## Anti-patterns

- ❌ Duplicating the same schema logic in DTOs and services
- ❌ Using `class-validator` decorators anywhere in the backend
- ❌ Forgetting `z.coerce.*` for query params
- ❌ Parsing env vars directly outside `env.schema.ts`
- ❌ Letting controllers contain validation logic that belongs in Zod
