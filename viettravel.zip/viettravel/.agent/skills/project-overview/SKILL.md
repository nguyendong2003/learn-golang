---
name: project-overview
description: Provides high-level context for the Vietnam travel marketplace (booking tours, hotels, combos). Use when starting a new task, onboarding, or when needing business context, actors, scope, or FRD references.
---

# Project Overview — Tour & Hotel Booking System

## Purpose

A **domestic Vietnam** marketplace connecting:

- **Customers** who want to travel within the country
- **Agents** (hotel owners / tour operators) who supply services

The platform mediates: search → booking → agent confirmation → customer payment → agent payment confirmation → completion.

## Scope

| ✅ In scope                   | ❌ Out of scope                       |
| ----------------------------- | ------------------------------------- |
| Domestic tour / hotel / combo | International tour or hotel           |
| Booking, moderation, reviews  | Online payment gateway                |
| AI advisory chatbot           | Enterprise accounting                 |
| Affiliate, corporate booking  | Agent HRM                             |
| Google Maps integration       | Standalone flight tickets             |
| VND, domestic flight segments | Multi-currency, international flights |

> **CRITICAL:** The system **does not process online payments**. Payment happens outside the system (bank transfer directly to the agent). The system only records status and agent confirmations.

## Actors

| Actor                    | Description                                           |
| ------------------------ | ----------------------------------------------------- |
| **Guest**                | Not registered — browse, search, AI chat              |
| **User**                 | Registered individual — book, review, loyalty         |
| **Corporate customer**   | Group bookings under contract                         |
| **Affiliate (referrer)** | Share links for commission                            |
| **Hotel agent**          | Hotel / homestay / resort                             |
| **Tour agent**           | Tour operating company                                |
| **Admin**                | Full system administration                            |
| **Staff**                | Support staff (created by Admin, limited permissions) |

## Business model

```
┌─────────────┐      ┌──────────────────┐      ┌─────────────┐
│   User      │ ───▶ │   Web platform   │ ◀─── │   Agent     │
│  (Customer) │      │                  │      │ (Hotel/Tour)│
└─────────────┘      └────────┬─────────┘      └─────────────┘
                              │
                              ▼
                       ┌──────────────┐
                       │    Admin     │
                       │ (Operations) │
                       └──────────────┘
```

**Platform revenue:** commission % on each `COMPLETED` booking. Default 10%, overridable by product type / agent.

## Main modules

| Module                                          | Side          | Related skill                                 |
| ----------------------------------------------- | ------------- | --------------------------------------------- |
| User / agent / affiliate / corporate management | Admin         | `domain-rbac-matrix`                          |
| Product / review / promotion moderation         | Admin         | `domain-product-state-machine`                |
| System-wide booking management                  | Admin         | `domain-booking-state-machine`                |
| Commission + reconciliation                     | Admin / Agent | `domain-frd-reference` (FR-AD-016, FR-AG-018) |
| Voucher + loyalty                               | Admin         | FR-AD-019, FR-AD-020                          |
| Hotel + room types + pricing + inventory        | Agent         | FR-AG-003..006                                |
| Tour + departures + itinerary                   | Agent         | FR-AG-007..009                                |
| Combo management                                | Agent         | FR-AG-010                                     |
| Search + booking + reviews                      | User          | FR-US-\*                                      |
| AI chatbot                                      | All           | FR-AD-025, FR-AD-029                          |

## Notation

| Symbol      | Meaning                         |
| ----------- | ------------------------------- |
| `FR-AD-xxx` | Functional Requirement — Admin  |
| `FR-AG-xxx` | Functional Requirement — Agent  |
| `FR-US-xxx` | Functional Requirement — User   |
| `FR-CO-xxx` | Functional Requirement — Common |
| `BR-xx`     | Business Rule                   |
| ⭐          | Required for MVP                |

## Definition of Done

A feature is Done when:

1. DTO + Zod schema exist in `packages/shared-types`
2. API endpoint has `@Roles()` + Swagger docs
3. Unit tests for the service (Jest), e2e tests for the endpoint (Supertest)
4. Frontend page has loading + error + empty states
5. Form has client-side validation + server error mapping
6. Audit log for admin/agent actions
7. PR description lists implemented `FR-xx` and `BR-xx`

## References

- Full FRD: `uploads/FRD_He_Thong_Du_Lich.md`
