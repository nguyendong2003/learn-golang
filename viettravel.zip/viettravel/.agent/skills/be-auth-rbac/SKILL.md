---
name: auth-rbac
description: JWT auth (access + refresh token), guards, decorators, role-based access control. Use when implementing login, protecting endpoints, adding role restrictions, or building agent/admin scope.
---

# Auth + RBAC

## When to use

- Use this skill when implementing login, token flow, guards, decorators, and role restrictions.
- Use it together with `coding-patterns` for controller/service structure and `error-handling` for business exceptions.

## Core rules

- Protect every non-public endpoint with `@UseGuards(JwtAuthGuard, RolesGuard)`.
- Add `@Roles(...)` on every protected route.
- Keep ownership checks in the service after RBAC passes.
- Store refresh tokens hashed in DB and rotate them on every use.
- Use `BusinessException(ErrorCode.FORBIDDEN_OWNERSHIP)` for access violations.
- Keep controllers thin: auth, roles, params, delegate.

## Token strategy

| Token   | TTL     | Storage         | Purpose              |
| ------- | ------- | --------------- | -------------------- |
| Access  | 15 min  | Memory          | Call API             |
| Refresh | 30 days | httpOnly cookie | Get new access token |

Refresh rotation: each use → mint new token + revoke old token (store hash in DB).

## UserRole enum

```ts
// packages/types/src/enums/role.enum.ts
export enum UserRole {
  ADMIN = "ADMIN",
  STAFF = "STAFF",
  AGENT = "AGENT",
  USER = "USER",
  CORPORATE = "CORPORATE",
}
```

## Guards

```ts
@UseGuards(JwtAuthGuard, RolesGuard)
```

## Decorators

```ts
@CurrentUser() actor: AuthUser
@CurrentUser('id') userId: string
@Roles(UserRole.AGENT, UserRole.ADMIN)
@Public()
```

## Controller pattern

```ts
@Controller("tours")
@UseGuards(JwtAuthGuard, RolesGuard)
@ApiTags("tours")
@ApiBearerAuth()
export class ToursController {
  @Post()
  @Roles(UserRole.AGENT)
  create(@CurrentUser() actor: AuthUser, @Body() dto: CreateTourDto) {
    return this.tours.create(actor, dto);
  }
}
```

## AuthModule structure

- `auth.controller.ts` — login, register, refresh, logout, me
- `auth.service.ts` — credential check, token issuance, rotation
- `strategies/` — JWT and local strategy
- `tokens/` — sign, verify, rotate helpers
- `refresh-token` model — hash, expiry, revoke tracking

## JWT Strategy

```ts
@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(config: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey: config.get<string>("JWT_ACCESS_SECRET"),
    });
  }

  validate(payload: { sub: string; role: UserRole }): AuthUser {
    return { id: payload.sub, role: payload.role };
  }
}
```

## Ownership check in service

```ts
if (actor.role === UserRole.AGENT && resource.agentId !== actor.agentId) {
  throw new BusinessException(ErrorCode.FORBIDDEN_OWNERSHIP);
}
if (actor.role === UserRole.USER && resource.userId !== actor.id) {
  throw new BusinessException(ErrorCode.FORBIDDEN_OWNERSHIP);
}
```

## Refresh token model

```prisma
model RefreshToken {
  id         String    @id @default(uuid())
  userId     String    @map("user_id")
  user       User      @relation(fields: [userId], references: [id], onDelete: Cascade)
  tokenHash  String    @unique @map("token_hash")
  expiresAt  DateTime  @map("expires_at")
  revokedAt  DateTime? @map("revoked_at")
  ipAddress  String?   @map("ip_address")
  createdAt  DateTime  @default(now()) @map("created_at")

  @@map("refresh_tokens")
  @@index([userId])
  @@index([expiresAt])
}
```
