---
name: plan-task
description: Read first before every backend task. Analyze requirements, define scope, create delivery checklist. REQUIRED before writing code.
---

# Planning Process

## Start here

Before planning implementation, read:

1. `.agent/skills/project-overview/SKILL.md` — business context, actors, scope
2. `AGENTS.md` — locked rules and stack

## Step 1 — Read requirement

Find and record:

```
FR-AG-007: Agent creates tour
  Actor:         Agent (status = APPROVED)
  Preconditions: Authenticated, agent approved
  Postconditions: Tour created with status DRAFT, bound to agentId
  BR-69: maxSeats > 0
  BR-71: departureDate > now()
  Error cases:
    - Agent not approved
    - Tour name duplicate for same agent
    - departureDate in past
```

## Step 2 — Identify scope

| What to do?                | Skill to read                     |
| -------------------------- | --------------------------------- |
| New schema / schema change | `be-database`                        |
| New endpoint               | `be-coding-patterns`                 |
| New module                 | `be-create-module`                   |
| Auth / role / guard        | `be-auth-rbac`                       |
| Validate input             | `be-validation`                      |
| Error handling             | `be-error-handling`                  |
| Background job             | `be-coding-patterns` (queue section) |

## Step 3 — Delivery order (don't change)

```
1. [ ] Zod schema  →  packages/types/src/schemas/
2. [ ] Prisma model + migration
3. [ ] DTO  (createZodDto wrapper)
4. [ ] Service method(s)  →  business logic + $transaction + audit
5. [ ] Controller endpoint  →  @Roles() required
6. [ ] Register module in app.module.ts
7. [ ] Unit test service  (.spec.ts)
8. [ ] E2E test controller  (.e2e-spec.ts)
```

## Step 4 — Full checklist

```markdown
## Task: <name> FR-xx-xxx BR-xx

### Schema & DB

- [ ] Zod schema added/updated in packages/types
- [ ] Prisma model updated in schema.prisma
- [ ] Migration created and named correctly
- [ ] New enum added to shared types if needed

### Backend

- [ ] DTO: create / update / query
- [ ] Service: business logic, $transaction, ownership check
- [ ] Audit log (admin/agent mutations)
- [ ] New ErrorCode if needed
- [ ] Controller: @Roles, @ApiTags, @ApiBearerAuth
- [ ] Module registered in app.module.ts

### Async / side effects

- [ ] Queue job in queue-names.ts (if any)
- [ ] Processor in queue/processors/ (if any)
- [ ] Provider method (mail, SMS, storage) (if any)

### Tests

- [ ] Unit test service: happy path + main error cases
- [ ] E2E test: happy path + 401/403

### Docs

- [ ] .env.example updated if new env var
```

## Step 5 — Pre-commit review

- [ ] `pnpm lint` — no errors
- [ ] `pnpm type-check` — no type errors
- [ ] `pnpm test` — all pass
- [ ] Every route has `@Roles()` — no accidental public endpoints
- [ ] No `console.log`, no `process.env.*` outside `env.schema.ts`
- [ ] Response doesn't expose `passwordHash`, `refreshToken`
- [ ] Commit message includes FR/BR code

## Common planning mistakes

| Mistake                         | Consequence              | Prevention                        |
| ------------------------------- | ------------------------ | --------------------------------- |
| Skip FRD                        | Implement wrong          | Read FR + BR first                |
| Change DB without schema-first  | DTO and DB mismatch      | Zod → Prisma → DTO in order       |
| Logic in controller             | Hard to test             | Controller must be thin           |
| Forget ownership check          | User A reads User B data | Check in every service method     |
| Multi-write without transaction | Partial data if fail     | Always wrap `$transaction`        |
| Forget audit log                | Compliance violation     | Add to every admin/agent mutation |
