---
name: error-handling
description: Standard error handling — BusinessException, ErrorCode enum, AllExceptionsFilter, response format. Use when throwing errors in service or setting up exception filter.
---

# Error Handling

## When to use

- Use this skill when throwing business errors in services or shaping API error responses.
- Use it together with `coding-patterns` for service/controller structure and `database` for Prisma error handling.

## Core rules

- Throw `BusinessException(ErrorCode.XXX)` for expected failures.
- Keep error codes stable and reusable across modules.
- Map Prisma and validation failures to consistent HTTP responses.
- Let the global exception filter format the response; do not handcraft error JSON in services.

## BusinessException

```ts
throw new BusinessException(ErrorCode.TOUR_NOT_FOUND);
throw new BusinessException(ErrorCode.SEAT_UNAVAILABLE, {
  available: 2,
  requested: 5,
});
```

## ErrorCode enum

```ts
// apps/api/src/common/errors/error-code.enum.ts
export enum ErrorCode {
  // Generic
  VALIDATION_FAILED = "VALIDATION_FAILED",
  FORBIDDEN_OWNERSHIP = "FORBIDDEN_OWNERSHIP",
  RESOURCE_NOT_FOUND = "RESOURCE_NOT_FOUND",

  // Auth
  INVALID_CREDENTIALS = "INVALID_CREDENTIALS",
  TOKEN_EXPIRED = "TOKEN_EXPIRED",
  TOKEN_REVOKED = "TOKEN_REVOKED",

  // Tour
  TOUR_NOT_FOUND = "TOUR_NOT_FOUND",
  INVALID_DEPARTURE_DATE = "INVALID_DEPARTURE_DATE",
  TOUR_NOT_PUBLISHED = "TOUR_NOT_PUBLISHED",

  // Booking
  BOOKING_NOT_FOUND = "BOOKING_NOT_FOUND",
  SEAT_UNAVAILABLE = "SEAT_UNAVAILABLE",
  BOOKING_EXPIRED = "BOOKING_EXPIRED",
  INVALID_STATE_TRANSITION = "INVALID_STATE_TRANSITION",
  CANCELLATION_FEE_APPLIES = "CANCELLATION_FEE_APPLIES",

  // Agent
  AGENT_NOT_FOUND = "AGENT_NOT_FOUND",
  AGENT_NOT_APPROVED = "AGENT_NOT_APPROVED",

  // Providers
  MAIL_SEND_FAILED = "MAIL_SEND_FAILED",
  STORAGE_UPLOAD_FAILED = "STORAGE_UPLOAD_FAILED",
  PAYMENT_FAILED = "PAYMENT_FAILED",
}
```

## BusinessException class

```ts
import { HttpException, HttpStatus } from "@nestjs/common";
import { ErrorCode } from "./error-code.enum";

export class BusinessException extends HttpException {
  constructor(
    public readonly code: ErrorCode,
    public readonly details?: Record<string, unknown>,
    status: HttpStatus = HttpStatus.UNPROCESSABLE_ENTITY,
  ) {
    super({ code, details }, status);
  }
}

// Factory helpers
export const notFound = (code: ErrorCode) =>
  new BusinessException(code, undefined, HttpStatus.NOT_FOUND);

export const conflict = (code: ErrorCode, details?: Record<string, unknown>) =>
  new BusinessException(code, details, HttpStatus.CONFLICT);

export const forbidden = (code: ErrorCode = ErrorCode.FORBIDDEN_OWNERSHIP) =>
  new BusinessException(code, undefined, HttpStatus.FORBIDDEN);
```

## Global exception filter

- Global filter should translate HttpException, Prisma errors, and unknown errors into one response format.
- Log unexpected errors with `Logger` and keep the response shape stable.

**Example response shape**

```ts
{
  statusCode: 422,
  error: "Unprocessable Entity",
  code: "TOUR_NOT_FOUND",
  message: "...",
  details: undefined,
  timestamp: "...",
  path: "/api/v1/tours/123",
  requestId: "...",
}
```

## HTTP status mapping

| ErrorCode                                   | HTTP Status |
| ------------------------------------------- | ----------- |
| `*_NOT_FOUND`                               | 404         |
| `FORBIDDEN_OWNERSHIP`, `AGENT_NOT_APPROVED` | 403         |
| `INVALID_CREDENTIALS`, `TOKEN_*`            | 401         |
| `SEAT_UNAVAILABLE`, `*_CONFLICT`            | 409         |
| `VALIDATION_FAILED`                         | 400         |
| Default                                     | 422         |

## Anti-patterns

- ❌ Throwing raw `Error` for expected business failures
- ❌ Returning custom error shapes from services
- ❌ Mapping the same error code to different HTTP statuses across modules
- ❌ Logging sensitive values in error payloads
- ❌ Embedding Prisma-specific handling inside controllers

## Never do

```ts
throw new Error("Tour not found"); // ❌ raw string
throw new Error(JSON.stringify({ code: "..." })); // ❌
return res.status(404).json({ message: "Not found" }); // ❌ manual in service
```
