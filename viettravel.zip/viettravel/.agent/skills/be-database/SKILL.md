---
name: database
description: Prisma schema patterns, migration workflow, query patterns, transaction, soft delete. Use when adding/modifying models, writing migration, or optimizing queries.
---

# Database (Prisma)

## When to use

- Use this skill when adding, changing, or reviewing Prisma models, indexes, migrations, transactions, or query behavior.
- Use it together with `validation` for schema/DTO changes and `coding-patterns` for service usage.

## Inputs needed

- Target domain / entity name
- Ownership and soft-delete rules
- Relations, unique keys, and indexes
- Whether the change affects pagination, transactions, or aggregate queries

## Core rules

- Follow schema-first: update Zod first, then Prisma, then DTOs.
- Add `createdAt`, `updatedAt`, and `deletedAt` on transactional models.
- Use soft delete with `deletedAt`; never hard delete.
- Use `Int` for VND amounts.
- Add indexes for frequently queried foreign keys and composite filters.
- Keep migrations generated from Prisma; do not hand-edit applied migrations.

## Schema patterns

```prisma
// Every booking/transactional model needs these 4 fields
model Tour {
  id        String    @id @default(cuid())
  createdAt DateTime  @default(now()) @map("created_at")
  updatedAt DateTime  @updatedAt @map("updated_at")
  deletedAt DateTime? @map("deleted_at")

  // Business fields
  name      String
  slug      String    @unique                       // business key → @unique
  basePrice Int                                     // VND = Int
  status    TourStatus @default(DRAFT)
  agentId   String    @map("agent_id")
  agent     Agent     @relation(fields: [agentId], references: [id])

  @@map("tours")
  @@index([agentId])                                // FK often queried → index
  @@index([status, createdAt])                      // composite query
}
```

## Migration workflow

```bash
# 1. Edit schema.prisma
# 2. Create migration
pnpm --filter api exec prisma migrate dev --name add_tour_slug

# 3. Verify
pnpm --filter api exec prisma migrate status

# Test DB
pnpm --filter api exec prisma migrate deploy  # (don't use dev in test/prod)
```

**Don't hand-edit migration file after applying.**

## Query patterns

### findOne with soft-delete guard

```ts
const tour = await this.prisma.tour.findFirst({
  where: { id, deletedAt: null },
});
if (!tour) throw new BusinessException(ErrorCode.TOUR_NOT_FOUND);
```

### findMany with filter + pagination

```ts
const where = {
  deletedAt: null,
  ...(status && { status }),
  ...(search && { name: { contains: search, mode: "insensitive" as const } }),
};

const [items, total] = await Promise.all([
  this.prisma.tour.findMany({
    where,
    skip: (page - 1) * limit,
    take: limit,
    orderBy: { [sortBy]: order },
    select: { id: true, name: true, basePrice: true, status: true }, // only needed fields
  }),
  this.prisma.tour.count({ where }),
]);
```

### Transaction

```ts
// Multi-model write — must use transaction
const booking = await this.prisma.$transaction(async (tx) => {
  const inv = await tx.inventory.findUnique({ where: { id: dto.inventoryId } });
  if (!inv || inv.available < dto.seats)
    throw conflict(ErrorCode.SEAT_UNAVAILABLE);

  await tx.inventory.update({
    where: { id: inv.id },
    data: { available: { decrement: dto.seats } },
  });

  return tx.booking.create({ data: { ...dto, status: "PENDING" } });
});

// With isolation level (prevent double-booking)
const result = await this.prisma.$transaction(
  async (tx) => {
    /* ... */
  },
  { isolationLevel: Prisma.TransactionIsolationLevel.Serializable },
);
```

### Soft delete

```ts
await this.prisma.tour.update({
  where: { id },
  data: { deletedAt: new Date() },
});
// Every findMany/findFirst must include deletedAt: null
```

## Naming conventions

| Thing | Convention                          | Example                               |
| ----- | ----------------------------------- | ------------------------------------- |
| Model | PascalCase singular                 | `Tour`, `HotelRoom`, `BookingItem`    |
| Field | camelCase + `@map("snake_case")`    | `basePrice @map("base_price")`        |
| Table | `@@map("snake_plural")`             | `@@map("hotel_rooms")`                |
| Enum  | PascalCase name, UPPER_SNAKE values | `enum TourStatus { DRAFT PUBLISHED }` |

## Index rules

```prisma
@unique          // Business key: slug, code, email
@@index([fk])    // Every often-queried FK
// Don't index boolean, status ≤ 3 values
```

## Enum in Prisma

```prisma
enum BookingStatus {
  PENDING
  CONFIRMED
  PAID
  COMPLETED
  CANCELLED
  REFUNDING
  REFUNDED
}
```

Sync with `packages/types/src/enums/booking-status.enum.ts`:

```ts
export enum BookingStatus {
  PENDING = "PENDING",
  CONFIRMED = "CONFIRMED",
  // ...
}
```

## Anti-patterns

- ❌ Adding models without the standard timestamp/soft-delete fields
- ❌ Using hard delete instead of updating `deletedAt`
- ❌ Forgetting indexes on queried foreign keys
- ❌ Using `Float` or `Decimal` for VND
- ❌ Hand-editing migrations after they are applied
- ❌ Running transactional writes without `$transaction`
