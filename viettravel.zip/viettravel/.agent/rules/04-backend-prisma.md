---
description: Prisma schema conventions — naming, required fields, index rules
globs: apps/api/prisma/schema.prisma
alwaysApply: false
---

## Naming

- Model: `PascalCase` singular (`Tour`, `HotelRoom`, `BookingItem`)
- Field: `camelCase` + `@map("snake_case")` for DB column
- Table: `@@map("snake_case_plural")`

## Required on every model with booking/audit

```prisma
id        String    @id @default(cuid())
createdAt DateTime  @default(now()) @map("created_at")
updatedAt DateTime  @updatedAt @map("updated_at")
deletedAt DateTime? @map("deleted_at")   // soft delete
```

## Index rules

```prisma
// Business key — use @unique
slug  String @unique
code  String @unique

// FK often queried — use @@index
@@index([userId])
@@index([agentId])
@@index([status, createdAt])

// Don't index low-cardinality column (boolean, status enum ≤ 3 values)
```

## Enum

```prisma
// Define in schema
enum BookingStatus {
  PENDING
  CONFIRMED
  PAID
  COMPLETED
  CANCELLED
  REFUNDING
  REFUNDED
}
```

## Important

- Don't hand-edit migration after applying
- Every FK must have corresponding `@@index`
- VND currency → `Int`, don't use `Float` or `Decimal`
- Datetime → `DateTime` (Prisma stores UTC automatically)
