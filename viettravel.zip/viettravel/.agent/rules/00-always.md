---
description: Core always-on rules — read AGENTS.md first, stack constraints
alwaysApply: true
---

Read `AGENTS.md` before every task.
When starting a new task, also read `.agent/skills/project-overview/SKILL.md` for business context.

Stack: NestJS 11, Prisma 6, PostgreSQL 17, Zod + nestjs-zod, BullMQ, JWT.

- Don't add new libraries arbitrarily. Don't use `class-validator`.
- No `console.log`. No `throw new Error(string)`. Don't read `process.env.X` directly.
- Soft delete (`deletedAt`), never hard delete. Currency = `Int` VND. Datetime store UTC.
- Skill index in `AGENTS.md` — read the right skill before coding.
