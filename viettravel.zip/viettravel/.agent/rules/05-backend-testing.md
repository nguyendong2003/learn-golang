---
description: Testing conventions — unit (service), e2e (controller), DB reset, mock patterns
globs: apps/api/src/**/*.spec.ts, apps/api/test/**/*
alwaysApply: false
---

## Unit test — service

```ts
// Mock PrismaService with jest.fn()
const prismaMock = {
  tour: { create: jest.fn(), findUnique: jest.fn(), findMany: jest.fn(), count: jest.fn() },
  $transaction: jest.fn((fn) => fn(prismaMock)),
};

// Mock external providers (mail, storage, audit)
{ provide: AuditService, useValue: { log: jest.fn() } }
```

- Test each error case separately
- `jest.clearAllMocks()` in `beforeEach`
- Don't test implementation detail — test behavior

## E2E test — controller

```ts
// Use Supertest + separate test DB (travel_test)
// Reset DB with TRUNCATE before each test (don't rollback transaction)
// Test happy path + 1–2 most important error cases
```

- Don't mock Prisma in e2e — test with real DB (schema test)
- Don't mock JWT guard in e2e — login for real to get token
- `beforeAll` create app, `afterAll` close app, `beforeEach` reset DB

## Naming

```
bookings.service.spec.ts       # unit — service
bookings.controller.spec.ts    # unit — controller (mock service)
test/bookings.e2e-spec.ts      # e2e
```

## Test ENV (.env.test)

```dotenv
NODE_ENV=test
DATABASE_URL=postgresql://...@localhost:5432/travel_test
JWT_ACCESS_SECRET=test-access-secret-32-chars-min!!
```
