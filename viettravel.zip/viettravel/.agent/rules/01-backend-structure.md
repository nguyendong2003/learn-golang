---
description: Folder layout and layer rules for NestJS backend
globs: apps/api/**/*
alwaysApply: false
---

## Folder layout

```
apps/api/src/
├── common/          # guards, filters, decorators, pagination, errors
├── config/          # env.schema.ts (Zod validate process.env)
├── prisma/          # PrismaService, PrismaModule
├── queue/           # BullMQ processors, queue-names.ts
├── providers/       # mail, storage, sms, payment (SDK wrappers)
└── modules/
    └── <feature>/
        ├── dto/
        │   ├── create-<feature>.dto.ts
        │   ├── update-<feature>.dto.ts
        │   └── query-<feature>.dto.ts
        ├── <feature>.controller.ts
        ├── <feature>.service.ts
        ├── <feature>.module.ts
        ├── <feature>.service.spec.ts
        └── <feature>.e2e-spec.ts
```

## Layer rules

| Layer        | Allowed                                      | Forbidden                        |
| ------------ | -------------------------------------------- | -------------------------------- |
| Controller   | Parse DTO, call 1 service method             | Query DB, business logic         |
| Service      | Business logic, `$transaction`, audit, queue | Read `req`/`res`, raw `Error`    |
| DTO          | `createZodDto(Schema)`                       | `@IsString()`, `class-validator` |
| Guard/Filter | RBAC, auth, exception map                    | Business logic                   |

- Don't import services from other modules directly — use events or import module and inject service.
- SDK wrappers (mail, MinIO, SMS, payment) → `src/providers/<name>/`, not in modules.
- Zod schemas (source of truth) → `packages/types/src/schemas/`, not created in `apps/api`.
