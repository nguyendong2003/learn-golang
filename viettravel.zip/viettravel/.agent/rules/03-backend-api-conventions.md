---
description: API conventions for controllers — routes, response envelope, pagination, status codes, and controller hygiene.
globs: apps/api/src/**/*.controller.ts
alwaysApply: false
---

## What this covers

- Route shape and naming for REST controllers
- Standard response envelope for success and error cases
- Pagination query defaults and common HTTP status codes
- Controller hygiene: roles, Swagger decorators, and thin handlers

## URL pattern

- Use plural, kebab-case routes.
- Keep the global prefix as `api/v1`.

**Example**

```
GET    /api/v1/tours           → list (paginated)
GET    /api/v1/tours/:id       → detail
POST   /api/v1/tours           → create
PATCH  /api/v1/tours/:id       → partial update
DELETE /api/v1/tours/:id       → soft delete
```

- URL examples: `tour-departures`, `hotel-rooms`

## Response envelope

- Return a consistent envelope so controllers stay predictable.

**Example**

```ts
// Success
{ data: T, meta?: PaginationMeta }

// Error
{ error: { code: string, message: string, details?: unknown } }
```

## Pagination query

- Use standard query params for list endpoints.

**Example**

```
?page=1&limit=20&sortBy=createdAt&order=desc&search=abc
```

## HTTP status

- Use the status code that matches the outcome.

| Status | When                                   |
| ------ | -------------------------------------- |
| 200    | GET / PATCH success                    |
| 201    | POST create success                    |
| 204    | DELETE success                         |
| 400    | Validation error                       |
| 401    | Not authenticated                      |
| 403    | No permission / don't own resource     |
| 404    | Not found                              |
| 409    | Conflict (duplicate, seat unavailable) |

## Controller checklist

- Every controller class must include `@ApiTags(...)` and `@ApiBearerAuth()`.
- Every route must have `@Roles(...)`.
- Keep handlers thin: parse input and delegate to one service method.

**Checklist**

- [ ] Route uses plural, kebab-case naming
- [ ] Global prefix remains `api/v1`
- [ ] Response follows `{ data, meta? }` or `{ error }`
- [ ] Pagination uses `page`, `limit`, `sortBy`, `order`, `search`
- [ ] HTTP status matches the operation outcome
- [ ] Class has `@ApiTags(...)` and `@ApiBearerAuth()`
- [ ] Every route has `@Roles(...)`
- [ ] Handler contains no business logic

## Anti-patterns

- ❌ Hard-coding a one-off response shape per controller
- ❌ Putting business rules in controller methods
- ❌ Returning 200 for create/delete operations that should be 201/204
- ❌ Skipping `@Roles()` because the controller is already protected
- ❌ Mixing route naming styles across modules
