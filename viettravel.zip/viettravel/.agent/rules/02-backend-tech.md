---
description: Locked dependencies, forbidden libraries, key usage patterns for apps/api
globs: apps/api/**/*.ts
alwaysApply: false
---

## Locked versions

| Package                        | Version      |
| ------------------------------ | ------------ |
| `@nestjs/*`                    | `^11`        |
| `prisma` / `@prisma/client`    | `^6`         |
| `zod`                          | `^3`         |
| `nestjs-zod`                   | `^4`         |
| `bullmq` / `@nestjs/bullmq`    | `^5` / `^11` |
| `ioredis`                      | `^5`         |
| `@nestjs/jwt` + `passport-jwt` | `^11` / `^4` |
| `@nestjs/throttler`            | `^6`         |
| `nestjs-pino`                  | `^4`         |

## Absolutely forbidden

- `class-validator`, `class-transformer` → use `nestjs-zod`
- `TypeORM`, `MikroORM`, `Sequelize` → use Prisma
- `console.log` → use `new Logger(ClassName.name)`
- `process.env.X` in service → use `ConfigService.get<T>('KEY')`
- `throw new Error(string)` → use `BusinessException(ErrorCode.XXX)`
- Hard delete entity with booking → set `deletedAt` (soft delete)

## Required

```ts
// Validation
export class CreateTourDto extends createZodDto(CreateTourSchema) {}

// Logging
private readonly logger = new Logger(ToursService.name);
this.logger.log({ tourId }, 'Tour created');

// Config
const secret = this.config.get<string>('JWT_SECRET');

// Transaction
await this.prisma.$transaction(async (tx) => { ... });

// Business error
throw new BusinessException(ErrorCode.TOUR_NOT_FOUND);
```
